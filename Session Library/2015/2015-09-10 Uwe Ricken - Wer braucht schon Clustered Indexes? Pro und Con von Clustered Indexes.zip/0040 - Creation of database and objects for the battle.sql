/*============================================================================
	File:		0040 - Creation of database and objects for the battle.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

	Date:		June 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
IF db_id('demo_db') IS NOT NULL
BEGIN
	RAISERROR ('Database demo_db will be dropped first!', 0, 0) WITH NOWAIT;
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

RAISERROR ('Database demo_db will be created!', 0, 0) WITH NOWAIT;
CREATE DATABASE demo_db
ON PRIMARY
(
	Name = 'demo_db',
	FILENAME = 'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db.mdf',
	SIZE = 100MB,
	MAXSIZE = 4000MB,
	FILEGROWTH = 100MB
)
LOG ON
(
	NAME = 'demo_log',
	FILENAME = 'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db.ldf',
	SIZE = 100MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
);
GO

RAISERROR ('Owner of database demo_db will be set to sa!', 0, 1) WITH NOWAIT;
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;

-- for the demos concerning fn_dbLog() keep in mind to set the
-- RECOVERY model to full unless you want run investigation later on!
RAISERROR ('Recovery model of database demo_db will be set to SIMPLE!', 0, 1) WITH NOWAIT;
ALTER DATABASE demo_db SET RECOVERY SIMPLE;
GO

-- Now we create two tables for the battle
USE demo_db;
GO

CREATE TABLE [dbo].[ClusteredIndex]
(
	[Id]	INT			NOT NULL	IDENTITY (1, 1),
	[c1]	CHAR(1000)	NOT NULL,
	[c2]	CHAR(3)		NOT NULL,
	[c4]	CHAR(5)		NOT NULL,
	[c5]	DATE		NOT NULL,

	CONSTRAINT pk_ClusteredIndex_Id PRIMARY KEY CLUSTERED([Id])
);
GO

CREATE TABLE [dbo].[Heap]
(
	[Id]	INT			NOT NULL,
	[c1]	CHAR(1000)	NOT NULL,
	[c2]	CHAR(3)		NOT NULL,
	[c4]	CHAR(5)		NOT NULL,
	[c5]	DATE		NOT NULL
);
GO

PRINT 'Now the tables can be filled with the data generator file 0040 - DATA GENERATOR.sqlgen'
GO