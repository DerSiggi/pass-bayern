/*============================================================================
	File:		0020 - Internals of a HEAP.sql

	Summary:	This script demonstrates the internal differences between
				a HEAP and a CLUSTERED INDEX.

	Attention:	This script will use undocumented functions of Microsoft SQL Server.
				Use this script not in a productive environment!

	Date:		June 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'cix_Addresses_Id' AND OBJECT_ID = OBJECT_ID('dbo.Addresses', 'U'))
	CREATE UNIQUE CLUSTERED INDEX cix_Addresses_Id ON dbo.Addresses (Id);
	GO

-- Internal structure of a clustered index: dbo.Addresses as example
SELECT	i.name,
		i.index_id,
		DDDPA.extent_page_id,
		DDDPA.page_type_desc,
		DDDPA.previous_page_page_id,
		DDDPA.allocated_page_page_id,
		DDDPA.next_page_page_id,
		DDDPA.page_free_space_percent,
		DDDPA.page_level
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_database_page_allocations
		(
			DB_ID(),
			I.object_id,
			I.index_id,
			NULL,
			'DETAILED'
		) AS DDDPA
WHERE	I.object_id = OBJECT_ID('dbo.Addresses', 'U') AND
		I.name = 'cix_Addresses_Id' AND
		DDDPA.is_allocated = 1
ORDER BY
		DDDPA.page_type DESC,		-- IAM-Pages first,
		DDDPA.page_level DESC,
		DDDPA.previous_page_page_id ASC,
		DDDPA.allocated_page_page_id;
GO

-- Activate TF 3604 for the output of data to client
DBCC TRACEON (3604);
GO

-- Inside the IAM Page of the CLUSTERED INDEX
DBCC PAGE ('CustomerOrders', 1, 41411, 3);
GO

-- Inside the PFS-Page
DBCC PAGE ('CustomerOrders', 1, 40440, 3);
GO


-- Inside the root node of the CLUSTERED INDEX
DBCC PAGE ('CustomerOrders', 1, 41413, 3);
GO

-- Inside the leaf node of the clustered index
DBCC PAGE ('CustomerOrders', 1, 41875, 3);
GO

SET STATISTICS IO ON;
GO

SELECT * FROM dbo.Addresses
WHERE Id = 513;

SET STATISTICS IO OFF;
GO

DBCC TRACEOFF (3604);
GO
