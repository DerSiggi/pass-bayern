/*============================================================================
	File:		0020 - Internals of a HEAP.sql

	Summary:	This script demonstrates the internal differences between
				a HEAP and a CLUSTERED INDEX.

	Attention:	This script will use undocumented functions of Microsoft SQL Server.
				Use this script not in a productive environment!

	Date:		June 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- Internal structure of a heap: dbo.Customers as example
SELECT	DDDPA.extent_page_id,
		DDDPA.page_type_desc,
		DDDPA.previous_page_page_id,
		DDDPA.allocated_page_page_id,
		DDDPA.next_page_page_id,
		DDDPA.page_free_space_percent,
		DDDPA.page_level
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_database_page_allocations
		(
			DB_ID(),
			I.object_id,
			I.index_id,
			NULL,
			'DETAILED'
		) AS DDDPA
WHERE	I.object_id = OBJECT_ID('dbo.Customers', 'U') AND
		DDDPA.is_allocated = 1
ORDER BY
		DDDPA.page_type DESC,		-- IAM-Pages first,
		DDDPA.allocated_page_page_id;
GO

-- Look into the IAM-Page for informational purposes
DBCC TRACEON (3604);
DBCC PAGE ('CustomerOrders', 1, 40152, 3);
GO

-- Look into the PFS-Page
DBCC PAGE ('CustomerOrders', 1, 32352, 3);
GO

-- Inside a random data page of the HEAP: dbo.Customers
DBCC PAGE ('CustomerOrders', 1, 24519, 3);
GO
