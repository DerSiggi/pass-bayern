/*============================================================================
	File:		0050 - HEAP vs CLUSTER - SELECT.sql

	Summary:	This script demonstrates the functionality of non clustered
				indexes in a HEAP. This script is part of the session:
				Clustered Indexes - PRO and CON.

	Attention:	This script will use undocumented functions of Microsoft SQL Server.
				Use this script not in a productive environment!

	Date:		June 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
SET NOCOUNT ON;
DBCC DROPCLEANBUFFERS;
SET STATISTICS IO, TIME ON;
GO

/*
	1. Run a SELECT on both tables for a dedicated ID
	Both queries will run with MAXDOP 1 to avoid "ungerechte" executions
	while a performant index seek is much better than an index scan which
	may predict parallel executions!
*/
DECLARE	@I AS INT = CAST(RAND() * 1000000 AS INT);
SELECT * FROM dbo.ClusteredIndex WHERE Id = @I OPTION (RECOMPILE, MAXDOP 1);
SELECT * FROM dbo.Heap WHERE Id = @I OPTION (RECOMPILE, MAXDOP 1);
GO

/*
	Because we KNOW that each ID is unique we could use TOP 1
	as long as we use ID <= 21 the IO will be better to equal
	to the clustered index
*/
DECLARE	@I AS INT = 4;
SELECT TOP 1 * FROM dbo.ClusteredIndex WHERE Id = @I OPTION (RECOMPILE, MAXDOP 1);
SELECT TOP 1 * FROM dbo.Heap WHERE Id = @I OPTION (RECOMPILE, MAXDOP 1);
GO

/*
	The benefit of the SEEK will be destroyed when an attribute will
	be selected which has NO index!

	Before we run the queries we'll check whether there is an index
	on both tables
*/
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'ix_ClusteredIndex_C2' AND OBJECT_ID = OBJECT_ID('dbo.ClusteredIndex', 'U'))
	DROP INDEX ix_ClusteredIndex_C2 ON dbo.ClusteredIndex;
	GO

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'ix_HEAP_C2' AND OBJECT_ID = OBJECT_ID('dbo.HEAP', 'U'))
	DROP INDEX ix_Heap_C2 ON dbo.HEAP;
	GO

SELECT	DISTINCT
		C2				AS	CountryCode,
		COUNT_BIG(*)	AS	Anzahl
FROM	dbo.ClusteredIndex
GROUP BY
		C2
ORDER BY
		C2
OPTION	(RECOMPILE, MAXDOP 1);
GO

SELECT	DISTINCT
		C2				AS	CountryCode,
		COUNT_BIG(*)	AS	Anzahl
FROM	dbo.HEAP
GROUP BY
		C2
ORDER BY
		C2
OPTION	(RECOMPILE, MAXDOP 1);
GO

/* ok - the HEAP performs better because of... ? */
SELECT	QUOTENAME(ISNULL(i.name, 'HEAP'))		AS	IndexName,
		DDIPS.index_id,
		DDIPS.index_level,
		DDIPS.page_count,
		DDIPS.record_count,
		DDIPS.min_record_size_in_bytes,
		DDIPS.max_record_size_in_bytes
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_index_physical_stats
		(
			DB_ID(),
			i.object_id,
			i.index_id,
			NULL,
			'DETAILED'
		) AS DDIPS
WHERE	i.object_id IN
		(OBJECT_ID('dbo.Heap', 'U'), OBJECT_ID('dbo.ClusteredIndex', 'U'))
ORDER BY
		i.name ASC,
		DDIPS.index_Id ASC,
		DDIPS.index_level DESC;
GO

/* Because of the really bad execution plan we create an index on C2 */
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'ix_ClusteredIndex_C2' AND OBJECT_ID = OBJECT_ID('dbo.ClusteredIndex', 'U'))
	CREATE INDEX ix_ClusteredIndex_C2 ON dbo.ClusteredIndex (C2);
	GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'ix_HEAP_C2' AND OBJECT_ID = OBJECT_ID('dbo.HEAP', 'U'))
	CREATE INDEX ix_Heap_C2 ON dbo.HEAP (C2);
	GO

/* Let's run the queries again to see the benefits */
SELECT	DISTINCT
		C2				AS	CountryCode,
		COUNT_BIG(*)	AS	Anzahl
FROM	dbo.ClusteredIndex
GROUP BY
		C2
ORDER BY
		C2
OPTION	(RECOMPILE, MAXDOP 1);
GO

SELECT	DISTINCT
		C2				AS	CountryCode,
		COUNT_BIG(*)	AS	Anzahl
FROM	dbo.HEAP
GROUP BY
		C2
ORDER BY
		C2
OPTION	(RECOMPILE, MAXDOP 1);
GO

/* ok - the clustered index is much better because of what? ...*/
SELECT	QUOTENAME(ISNULL(i.name, 'HEAP'))		AS	IndexName,
		DDIPS.index_id,
		DDIPS.index_level,
		DDIPS.page_count,
		DDIPS.record_count,
		DDIPS.min_record_size_in_bytes,
		DDIPS.max_record_size_in_bytes
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_index_physical_stats
		(
			DB_ID(),
			i.object_id,
			i.index_id,
			NULL,
			'DETAILED'
		) AS DDIPS
WHERE	i.name IN
		(
			'ix_ClusteredIndex_C2',
			'ix_Heap_C2'
		)
ORDER BY
		i.name ASC,
		DDIPS.index_Id ASC,
		DDIPS.index_level DESC;
GO

/* Why do we have 4 bytes more in the index in the HEAP? */
-- Let's check the index of the clustered index!
SELECT	i.name,
		DDDPA.index_id,
		DDDPA.page_type,
		DDDPA.page_level,
		DDDPA.previous_page_page_id,
		DDDPA.allocated_page_page_id,
		DDDPA.next_page_page_id
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_database_page_allocations
		(
			DB_ID(),
			I.object_id,
			I.index_id,
			NULL,
			'DETAILED'
		) AS DDDPA
WHERE	i.name = 'ix_ClusteredIndex_C2' AND
		DDDPA.is_allocated = 1
ORDER BY
		DDDPA.page_type DESC,
		DDDPA.page_level DESC,
		DDDPA.previous_page_page_id ASC;
GO

DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 411, 3);
DBCC PAGE ('demo_db', 1, 287016, 3);
GO

-- Let's check the index of the HEAP!
SELECT	i.name,
		DDDPA.index_id,
		DDDPA.page_type,
		DDDPA.page_level,
		DDDPA.previous_page_page_id,
		DDDPA.allocated_page_page_id,
		DDDPA.next_page_page_id
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_database_page_allocations
		(
			DB_ID(),
			I.object_id,
			I.index_id,
			NULL,
			'DETAILED'
		) AS DDDPA
WHERE	i.name = 'ix_HEAP_C2' AND
		DDDPA.is_allocated = 1
ORDER BY
		DDDPA.page_type DESC,
		DDDPA.page_level DESC,
		DDDPA.previous_page_page_id ASC;
GO

DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 287011, 3);
GO

-- Encode the RID-Information
DECLARE @RID VARBINARY(8) = 0x0019030001000200;
WITH rid
AS
(
	SELECT	CAST
			(
				SUBSTRING(@RID, 6, 1) +
				SUBSTRING(@RID, 5, 1)
				AS INT
			)								AS	[File_Id],
			CAST
			(
				SUBSTRING(@RID, 4, 1) +
				SUBSTRING(@RID, 3, 1) +
				SUBSTRING(@RID, 2, 1) +
				SUBSTRING(@RID, 1, 1)
				AS INT
			)								AS	[Page_Id],
			CAST
			(
				SUBSTRING(@RID, 8, 1) +
				SUBSTRING(@RID, 7, 1)
				AS INT
			)								AS	[Slot_Id]
)
SELECT	rid.[File_Id],
		rid.[Page_Id],
		rid.[Slot_Id],
		'(' +
			CAST(rid.[File_Id] AS VARCHAR(5))  + ':' +
			CAST(rid.[Page_Id] AS VARCHAR(10)) + ':' +
			CAST(rid.[Slot_Id] AS VARCHAR(2)) +
		')'
FROM	rid;

SELECT	TOP 1
		*
FROM	dbo.HEAP
WHERE	sys.fn_PhysLocFormatter(%%physloc%%) = '(1:203008:2)';
GO

-- Now we check the entry by investigation of the data page
DBCC PAGE ('demo_db', 1, 203008, 3);
GO