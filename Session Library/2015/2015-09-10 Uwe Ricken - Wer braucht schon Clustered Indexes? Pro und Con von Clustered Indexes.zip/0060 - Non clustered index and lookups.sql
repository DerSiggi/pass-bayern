/*============================================================================
	File:		0060 - Non clustered index and lookups.sql

	Summary:	This script demonstrates the functionality of non clustered
				indexes in a HEAP and CLUSTERED INDEX. This script is part of
				the session: Clustered Indexes - PRO and CON.

	Attention:	This script will use undocumented functions of Microsoft SQL Server.
				Use this script not in a productive environment!

	Date:		June 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET STATISTICS IO, TIME ON;
GO

DECLARE	@Id	INT,
		@C1	CHAR(1000),
		@C2 CHAR(3),
		@C4	VARCHAR(100),
		@C5	DATE;

SELECT	@Id = Id,
		@C1 = C1,
		@C2 = @C2,
		@C4 = @C4,
		@C5 = @C5
FROM	dbo.Heap AS H
WHERE	H.c2 = 'DEU';

SELECT	@Id = Id,
		@C1 = C1,
		@C2 = @C2,
		@C4 = @C4,
		@C5 = @C5
FROM	dbo.ClusteredIndex AS CI
WHERE	CI.c2 = 'DEU';
GO
