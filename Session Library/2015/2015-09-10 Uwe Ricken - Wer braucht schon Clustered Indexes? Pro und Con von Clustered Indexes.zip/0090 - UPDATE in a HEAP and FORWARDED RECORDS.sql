/*============================================================================
	File:		0090 - UPDATE in a HEAP and FORWARDED RECORDS.sql

	Summary:	This script uses data in a HEAP and after an expansion of the
				data length it produces a FORWARDED record

				THIS SCRIPT IS PART OF THE TRACK: "Clustered Indexes - Pro and Con"

	Date:		July 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET NOCOUNT ON
SET LANGUAGE us_english;
GO

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	c1	int		IDENTITY(1, 1),
	c2	varchar(8000)
);
GO

INSERT INTO dbo.demo_table (c2) VALUES (REPLICATE('A', 3500));
INSERT INTO dbo.demo_table (c2) VALUES (REPLICATE('B', 3500));
GO

-- get the physical and logical location of the data
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.demo_table
GO

-- Update the record 1 and write a text of 1 chars into col2
BEGIN TRANSACTION UpdateRecord
GO
	UPDATE	dbo.demo_table SET c2 = 'A' WHERE c1 = 1;

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO
COMMIT TRANSACTION UpdateRecord
GO

/*
	What happend inside the named transaction?
	NOTICE that not only the data record is affected from the update
	but the PFS, too!

	PFS is affected because the filling status of the page has changed!
*/
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord')
ORDER BY
		[Current LSN];

CHECKPOINT;
GO

-- Update the record 1 and write a text of 5000 chars into col2
BEGIN TRANSACTION UpdateRecord
GO
	UPDATE	dbo.demo_table SET c2 = REPLICATE ('A', 5000) WHERE c1 = 1;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO
COMMIT TRANSACTION UpdateRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		[Page ID],
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord')
ORDER BY
		[Current LSN];

CHECKPOINT;
GO

SET STATISTICS IO ON;
GO

SELECT * FROM dbo.demo_table AS h;
GO

SET STATISTICS IO OFF;
GO

-- What pages will be allocated by the table
SELECT	p.*, h.*
FROM	dbo.demo_table AS h
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- see the physical situation on the data page
DBCC TRACEON(3604);
DBCC PAGE ('demo_db', 1, 287004, 3);
GO

-- Where is the record
DBCC PAGE ('demo_db', 1, 287006, 1);
GO

CHECKPOINT;
GO

/*
	2 database pages (except IAM) are allocated by the table
	although only 1 page is in use!
*/
SELECT	index_id,
		page_type,
		page_type_desc,
		allocated_page_page_id
FROM	sys.dm_db_database_page_allocations
		(
			DB_ID(),
			OBJECT_ID('dbo.demo_table', 'U'),
			NULL,
			NULL,
			'DETAILED'
		)
ORDER BY
		Index_id;
GO

-- Reset the length of the record to  previous length
BEGIN TRANSACTION UpdateRecord
GO
	/*
		USE (TABLOCK) to release empty pages in the table!
		If you don't use TABLOCK the pages will not be
		deallocated to the database!
	*/
	UPDATE	dbo.demo_table -- WITH (TABLOCK)
	SET		c2 = REPLICATE ('A', 20)
	WHERE	c1 = 1;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO

COMMIT TRANSACTION UpdateRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[RowLog Contents 0]		AS	OldData,
		[RowLog Contents 1]		AS	NewData
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) =
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'UpdateRecord')
ORDER BY
		[Current LSN];
GO

SET STATISTICS IO ON;
GO

SELECT p.*, h.* FROM dbo.demo_table AS h CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- How many pages are allocated by the table
SELECT	*
FROM	sys.dm_db_partition_stats
WHERE	object_id = OBJECT_ID('dbo.demo_table');
GO

-- Clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO
