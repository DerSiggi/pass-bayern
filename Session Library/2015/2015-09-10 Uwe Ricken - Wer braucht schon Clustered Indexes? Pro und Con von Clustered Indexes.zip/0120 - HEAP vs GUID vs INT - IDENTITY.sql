/*============================================================================
	File:		0120 - GUID vs INT - IDENTITY.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts


	Date:		M�rz 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
IF db_id('INT_VS_GUID') IS NOT NULL
BEGIN
	RAISERROR ('Database INT_VS_GUID will be dropped first!', 0, 0) WITH NOWAIT;
	ALTER DATABASE INT_VS_GUID SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE INT_VS_GUID;
END
GO

-- and create a new demo database
CREATE DATABASE [INT_VS_GUID]
ON PRIMARY
(
	NAME = N'INT_VS_GUID_01',
	FILENAME = N'F:\DATA\INT_VS_GUID_01.mdf',
	SIZE = 200MB,
	MAXSIZE = 100000MB,
	FILEGROWTH = 100MB
),
(
	NAME = N'INT_VS_GUID_02',
	FILENAME = N'F:\DATA\INT_VS_GUID_02.ndf',
	SIZE = 200MB,
	MAXSIZE = 100000MB,
	FILEGROWTH = 100MB
),
(
	NAME = N'INT_VS_GUID_03',
	FILENAME = N'F:\DATA\INT_VS_GUID_03.ndf',
	SIZE = 200MB,
	MAXSIZE = 100000MB,
	FILEGROWTH = 100MB
),
(
	NAME = N'INT_VS_GUID_04',
	FILENAME = N'F:\DATA\INT_VS_GUID_04.ndf',
	SIZE = 200MB,
	MAXSIZE = 100000MB,
	FILEGROWTH = 100MB
)
LOG ON
(
	NAME = N'demo_log',
	FILENAME = N'F:\DATA\INT_VS_GUID.ldf',
	SIZE = 500MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
);
GO

ALTER AUTHORIZATION ON DATABASE::INT_VS_GUID TO sa;
ALTER DATABASE [INT_VS_GUID] SET RECOVERY SIMPLE;
GO

USE INT_VS_GUID;
GO

-- table with contigious numbers as clustered key
CREATE TABLE dbo.numeric_table
(
	Id	INT						NOT NULL	IDENTITY(1, 1),
	c1	CHAR(400)				NOT NULL	DEFAULT ('just a filler'),
	
	CONSTRAINT pk_numeric_table PRIMARY KEY CLUSTERED (Id)
);
GO

-- table with random guid as clustered key
CREATE TABLE dbo.guid_table
(
	Id	UNIQUEIDENTIFIER	NOT NULL	ROWGUIDCOL	DEFAULT(NEWID()),
	c1	CHAR(388)			NOT NULL	DEFAULT ('just a filler'),
	
	CONSTRAINT pk_guid_table PRIMARY KEY CLUSTERED (Id)
);
GO

-- table with contigious numbers as clustered key
CREATE TABLE dbo.heap_table
(
	Id	INT			NOT NULL	IDENTITY(1, 1),
	c1	CHAR(400)	NOT NULL	DEFAULT ('just a filler')
);
GO

-- Procedure for insertion of 1,000 records in numeric_table
CREATE PROC dbo.proc_insert_data
	@type varchar(10)
AS
	SET NOCOUNT ON

	DECLARE	@i INT = 1;

	IF @type = 'numeric'
	BEGIN
		WHILE @i <= 1000
		BEGIN
			INSERT INTO dbo.numeric_table DEFAULT VALUES
			SET @i += 1;
		END

		RETURN;
	END
	
	IF @type = 'guid'
	BEGIN
		WHILE @i <= 1000
		BEGIN
			INSERT INTO dbo.guid_table DEFAULT VALUES
			SET @i += 1;
		END

		RETURN;
	END
			
	WHILE @i <= 1000
	BEGIN
		INSERT INTO dbo.heap_table DEFAULT VALUES
		SET @i += 1;
	END


	SET NOCOUNT OFF;
GO

TRUNCATE TABLE dbo.numeric_table;
TRUNCATE TABLE dbo.guid_table;
TRUNCATE TABLE dbo.heap_table;
GO

CHECKPOINT;
GO
/*
	ostress -E -SNB-LENOVO-I\SQL_2012 -Q"EXEC dbo.proc_insert_data 'heap';" -n100 -dINT_VS_GUID -q
*/

DBCC SQLPERF('sys.dm_os_wait_stats', 'CLEAR');
GO

SELECT	DOWT.wait_type,
		DOWT.resource_description,
		COUNT_BIG(DOWT.session_id)		AS	no_sessions,
		SUM(DOWT.wait_duration_ms)		AS	sum_ms
FROM	sys.dm_exec_sessions AS DES INNER JOIN sys.dm_os_waiting_tasks AS DOWT
		ON (DES.session_id = DOWT.session_id)
WHERE	DES.is_user_process = 1
GROUP BY
		DOWT.wait_type,
		DOWT.resource_description;
GO

SELECT * FROM sys.dm_os_wait_stats AS DOWS
WHERE	waiting_tasks_count > 0 AND
[wait_type] NOT IN
(
	N'BROKER_EVENTHANDLER',         N'BROKER_RECEIVE_WAITFOR',
	N'BROKER_TASK_STOP',            N'BROKER_TO_FLUSH',
	N'BROKER_TRANSMITTER',          N'CHECKPOINT_QUEUE',
	N'CHKPT',                       N'CLR_AUTO_EVENT',
	N'CLR_MANUAL_EVENT',            N'CLR_SEMAPHORE',
	N'DBMIRROR_DBM_EVENT',          N'DBMIRROR_EVENTS_QUEUE',
	N'DBMIRROR_WORKER_QUEUE',       N'DBMIRRORING_CMD',
	N'DIRTY_PAGE_POLL',             N'DISPATCHER_QUEUE_SEMAPHORE',
	N'EXECSYNC',                    N'FSAGENT',
	N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
	N'HADR_CLUSAPI_CALL',           N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',
	N'HADR_LOGCAPTURE_WAIT',        N'HADR_NOTIFICATION_DEQUEUE',
	N'HADR_TIMER_TASK',             N'HADR_WORK_QUEUE',
	N'KSOURCE_WAKEUP',              N'LAZYWRITER_SLEEP',
	N'LOGMGR_QUEUE',                N'ONDEMAND_TASK_QUEUE',
	N'PWAIT_ALL_COMPONENTS_INITIALIZED',
	N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
	N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
	N'REQUEST_FOR_DEADLOCK_SEARCH', N'RESOURCE_QUEUE',
	N'SERVER_IDLE_CHECK',           N'SLEEP_BPOOL_FLUSH',
	N'SLEEP_DBSTARTUP',             N'SLEEP_DCOMSTARTUP',
	N'SLEEP_MASTERDBREADY',         N'SLEEP_MASTERMDREADY',
	N'SLEEP_MASTERUPGRADED',        N'SLEEP_MSDBSTARTUP',
	N'SLEEP_SYSTEMTASK',            N'SLEEP_TASK',
	N'SLEEP_TEMPDBSTARTUP',         N'SNI_HTTP_ACCEPT',
	N'SP_SERVER_DIAGNOSTICS_SLEEP', N'SQLTRACE_BUFFER_FLUSH',
	N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
	N'SQLTRACE_WAIT_ENTRIES',       N'WAIT_FOR_RESULTS',
	N'WAITFOR',                     N'WAITFOR_TASKSHUTDOWN',
	N'WAIT_XTP_HOST_WAIT',          N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG',
	N'WAIT_XTP_CKPT_CLOSE',         N'XE_DISPATCHER_JOIN',
	N'XE_DISPATCHER_WAIT',          N'XE_TIMER_EVENT'
) AND
[wait_type] NOT LIKE 'PREEMPTIVE_OS%'
ORDER BY waiting_tasks_count DESC;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM	sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.numeric_table', 'U'),
	1,
	NULL,
	'DETAILED'
) AS DDIPS;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.guid_table', 'U'),
	1,
	NULL,
	'DETAILED'
) AS DDIPS;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM	sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.heap_table', 'U'),
	0,
	NULL,
	'DETAILED'
) AS DDIPS;
GO
