/*============================================================================
	File:		0011 - restore demo database from existing backup.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

	DOWNLOAD LINK: http://1drv.ms/1abFupW

	Date:		M�rz 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
RESTORE FILELISTONLY FROM DISK = 'S:\BACKUP\demo_db_full.bak';
GO

RESTORE DATABASE CustomerOrders FROM DISK = 'S:\BACKUP\demo_db_full.bak'
WITH 
	MOVE 'demo_db' TO 'F:\DATA\CustomerOrders.mdf',
	MOVE 'demo_log' TO 'F:\DATA\CustomerOrders.ldf',
	REPLACE,
	STATS = 10;
GO

ALTER AUTHORIZATION ON DATABASE::CustomerOrders TO SA;
ALTER DATABASE CustomerOrders SET COMPATIBILITY_LEVEL = 110;
GO
