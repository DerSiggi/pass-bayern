/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */

GO

create table dbo.MaxDataTable(
	c1 bigint,
	c2 numeric (36,3),
	c3 bit,
	c4 smallint,
	c5 decimal (18,3),
	c6 smallmoney,
	c7 int,
	c8 tinyint,
	c9 money,
	c10 float(24),
	c11 real,
	c12 date,
	c13 datetimeoffset,
	c14 datetime2 (7),
	c15 smalldatetime,
	c16 datetime,
	c17 time (7),
	c18 char(100),
	c19 varchar(100),
	c20 nchar(100),
	c21 nvarchar(100),
	c22 binary(8),
	c23 varbinary(8),
	c24 uniqueidentifier,
);


-- Lets try out to create a new Clustered Columnstore Index:
Create Clustered Columnstore Index 
	CC_MaxDataTable on dbo.MaxDataTable;

-- Insert some Null's by default into this table:
insert into dbo.MaxDataTable
	default values;

-- Select content of our table
select c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20, c21, c22, c23, c24
	from dbo.MaxDataTable; 


-- *****************************************************************

-- Let us add one more column
alter table dbo.MaxDataTable
	add c25 int NULL;
GO

update dbo.MaxDataTable
	set c25 = 23;

-- Can we actually modify it ?
alter table dbo.MaxDataTable
	alter column c25 int NOT NULL;

-- Drop it
alter table dbo.MaxDataTable
	drop column c25;

-- *****************************************************************
-- Insert 10.000 rows
insert into dbo.MaxDataTable
	default values;
GO 10000

-- *****************************************************************
-- Check on the Row Groups status
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;
		


-- *****************************************************************
-- Lets Update all C1 rows with their ID
with updTable as
	(
	select *
		, row_number() over(partition by C1 order by C1) as rnk
		from dbo.MaxDataTable
	)
update updTable
	set C1 = rnk;

-- *****************************************************************
-- Check on the Row Groups status
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;
		


-- *****************************************************************
-- Lets Delete 5.000 rows
delete from dbo.MaxDataTable
	where C1 % 2 = 0;

-- *****************************************************************
-- Check on the Row Groups status (No deleted rows suffered, since we are still working with Delta-Store)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;
		


-- *****************************************************************
-- Since data is still in the Delta-store lets try to Rebuild the table to put everything into a Segment:
alter table dbo.MaxDataTable 
        rebuild;
GO

-- *****************************************************************
-- Check on the Row Groups status (No deleted rows, because we rebuild completely our Row Group)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Insert more 10.000 rows 
insert into dbo.MaxDataTable
	default values;
GO 10000

-- *****************************************************************
-- Check on the Row Groups status (1 Delta-Store, 1 Row Group)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Lets Update all C1 rows with their ID
with updTable as
	(
	select *
		, row_number() over(partition by C1 order by C1) as rnk
		from dbo.MaxDataTable
	)
update updTable
	set C1 = rnk;

-- *****************************************************************
-- Check on the Row Groups status (Our Row Group is actually completely deleted)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Lets Delete half of the available rows
delete from dbo.MaxDataTable
	where C1 % 2 = 0;

-- *****************************************************************
-- Check on the Row Groups status 
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Insert 1.045.678 rows in order to get the Delta-Store full
declare @i as int;
declare @max as int;
select @max = isnull(max(C1),0) from dbo.MaxDataTable;
set @i = 1;

begin tran
while @i <= 1048576
begin
	insert into dbo.MaxDataTable
		default values

	set @i = @i + 1;
end;
commit;

-- *****************************************************************
-- Observe Delta-Stores !!!
-- Lets wait for Tuple-Mover to kick-in (occurs every 5 min)
-- Check on the Row Groups status ( 1 Open, 1 Close & 1 Compressed )
-- After Tuple Mover will be executed, there will be 2 Compressed & 1 Open
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Insert another 1.045.768 rows and kick in manually Tuple Mover
declare @i as int;
declare @max as int;
select @max = isnull(max(C1),0) from dbo.MaxDataTable;
set @i = 1;

begin tran
while @i <= 1048576
begin
	insert into dbo.MaxDataTable
		default values

	set @i = @i + 1;
end;
commit;

-- Tuple Mover
alter index CC_MaxDataTable on dbo.MaxDataTable
	Reorganize;

-- *****************************************************************
-- This time we have 4 Row Groups (notice that even those which are 100% deleted are still not removed)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Lets delete everything that is NULL or where C1 is < 5000;
delete from dbo.MaxDataTable
	where C1 is null or C1 < 5000;

-- *****************************************************************
-- This time we have almost every content deleted 
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Lets REBUILD the Columnstore Index, it should remove all deleted Row Groups
alter index CC_MaxDataTable on dbo.MaxDataTable
	REBUILD;

-- *****************************************************************
-- This time we have just 1 Compressed Row Group
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

-- *****************************************************************
-- Clean out our table
truncate table dbo.MaxDataTable;

-- Insert 2.000.000+ rows in order to get the Delta-Store full
declare @i as int;
declare @max as int;
select @max = isnull(max(C1),0) from dbo.MaxDataTable;
set @i = 1;

begin tran
while @i <= 2148576
begin
	insert into dbo.MaxDataTable
		default values

	set @i = @i + 1;
end;
commit;

checkpoint;

-- *****************************************************************
-- Analyze & play with it :)
SELECT rg.total_rows, 
	    cast(100.0*(total_rows)/1048576 as Decimal(6,3)) as PercentFull,
		cast(100-100.0*(total_rows - ISNULL(deleted_rows,0))/iif(total_rows = 0, 1, total_rows) as Decimal(6,3)) AS PercentDeleted, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	WHERE object_name(i.object_id) = 'MaxDataTable' 
	ORDER BY object_name(i.object_id), i.name, row_group_id;