/* 
 * Queries for testing SQL Server 2014 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */

-- Undocumented TF 646
-- Turn on trace, clear error log
dbcc traceon(3605,646,-1) with no_infomsgs;
dbcc errorlog with no_infomsgs;
go

-- Read error log
exec sys.xp_readerrorlog
go

-- A simple query
select C4, count(C1) 
	from dbo.MaxDataTable 
		where C8 between 1 and 50000 
	group by C4;
go

-- Turn off traces
dbcc traceoff(3605,646,-1) with no_infomsgs;
go

-- Read error log
exec sys.xp_readerrorlog
