/* 
 * Queries for testing SQL Server 2014 CTP improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 */
 
 use ContosoRetailDW;
 GO

 /* List Drop PRIMARY KEYS statements for preselected 5 tables */
 SELECT 'ALTER TABLE ' + TABLE_SCHEMA + '.[' + TABLE_NAME + '] DROP CONSTRAINT [' + CONSTRAINT_NAME + ']' as SQLStatement, *
	FROM information_schema.table_constraints
	WHERE CONSTRAINT_TYPE = 'PRIMARY KEY' and TABLE_NAME in ('FactOnlineSales','FactInventory','FactSalesQuota','FactSales','FactStrategyPlan');


 /* List Drop FOREIGN KEYS statements for preselected 5 tables */
SELECT 'ALTER TABLE ' + TABLE_SCHEMA + '.[' + TABLE_NAME + '] DROP CONSTRAINT [' + CONSTRAINT_NAME + ']' as SQLStatement, *
	FROM information_schema.table_constraints
	WHERE CONSTRAINT_TYPE = 'FOREIGN KEY' and TABLE_NAME in ('FactOnlineSales','FactInventory','FactSalesQuota','FactSales','FactStrategyPlan');
