/* A Game of Hierarchies
 * Father Queries CTE recursive
 */

/*
Copyright (c) 2017 Markus Ehrenm�ller-Jensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

use AGameOfHierarchies
go

SELECT
	ID, FirstName, FatherID, 1 Lvl
FROM
	dbo.Family

--CTE recursive
;WITH FatherTree AS (
SELECT
	ID, FirstName, FatherID, 1 Lvl
FROM
	dbo.Family
WHERE
	ID = 100 --Benjen Stark

UNION ALL

SELECT
	AGameOfHierarchies.ID, convert(varchar(50), ' | ' + AGameOfHierarchies.FirstName) FirstName, AGameOfHierarchies.FatherID, FatherTree.Lvl + 1 Lvl
FROM
	dbo.Family AGameOfHierarchies
INNER JOIN
	FatherTree ON
		FatherTree.ID = AGameOfHierarchies.FatherID
)
SELECT
	*
FROM
	FatherTree;
/*
ID          FirstName                                          FatherID    Lvl
----------- -------------------------------------------------- ----------- -----------
100         Benjen                                             NULL        1
102          | Rickon                                          100         2
104          | Cregan                                          102         3
106          | Brandon                                         104         4
108          | Beron                                           106         5
110          | William                                         108         6
112          | Edwyle                                          110         7
114          | Rickard                                         112         8
116          | Eddard                                          114         9
118          | Robb                                            116         10
120          | Sansa                                           116         10
121          | Arya                                            116         10
122          | Brandon                                         116         10
123          | Rickon                                          116         10
124          | John                                            116         10
*/

--CTE recursive, formated output
;WITH FatherTree AS (
SELECT
	ID, FirstName, FatherID, 1 Lvl
FROM
	dbo.Family
WHERE
	ID = 100 --Benjen Stark

UNION ALL

SELECT
	AGameOfHierarchies.ID, convert(varchar(50), REPLICATE(' | ', FatherTree.Lvl) + AGameOfHierarchies.FirstName) FirstName, AGameOfHierarchies.FatherID, FatherTree.Lvl + 1 Lvl
FROM
	dbo.Family AGameOfHierarchies
INNER JOIN
	FatherTree ON
		FatherTree.ID = AGameOfHierarchies.FatherID
)
SELECT
	*
FROM
	FatherTree;
/*
ID          FirstName                                          FatherID    Lvl
----------- -------------------------------------------------- ----------- -----------
100         Benjen                                             NULL        1
102          | Rickon                                          100         2
104          |  | Cregan                                       102         3
106          |  |  | Brandon                                   104         4
108          |  |  |  | Beron                                  106         5
110          |  |  |  |  | William                             108         6
112          |  |  |  |  |  | Edwyle                           110         7
114          |  |  |  |  |  |  | Rickard                       112         8
116          |  |  |  |  |  |  |  | Eddard                     114         9
118          |  |  |  |  |  |  |  |  | Robb                    116         10
120          |  |  |  |  |  |  |  |  | Sansa                   116         10
121          |  |  |  |  |  |  |  |  | Arya                    116         10
122          |  |  |  |  |  |  |  |  | Brandon                 116         10
123          |  |  |  |  |  |  |  |  | Rickon                  116         10
124          |  |  |  |  |  |  |  |  | John                    116         10
*/
