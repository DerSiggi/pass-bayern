/* A Game of Hierarchies
 * Models
 */

/*
Copyright (c) 2017 Markus Ehrenm�ller-Jensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

USE AGameOfHierarchies
GO

-- Several columns in one table (denormalized)
SELECT
	POIName,
	RegionName,
	ContinentName,
	WorldName
FROM
	dbo.POI
ORDER BY
	WorldName,
	ContinentName,
	RegionName,
	POIName;
/*
POIName            RegionName                                         ContinentName   WorldName
------------------ -------------------------------------------------- --------------- ---------------
Asshai             Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Ibben              Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Shadow Lands       Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Yi Ti              Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Astapor            Bay of Dragons                                     Essos           The Known World
Meereen            Bay of Dragons                                     Essos           The Known World
Yunkai             Bay of Dragons                                     Essos           The Known World
Vaes Dothrak       Dothraki Sea                                       Essos           The Known World
Shahadazhan        Lhazar                                             Essos           The Known World
Qarth              Qarth                                              Essos           The Known World
...
*/

--Several tables (normalized)
SELECT
	POIName,
	RegionID
FROM
	dbo.POI
ORDER BY
	POIName;
/*
POIName           RegionID
----------------- -----------
Acorn Hall        3
Antlers           6
Ashemark          4
Asshai            19
Astapor           14
Baelish Keep      2
Bandallon         8
...
*/

SELECT
	RegionName,
	ID,
	ContinentID
FROM
	dbo.Region
ORDER BY
	RegionName;
/*
RegionName                                       ID  ContinentID
------------------------------------------------ --- -----------
Asshai, the Jade Sea, and lands of the far east  19  2
Bay of Dragons                                   14  2
Beyond the Wall                                  10  1
Dorne                                            9   1
Dothraki Sea                                     15  2
Iron Islands                                     5   1
Lhazar                                           16  2
Qarth                                            18  2
Summer Islands                                   20  3
The Crownlands                                   6   1
The Free Cities                                  11  2
The North                                        1   1
The Reach                                        8   1
The Red Waste                                    17  2
The Rhoyne River                                 12  2
The Riverlands                                   3   1
The Stormlands                                   7   1
The Vale of Arryn                                2   1
The Westerlands                                  4   1
Valyrian Peninsula                               13  2
*/

SELECT
	POI.POIName,
	Region.RegionName,
	Continent.ContinentName,
	World.WorldName
FROM
	dbo.POI
INNER JOIN
	dbo.Region on
		Region.ID=POI.RegionID
INNER JOIN
	dbo.Continent on
		Continent.ID=Region.ContinentID
INNER JOIN
	dbo.World on
		World.ID=Continent.WorldID
ORDER BY
	World.WorldName,
	Continent.ContinentName,
	Region.RegionName,
	POI.POIName;
/*
POIName            RegionName                                         ContinentName   WorldName
------------------ -------------------------------------------------- --------------- ---------------
Asshai             Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Ibben              Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Shadow Lands       Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Yi Ti              Asshai, the Jade Sea, and lands of the far east    Essos           The Known World
Astapor            Bay of Dragons                                     Essos           The Known World
Meereen            Bay of Dragons                                     Essos           The Known World
Yunkai             Bay of Dragons                                     Essos           The Known World
Vaes Dothrak       Dothraki Sea                                       Essos           The Known World
Shahadazhan        Lhazar                                             Essos           The Known World
Qarth              Qarth                                              Essos           The Known World
...
*/
