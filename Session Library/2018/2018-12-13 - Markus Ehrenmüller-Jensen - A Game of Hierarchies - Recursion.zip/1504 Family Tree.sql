/* A Game of Hierarchies
 * Family Tree
 */

/*
Copyright (c) 2017 Markus Ehrenm�ller-Jensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

use AGameOfHierarchies
go

--
--Male ancestors of Robb Stark
--
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  SELECT ID, FatherID, FirstName, 0 AS FatherLvl 
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  SELECT father.ID, father.FatherID, father.FirstName, child.FatherLvl + 1
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS father
      ON child.FatherID = father.ID
)
SELECT ID, FatherID, FirstName, FatherLvl
FROM Ancestors
ORDER BY
	FatherLvl desc;
/*
ID          FatherID    FirstName                                          FatherLvl
----------- ----------- -------------------------------------------------- -----------
100         NULL        Benjen                                             9
102         100         Rickon                                             8
104         102         Cregan                                             7
106         104         Brandon                                            6
108         106         Beron                                              5
110         108         William                                            4
112         110         Edwyle                                             3
114         112         Rickard                                            2
116         114         Eddard                                             1
118         116         Robb                                               0
*/

--
--Female ancestors of Robb Stark
--
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  SELECT ID, MotherID, FirstName, 0 AS MotherLvl 
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  SELECT mother.ID, mother.MotherID, mother.FirstName, child.motherLvl + 1
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS mother
      ON child.MotherID = mother.ID
)
SELECT ID, MotherID, FirstName, MotherLvl
FROM Ancestors
ORDER BY
	MotherLvl desc;
/*
ID          MotherID    FirstName                                          MotherLvl
----------- ----------- -------------------------------------------------- -----------
131         NULL        Minisa                                             2
117         131         Catelyn                                            1
118         117         Robb                                               0
*/

--
-- combine Father- & Mother-Query
--
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  --Root
  SELECT ID, FatherID, MotherID, FirstName, 0 AS FatherLvl, 0 as MotherLvl
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  --Father
  SELECT father.ID, father.FatherID, father.MotherID, father.FirstName, child.FatherLvl + 1, child.MotherLvl +1
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS father
      ON child.FatherID = father.ID

  UNION ALL

  --Mother
  SELECT mother.ID, mother.FatherID, mother.MotherID, mother.FirstName, child.FatherLvl + 1, child.MotherLvl + 1
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS mother
      ON child.MotherID = mother.ID
)
SELECT ID, FatherID, MotherID, FirstName, FatherLvl, MotherLvl
FROM Ancestors
ORDER BY
	FatherLvl desc;
/*
ID          FatherID    MotherID    FirstName                                          FatherLvl   MotherLvl
----------- ----------- ----------- -------------------------------------------------- ----------- -----------
100         NULL        NULL        Benjen                                             9           9
101         NULL        NULL        Lysa                                               9           9
102         100         101         Rickon                                             8           8
103         NULL        NULL        Gilliane                                           8           8
104         102         103         Cregan                                             7           7
105         NULL        NULL        Lynara                                             7           7
106         104         105         Brandon                                            6           6
107         NULL        NULL        Alys                                               6           6
108         106         107         Beron                                              5           5
109         NULL        NULL        Lorra                                              5           5
110         108         109         William                                            4           4
111         NULL        NULL        Melantha                                           4           4
132         NULL        NULL        ???                                                3           3
112         110         111         Edwyle                                             3           3
113         NULL        NULL        Marna                                              3           3
114         112         113         Rickard                                            2           2
115         NULL        NULL        Lyarra                                             2           2
130         132         NULL        Hoster                                             2           2
131         NULL        NULL        Minisa                                             2           2
116         114         115         Eddard                                             1           1
117         130         131         Catelyn                                            1           1
118         116         117         Robb                                               0           0
*/

-- adding Paths
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  --Root
  SELECT ID, FatherID, MotherID, FirstName, 0 AS FatherLvl, 0 as MotherLvl, 
  convert(varchar(512), FirstName) FamilyTreePath
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  --Father
  SELECT father.ID, father.FatherID, father.MotherID, father.FirstName, child.FatherLvl + 1, child.MotherLvl +1, 
  convert(varchar(512), FamilyTreePath + ' -> father: ' + father.FirstName) FamilyTreePath
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS father
      ON child.FatherID = father.ID

  UNION ALL

  --Mother
  SELECT mother.ID, mother.FatherID, mother.MotherID, mother.FirstName, child.FatherLvl + 1, child.MotherLvl + 1, 
  convert(varchar(512), FamilyTreePath + ' -> mother: ' + mother.FirstName) FamilyTreePath
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS mother
      ON child.MotherID = mother.ID
)
SELECT ID, FatherID, MotherID, FirstName, FatherLvl, MotherLvl, FamilyTreePath
FROM Ancestors
ORDER BY
	FatherLvl desc;
/*
ID          FatherID    MotherID    FirstName                                          FatherLvl   MotherLvl   FamilyTreePath
----------- ----------- ----------- -------------------------------------------------- ----------- ----------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
100         NULL        NULL        Benjen                                             9           9           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon -> father: Benjen
101         NULL        NULL        Lysa                                               9           9           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon -> mother: Lysa
102         100         101         Rickon                                             8           8           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon
103         NULL        NULL        Gilliane                                           8           8           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> mother: Gilliane
104         102         103         Cregan                                             7           7           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan
105         NULL        NULL        Lynara                                             7           7           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> mother: Lynara
106         104         105         Brandon                                            6           6           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon
107         NULL        NULL        Alys                                               6           6           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> mother: Alys
108         106         107         Beron                                              5           5           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron
109         NULL        NULL        Lorra                                              5           5           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> mother: Lorra
110         108         109         William                                            4           4           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William
111         NULL        NULL        Melantha                                           4           4           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> mother: Melantha
132         NULL        NULL        ???                                                3           3           Robb -> mother: Catelyn -> father: Hoster -> father: ???
112         110         111         Edwyle                                             3           3           Robb -> father: Eddard -> father: Rickard -> father: Edwyle
113         NULL        NULL        Marna                                              3           3           Robb -> father: Eddard -> father: Rickard -> mother: Marna
114         112         113         Rickard                                            2           2           Robb -> father: Eddard -> father: Rickard
115         NULL        NULL        Lyarra                                             2           2           Robb -> father: Eddard -> mother: Lyarra
130         132         NULL        Hoster                                             2           2           Robb -> mother: Catelyn -> father: Hoster
131         NULL        NULL        Minisa                                             2           2           Robb -> mother: Catelyn -> mother: Minisa
116         114         115         Eddard                                             1           1           Robb -> father: Eddard
117         130         131         Catelyn                                            1           1           Robb -> mother: Catelyn
118         116         117         Robb                                               0           0           Robb
*/

-- adding Sort
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  --Root
  SELECT ID, FatherID, MotherID, FirstName, 0 AS FatherLvl, 0 as MotherLvl, 
  convert(varchar(512), FirstName) FamilyTreePath,
  convert(varchar(15), '2') Sort
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  --Father
  SELECT father.ID, father.FatherID, father.MotherID, father.FirstName, child.FatherLvl + 1, child.MotherLvl +1, 
  convert(varchar(512), FamilyTreePath + ' -> father: ' + father.FirstName) FamilyTreePath,
  convert(varchar(15), Sort + '1') Sort
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS father
      ON child.FatherID = father.ID

  UNION ALL

  --Mother
  SELECT mother.ID, mother.FatherID, mother.MotherID, mother.FirstName, child.FatherLvl + 1, child.MotherLvl + 1, 
  convert(varchar(512), FamilyTreePath + ' -> mother: ' + mother.FirstName) FamilyTreePath,
  convert(varchar(15), Sort + '3') Sort
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS mother
      ON child.MotherID = mother.ID
)
SELECT ID, FatherID, MotherID, FirstName, FatherLvl, MotherLvl, Sort, FamilyTreePath
FROM Ancestors
ORDER BY
	Sort + '222222222222222';
/*
ID          FatherID    MotherID    FirstName                                          FatherLvl   MotherLvl   Sort            FamilyTreePath
----------- ----------- ----------- -------------------------------------------------- ----------- ----------- --------------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
100         NULL        NULL        Benjen                                             9           9           2111111111      Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon -> father: Benjen
102         100         101         Rickon                                             8           8           211111111       Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon
101         NULL        NULL        Lysa                                               9           9           2111111113      Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> father: Rickon -> mother: Lysa
104         102         103         Cregan                                             7           7           21111111        Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan
103         NULL        NULL        Gilliane                                           8           8           211111113       Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> father: Cregan -> mother: Gilliane
106         104         105         Brandon                                            6           6           2111111         Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon
105         NULL        NULL        Lynara                                             7           7           21111113        Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> father: Brandon -> mother: Lynara
108         106         107         Beron                                              5           5           211111          Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron
107         NULL        NULL        Alys                                               6           6           2111113         Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> father: Beron -> mother: Alys
110         108         109         William                                            4           4           21111           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William
109         NULL        NULL        Lorra                                              5           5           211113          Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> father: William -> mother: Lorra
112         110         111         Edwyle                                             3           3           2111            Robb -> father: Eddard -> father: Rickard -> father: Edwyle
111         NULL        NULL        Melantha                                           4           4           21113           Robb -> father: Eddard -> father: Rickard -> father: Edwyle -> mother: Melantha
114         112         113         Rickard                                            2           2           211             Robb -> father: Eddard -> father: Rickard
113         NULL        NULL        Marna                                              3           3           2113            Robb -> father: Eddard -> father: Rickard -> mother: Marna
116         114         115         Eddard                                             1           1           21              Robb -> father: Eddard
115         NULL        NULL        Lyarra                                             2           2           213             Robb -> father: Eddard -> mother: Lyarra
118         116         117         Robb                                               0           0           2               Robb
132         NULL        NULL        ???                                                3           3           2311            Robb -> mother: Catelyn -> father: Hoster -> father: ???
130         132         NULL        Hoster                                             2           2           231             Robb -> mother: Catelyn -> father: Hoster
117         130         131         Catelyn                                            1           1           23              Robb -> mother: Catelyn
131         NULL        NULL        Minisa                                             2           2           233             Robb -> mother: Catelyn -> mother: Minisa
*/

-- adding full name & layout
DECLARE @ID AS INT = 118; --Robb Stark

WITH Ancestors
AS
(
  --Root
  SELECT ID, FatherID, MotherID, FirstName, Titles, LastName, 0 AS Lvl, 
  convert(varchar(512), FirstName) FamilyTreePath,
  convert(varchar(10), 'Child: ') as FatherMother,
  convert(varchar(512), '2') Sort
  FROM dbo.Family
  WHERE ID = @ID

  UNION ALL

  --Father
  SELECT father.ID, father.FatherID, father.MotherID, father.FirstName, father.Titles, father.LastName, Lvl +1 Lvl,
  convert(varchar(512), FamilyTreePath + ' -> father: ' + father.FirstName) FamilyTreePath,
  convert(varchar(10), 'Father:') as FatherMother,
  convert(varchar(512), Sort + '1') Sort
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS father
      ON child.FatherID = father.ID

  UNION ALL

  --Mother
  SELECT mother.ID, mother.FatherID, mother.MotherID, mother.FirstName, mother.Titles, mother.LastName, Lvl + 1 Lvl,
  convert(varchar(512), FamilyTreePath + ' -> mother: ' + mother.FirstName) FamilyTreePath,
  convert(varchar(10), 'Mother:') as FatherMother,
  convert(varchar(512), Sort + '3') Sort
  FROM Ancestors AS child
    INNER JOIN dbo.Family AS mother
      ON child.MotherID = mother.ID
)
SELECT
	CASE WHEN LEFT(Sort, 2)=21
		THEN
		CASE WHEN Lvl >= MIN(LvL) OVER(ORDER BY Sort + '222222222222222' ROWS BETWEEN UNBOUNDED PRECEDING AND 2 PRECEDING)
			  THEN isnull(REPLICATE('    ', Lvl-2) + '   |', '')
			  ELSE isnull(REPLICATE('    ', Lvl-2) + '    ', '')
			  END + '   ' + FatherMother + ' ' 
		 ELSE
		CASE WHEN Lvl >= MAX(LvL) OVER(ORDER BY Sort + '222222222222222' ROWS BETWEEN 2 FOLLOWING AND UNBOUNDED FOLLOWING )
			  THEN isnull(REPLICATE('   |', Lvl-1), '')
			  ELSE isnull(REPLICATE('    ', Lvl-1), '')
			  END + '   ' + FatherMother + ' ' 
		 END
		 + FirstName + case when Titles <> '' then ' "' + Titles + '" ' else ' ' end + LastName as FamilyTree
FROM Ancestors
ORDER BY
	Sort + '222222222222222';
/*
FamilyTree
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                   Father: Benjen Stark
                               Father: Rickon Stark
                               |   Mother: Lysa Locke
                           Father: Cregan "The Old Man Of The North" Stark
                           |   Mother: Gilliane Glover
                       Father: Brandon Stark
                       |   Mother: Lynara Stark
                   Father: Beron Stark
                   |   Mother: Alys Karstark
               Father: William Stark
               |   Mother: Lorra Royce
           Father: Edwyle Stark
           |   Mother: Melantha Blackwood
       Father: Rickard Stark
       |   Mother: Marna Locke
   Father: Eddard Stark
   |   Mother: Lyarra Stark
   Child:  Robb "The Young Wolf" Stark
   |   |   Father: ??? Tully
   |   Father: Hoster Tully
   Mother: Catelyn "Lady Stoneheart" Tully
       Mother: Minisa Whent
*/
