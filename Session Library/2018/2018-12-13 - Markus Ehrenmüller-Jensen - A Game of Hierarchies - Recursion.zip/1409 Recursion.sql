/* A Game of Hierarchies
 * Recursion
 */

/*
Copyright (c) 2017 Markus Ehrenm�ller-Jensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

USE AGameOfHierarchies
GO

-- Procedures, which counts up
CREATE OR ALTER PROCEDURE dbo.CountUpProc 
	(@i int)
AS
BEGIN

PRINT	@i; 
SET		@i += 1; 
EXEC	dbo.CountUpProc @i; 

END; 
GO 

EXEC dbo.CountUpProc 1;
GO
/*
1
2
3
...
30
31
32
Msg 217, Level 16, State 1, Procedure dbo.CountUpProc, Line 10 [Batch Start Line 41]
Maximum stored procedure, function, trigger, or view nesting level exceeded (limit 32).

*/

-- Procedures, which counts down
CREATE OR ALTER PROCEDURE dbo.CountDownProc 
	(@i int)
AS
BEGIN

PRINT	@i; 

IF	@i = 1
	RETURN
ELSE
	SET		@i -= 1; 
	EXEC	dbo.CountDownProc @i; 
END; 

GO 

EXEC dbo.CountDownProc 32;
GO
/*
32
31
30
...
3
2
1
*/

-- Function, which sums up
CREATE OR ALTER FUNCTION dbo.SumUpFunc 
	(@i int)
RETURNS int
BEGIN

IF	@i = 1
	RETURN 1;
ELSE
	SET		@i -= 1; 
	RETURN	@i+1+dbo.SumUpFunc(@i); 
END; 

GO 

SELECT dbo.SumUpFunc(10);
--55
SELECT dbo.SumUpFunc(32);
--528
SELECT dbo.SumUpFunc(100);
/*
Msg 217, Level 16, State 1, Line 104
Maximum stored procedure, function, trigger, or view nesting level exceeded (limit 32).
*/


-- CTE, which counts up
;WITH CountUp AS (
SELECT
	1 i

UNION ALL

SELECT
	i + 1
FROM
	CountUp
)
SELECT
	*
FROM
	CountUp

--OPTION (MAXRECURSION 32)
--OPTION (MAXRECURSION 100)
OPTION (MAXRECURSION 32767)
--OPTION (MAXRECURSION 32768)
--OPTION (MAXRECURSION 0)
;


-- CTE, which counts up
-- limit in SELECT
;WITH CountUp AS (
SELECT
	1 i

UNION ALL

SELECT
	i + 1
FROM
	CountUp
)
SELECT
	*
FROM
	CountUp
WHERE
	i < 99
;
/*
Msg 530, Level 16, State 1, Line 112
The statement terminated. The maximum recursion 100 has been exhausted before statement completion.
*/

-- CTE, which counts up
-- limit in CTE
;WITH CountUp AS (
SELECT
	1 i

UNION ALL

SELECT
	i + 1
FROM
	CountUp
WHERE
	i < 100
)
SELECT
	*
FROM
	CountUp
;

-- CTE, which sums up
-- limit in CTE
;WITH SumUp AS (
SELECT
	10 i, 10 SumUp

UNION ALL

SELECT
	i-1 i, SumUp + (i-1) SumUp
FROM
	SumUp
WHERE
	i < 100 and
	i > 1
)
SELECT
	*
	--max(SumUp)
FROM
	SumUp
;
