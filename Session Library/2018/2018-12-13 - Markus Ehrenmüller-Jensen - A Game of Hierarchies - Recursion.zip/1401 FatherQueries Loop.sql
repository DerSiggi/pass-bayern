/* A Game of Hierarchies
 * Father Queries Loop
 */

/*
Copyright (c) 2017 Markus Ehrenm�ller-Jensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

use [AGameOfHierarchies]
go

--descendants
IF OBJECT_ID(N'dbo.descendants', N'TF') IS NOT NULL DROP FUNCTION dbo.descendants;
GO
CREATE FUNCTION dbo.descendants(@root AS INT) 
RETURNS @descendants Table
(
  ID	INT NOT NULL PRIMARY KEY NONCLUSTERED,
  FatherLvl	INT NOT NULL,
  UNIQUE CLUSTERED(FatherLvl, ID)   -- Index will be used to filter level
)
AS
BEGIN
  DECLARE @FatherLvl AS INT = 0; -- Initialize level counter with 0

  -- Insert root node to @descendants
  INSERT INTO @descendants(ID, FatherLvl)
    SELECT	ID, @FatherLvl 
	FROM	dbo.Family 
	WHERE	ID = @root;

  WHILE @@rowcount > 0 -- while previous level had rows
  BEGIN
    SET @FatherLvl += 1; -- Increment level counter

    -- Insert next level of subordinates to @descendants
    INSERT INTO @descendants(ID, FatherLvl)
      SELECT child.ID, @FatherLvl
      FROM @descendants AS father
        INNER JOIN dbo.Family AS child 
          ON father.FatherLvl = @FatherLvl - 1 -- Filter father from previous level
             AND child.FatherID = father.ID;
  END

  RETURN;
END
GO

--
--Tree of Family Stark
--
SELECT AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl
FROM 
	dbo.descendants(100) descendants -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID;
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
100         Benjen                                             NULL        0
102         Rickon                                             100         1
104         Cregan                                             102         2
106         Brandon                                            104         3
108         Beron                                              106         4
110         William                                            108         5
112         Edwyle                                             110         6
114         Rickard                                            112         7
116         Eddard                                             114         8
118         Robb                                               116         9
120         Sansa                                              116         9
121         Arya                                               116         9
122         Brandon                                            116         9
123         Rickon                                             116         9
124         John                                               116         9
*/

--formated output
SELECT AGameOfHierarchies.ID, REPLICATE(' | ', descendants.FatherLvl) + AGameOfHierarchies.FirstName FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl
FROM 
	dbo.descendants(100) descendants -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID;
/*
ID                                                  FatherID    FatherLvl
----------- --------------------------------------- ----------- -----------
100         Benjen                                  NULL        0
102          | Rickon                               100         1
104          |  | Cregan                            102         2
106          |  |  | Brandon                        104         3
108          |  |  |  | Beron                       106         4
110          |  |  |  |  | William                  108         5
112          |  |  |  |  |  | Edwyle                110         6
114          |  |  |  |  |  |  | Rickard            112         7
116          |  |  |  |  |  |  |  | Eddard          114         8
118          |  |  |  |  |  |  |  |  | Robb         116         9
120          |  |  |  |  |  |  |  |  | Sansa        116         9
121          |  |  |  |  |  |  |  |  | Arya         116         9
122          |  |  |  |  |  |  |  |  | Brandon      116         9
123          |  |  |  |  |  |  |  |  | Rickon       116         9
124          |  |  |  |  |  |  |  |  | John         116         9
*/

--
--Last decendents = youngest generation
--

SELECT AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, father.FatherLvl
FROM 
	dbo.descendants(100) as father -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = father.ID
WHERE 
	NOT EXISTS --where not exists children = where no other member has me as a father
	  (SELECT top 1 1 FROM dbo.Family AS child
	   WHERE child.FatherID = father.ID);
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
118         Robb                                               116         9
120         Sansa                                              116         9
121         Arya                                               116         9
122         Brandon                                            116         9
123         Rickon                                             116         9
124         John                                               116         9
*/

--introducing parameter Max-Level
IF OBJECT_ID(N'dbo.descendants', N'TF') IS NOT NULL DROP FUNCTION dbo.descendants;
GO
CREATE FUNCTION dbo.descendants(@root AS INT, @maxlevels AS INT = NULL) 
RETURNS @descendants Table
(
  ID	INT NOT NULL PRIMARY KEY NONCLUSTERED,
  FatherLvl	INT NOT NULL,
  UNIQUE CLUSTERED(FatherLvl, ID)   -- Index will be used to filter level
)
AS
BEGIN
  DECLARE @FatherLvl AS INT = 0;            -- Initialize level counter with 0

  -- Insert root node to @descendants
  INSERT INTO @descendants(ID, FatherLvl)
    SELECT ID, @FatherLvl FROM dbo.Family WHERE ID = @root;

  WHILE @@rowcount > 0                -- while previous level had rows
    AND (@FatherLvl < @maxlevels      -- and haven't reached level limit
         OR @maxlevels IS NULL)       
  BEGIN
    SET @FatherLvl += 1;              -- Increment level counter

    -- Insert next level of subordinates to @descendants
    INSERT INTO @descendants(ID, FatherLvl)
      SELECT child.ID, @FatherLvl
      FROM @descendants AS father
        INNER JOIN dbo.Family AS child 
          ON father.FatherLvl = @FatherLvl - 1         -- Filter father from previous level
             AND child.FatherID = father.ID;
  END

  RETURN;
END
GO

--
--Tree of Family Stark
--
SELECT AGameOfHierarchies.ID, REPLICATE(' | ', descendants.FatherLvl) + AGameOfHierarchies.FirstName FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl
FROM 
	dbo.descendants(100, null) as descendants -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID;
/*
ID                                                 FatherID    FatherLvl
----------- -------------------------------------- ----------- -----------
100         Benjen                                 NULL        0
102          | Rickon                              100         1
104          |  | Cregan                           102         2
106          |  |  | Brandon                       104         3
108          |  |  |  | Beron                      106         4
110          |  |  |  |  | William                 108         5
112          |  |  |  |  |  | Edwyle               110         6
114          |  |  |  |  |  |  | Rickard           112         7
116          |  |  |  |  |  |  |  | Eddard         114         8
118          |  |  |  |  |  |  |  |  | Robb        116         9
120          |  |  |  |  |  |  |  |  | Sansa       116         9
121          |  |  |  |  |  |  |  |  | Arya        116         9
122          |  |  |  |  |  |  |  |  | Brandon     116         9
123          |  |  |  |  |  |  |  |  | Rickon      116         9
124          |  |  |  |  |  |  |  |  | John        116         9
*/

--
--Tree of two generations of Stark
--
SELECT AGameOfHierarchies.ID, REPLICATE(' | ', descendants.FatherLvl) + AGameOfHierarchies.FirstName FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl
FROM 
	dbo.descendants(114, 2) as descendants -- Rickard Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID;
/*
ID                             FatherID    FatherLvl
----------- ------------------ ----------- -----------
114         Rickard            112         0
116          | Eddard          114         1
118          |  | Robb         116         2
120          |  | Sansa        116         2
121          |  | Arya         116         2
122          |  | Brandon      116         2
123          |  | Rickon       116         2
124          |  | John         116         2
*/

--
--Grandchildren of Rickard Stark only
--
SELECT AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl
FROM 
	dbo.descendants(114, 2) as descendants -- Rickard Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID
WHERE
	descendants.FatherLvl = 2;
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
118         Robb                                               116         2
120         Sansa                                              116         2
121         Arya                                               116         2
122         Brandon                                            116         2
123         Rickon                                             116         2
124         John                                               116         2
*/

--
--Ancestors
--
IF OBJECT_ID(N'dbo.Ancestors', N'TF') IS NOT NULL DROP FUNCTION dbo.Ancestors;
GO
CREATE FUNCTION dbo.Ancestors
  (@ID AS INT, @MaxLevels AS INT = NULL) 
RETURNS @Ancestors TABLE
(
  ID		INT NOT NULL PRIMARY KEY,
  FatherLvl	INT NOT NULL
)
AS
BEGIN
  IF NOT EXISTS(SELECT * FROM dbo.Family WHERE ID = @ID)
    RETURN;  

  DECLARE @FatherLvl AS INT = 0;      -- Initialize level counter with 0

  WHILE @ID IS NOT NULL				  -- while current father has a child
    AND (@FatherLvl <= @MaxLevels     -- and haven't reached level limit
         OR @MaxLevels IS NULL)       
  BEGIN
    -- Insert current father to @Ancestors
    INSERT INTO @Ancestors(ID, FatherLvl) 
	VALUES(@ID, @FatherLvl);
    SET @FatherLvl += 1;              -- Increment level counter
    -- Get next level father
    SET @ID = (SELECT FatherID FROM dbo.Family WHERE ID=@ID);
  END

  RETURN;
END
GO

--Ancestors of Edward Stark
SELECT
	AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, Ancestors.FatherLvl
FROM
	dbo.Ancestors(116,null) Ancestors
	INNER JOIN dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = Ancestors.ID;
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
100         Benjen                                             NULL        8
102         Rickon                                             100         7
104         Cregan                                             102         6
106         Brandon                                            104         5
108         Beron                                              106         4
110         William                                            108         3
112         Edwyle                                             110         2
114         Rickard                                            112         1
116         Eddard                                             114         0
*/

--Ancestors of Edward Stark only up to his grandfather
SELECT
	AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, Ancestors.FatherLvl
FROM
	dbo.Ancestors(116,2) Ancestors
INNER JOIN 	dbo.Family AGameOfHierarchies on
	AGameOfHierarchies.ID = Ancestors.ID;
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
112         Edwyle                                             110         2
114         Rickard                                            112         1
116         Eddard                                             114         0
*/

--Show only grandfather of Edward Stark
SELECT
	AGameOfHierarchies.ID, AGameOfHierarchies.FirstName, AGameOfHierarchies.FatherID, Ancestors.FatherLvl
FROM
	dbo.Ancestors(116,2) Ancestors
INNER JOIN dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = Ancestors.ID
WHERE
	Ancestors.FatherLvl = 2;
/*
ID          FirstName                                          FatherID    FatherLvl
----------- -------------------------------------------------- ----------- -----------
112         Edwyle                                             110         2
*/

--introducing path
IF OBJECT_ID(N'dbo.descendants', N'TF') IS NOT NULL DROP FUNCTION dbo.descendants;
GO
CREATE FUNCTION dbo.descendants(@root AS INT, @maxlevels AS INT = NULL) RETURNS @descendants Table
(
  ID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
  FatherLvl		INT NOT NULL,
  FatherPath	VARCHAR(896) NOT NULL,
  UNIQUE CLUSTERED(FatherLvl, ID)   -- Index will be used to filter level
)
AS
BEGIN
  DECLARE @FatherLvl AS INT = 0;            -- Initialize level counter with 0

  -- Insert root node to @descendants
  INSERT INTO @descendants(ID, FatherLvl, FatherPath)
    SELECT ID, @FatherLvl, '.' + CAST(ID AS VARCHAR(10)) + '.' 
	FROM dbo.Family 
	WHERE ID = @root;

  WHILE @@rowcount > 0                -- while previous level had rows
    AND (@FatherLvl < @maxlevels            -- and haven't reached level limit
         OR @maxlevels IS NULL)       
  BEGIN
    SET @FatherLvl += 1;                    -- Increment level counter

    -- Insert next level of subordinates to @descendants
    INSERT INTO @descendants(ID, FatherLvl, FatherPath)
      SELECT child.ID, @FatherLvl, 
	  father.FatherPath + CAST(child.ID AS VARCHAR(10)) + '.'
      FROM @descendants AS father
        INNER JOIN dbo.Family AS child 
          ON father.FatherLvl = @FatherLvl - 1         -- Filter father from previous level
             AND child.FatherID = father.ID;
  END

  RETURN;
END
GO

--formated output
SELECT AGameOfHierarchies.ID, REPLICATE(' | ', descendants.FatherLvl) + AGameOfHierarchies.FirstName FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl, descendants.FatherPath
FROM 
	dbo.descendants(100, null) descendants -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID;
/*
ID                                        FatherID    FatherLvl   FatherPath
---- ------------------------------------ ----------- ----------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
100  Benjen                               NULL        0           .100.
102   | Rickon                            100         1           .100.102.
104   |  | Cregan                         102         2           .100.102.104.
106   |  |  | Brandon                     104         3           .100.102.104.106.
108   |  |  |  | Beron                    106         4           .100.102.104.106.108.
110   |  |  |  |  | William               108         5           .100.102.104.106.108.110.
112   |  |  |  |  |  | Edwyle             110         6           .100.102.104.106.108.110.112.
114   |  |  |  |  |  |  | Rickard         112         7           .100.102.104.106.108.110.112.114.
116   |  |  |  |  |  |  |  | Eddard       114         8           .100.102.104.106.108.110.112.114.116.
118   |  |  |  |  |  |  |  |  | Robb      116         9           .100.102.104.106.108.110.112.114.116.118.
120   |  |  |  |  |  |  |  |  | Sansa     116         9           .100.102.104.106.108.110.112.114.116.120.
121   |  |  |  |  |  |  |  |  | Arya      116         9           .100.102.104.106.108.110.112.114.116.121.
122   |  |  |  |  |  |  |  |  | Brandon   116         9           .100.102.104.106.108.110.112.114.116.122.
123   |  |  |  |  |  |  |  |  | Rickon    116         9           .100.102.104.106.108.110.112.114.116.123.
124   |  |  |  |  |  |  |  |  | John      116         9           .100.102.104.106.108.110.112.114.116.124.
*/

--introducing sort
IF OBJECT_ID(N'dbo.descendants', N'TF') IS NOT NULL DROP FUNCTION dbo.descendants;
GO
CREATE FUNCTION dbo.descendants(@root AS INT, @maxlevels AS INT = NULL) RETURNS @descendants Table
(
  ID			INT NOT NULL PRIMARY KEY NONCLUSTERED,
  FatherLvl		INT NOT NULL,
  FatherPath	VARCHAR(896) NOT NULL,
  Sort			VARBINARY(MAX),
  UNIQUE CLUSTERED(FatherLvl, ID)   -- Index will be used to filter level
)
AS
BEGIN
  DECLARE @FatherLvl AS INT = 0;            -- Initialize level counter with 0

  -- Insert root node to @descendants
  INSERT INTO @descendants(ID, FatherLvl, FatherPath, sort)
    SELECT ID, @FatherLvl, '.' + CAST(ID AS VARCHAR(10)) + '.' ,
	CAST(CAST(1 AS BINARY(4)) AS VARBINARY(MAX)) AS sort
	FROM dbo.Family 
	WHERE ID = @root;

  WHILE @@rowcount > 0                -- while previous level had rows
    AND (@FatherLvl < @maxlevels            -- and haven't reached level limit
         OR @maxlevels IS NULL)       
  BEGIN
    SET @FatherLvl += 1;                    -- Increment level counter

    -- Insert next level of subordinates to @descendants
    INSERT INTO @descendants(ID, FatherLvl, FatherPath, sort)
      SELECT child.ID, @FatherLvl, father.FatherPath + CAST(child.ID AS VARCHAR(10)) + '.',
			--sort by FirstName
			father.sort + CAST(ROW_NUMBER() OVER(PARTITION BY child.FatherID ORDER BY child.FirstName) AS BINARY(4))
      FROM @descendants AS father
        INNER JOIN dbo.Family AS child 
          ON father.FatherLvl = @FatherLvl - 1         -- Filter father from previous level
             AND child.FatherID = father.ID;
  END

  RETURN;
END
GO

--formated output
SELECT AGameOfHierarchies.ID, REPLICATE(' | ', descendants.FatherLvl) + AGameOfHierarchies.FirstName FirstName, AGameOfHierarchies.FatherID, descendants.FatherLvl, descendants.FatherPath, descendants.sort
FROM 
	dbo.descendants(100, null) descendants -- Benjen Stark
	inner join dbo.Family AGameOfHierarchies on
		AGameOfHierarchies.ID = descendants.ID
ORDER BY
	descendants.sort;
/*
ID                                               FatherID    FatherLvl   FatherPath
----------- ------------------------------------ ----------- ----------- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
100         Benjen                               NULL        0           .100.
102          | Rickon                            100         1           .100.102.
104          |  | Cregan                         102         2           .100.102.104.
106          |  |  | Brandon                     104         3           .100.102.104.106.
108          |  |  |  | Beron                    106         4           .100.102.104.106.108.
110          |  |  |  |  | William               108         5           .100.102.104.106.108.110.
112          |  |  |  |  |  | Edwyle             110         6           .100.102.104.106.108.110.112.
114          |  |  |  |  |  |  | Rickard         112         7           .100.102.104.106.108.110.112.114.
116          |  |  |  |  |  |  |  | Eddard       114         8           .100.102.104.106.108.110.112.114.116.
121          |  |  |  |  |  |  |  |  | Arya      116         9           .100.102.104.106.108.110.112.114.116.121.
122          |  |  |  |  |  |  |  |  | Brandon   116         9           .100.102.104.106.108.110.112.114.116.122.
124          |  |  |  |  |  |  |  |  | John      116         9           .100.102.104.106.108.110.112.114.116.124.
123          |  |  |  |  |  |  |  |  | Rickon    116         9           .100.102.104.106.108.110.112.114.116.123.
118          |  |  |  |  |  |  |  |  | Robb      116         9           .100.102.104.106.108.110.112.114.116.118.
120          |  |  |  |  |  |  |  |  | Sansa     116         9           .100.102.104.106.108.110.112.114.116.120.

*/

