﻿# run in single step; Presentation Mode
Exit

#region Install
$DockerMinimumVersion = '17.06.1-ee-1'
$NuGetPackageProviderVersion = '2.8.5.201'

if (!Get-Service -Name docker) {
    if (!(Get-PackageProvider -Name "NuGet")) {
        Install-PackageProvider -Name "NuGet" -MinimumVersion $NuGetPackageProviderVersion -Force
    }

    if (!(Get-Module -Name "DockerMsftProvider" -ListAvailable)) {
        Install-Module -Name "DockerMsftProvider" -Repository PSGallery -Force
    }

    # notepad "C:\Program Files\WindowsPowerShell\Modules\DockerMsftProvider\1.0.0.1\DockerMsftProvider.psm1"
    # https://dockermsft.blob.core.windows.net/dockercontainer/DockerMsftIndex.json 
    Get-Package Docker* | select *
    Install-Package -Name docker -ProviderName DockerMsftProvider -MinimumVersion $DockerMinimumVersion -Force

    Restart-Computer -Force
}

#Alternative install with DSC
if (!Get-Service -Name docker) {
    Install-Script -Name Install-DockerOnWS2016UsingDSC
    Install-DockerOnWS2016UsingDSC.ps1
}

#Install manually https://mobyproject.org/
$version = (Invoke-WebRequest -UseBasicParsing https://raw.githubusercontent.com/docker/docker/master/VERSION).Content.Trim()
Invoke-WebRequest "https://master.dockerproject.org/windows/x86_64/docker-$($version).zip" -OutFile "$env:TEMP\docker.zip" -UseBasicParsing
Expand-Archive -Path "$env:TEMP\docker.zip" -DestinationPath $env:ProgramFiles
$env:path += ";$env:ProgramFiles\Docker"
$existingMachinePath = [Environment]::GetEnvironmentVariable("Path",[System.EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable("Path", $existingMachinePath + ";$env:ProgramFiles\Docker", [EnvironmentVariableTarget]::Machine)
dockerd --register-service
Start-Service Docker

# Docker CE für Win10: https://docs.docker.com/docker-for-windows/install/#install-docker-for-windows
# https://download.docker.com/win/stable/Docker%20for%20Windows%20Installer.exe
# docker service and docker client will be installed
# hyperV will be activated --> required multiple reboots
# doesn't work under Windows Server

# linux Container in Windows Server 2016
https://blog.docker.com/2017/09/preview-linux-containers-on-windows/
https://github.com/linuxkit
#endregion Install

#region UninstallDocker
Uninstall-Package -Name "Docker" -ProviderName "DockerMsftProvider" -Force
Uninstall-Module -Name "DockerMsftProvider" -Force
$service = Get-WmiObject -Class Win32_Service -Filter "Name='docker'"
if ($service) { $service.StopService() }
if ($service) { $service.Delete() }
Stop-Process -Name docker, dockerd
Start-Sleep -s 5
Remove-Item -Recurse -Force "~/AppData/Local/Docker"
Remove-Item -Recurse -Force "~/AppData/Roaming/Docker"
if (Test-Path "C:\ProgramData\Docker") { takeown.exe /F "C:\ProgramData\Docker" /R /A /D Y }
if (Test-Path "C:\ProgramData\Docker") { icacls "C:\ProgramData\Docker\" /T /C /grant Administrators:F }
Remove-Item -Path "C:\ProgramData\docker" -Force -Recurse
Remove-Item -Recurse -Force "C:\Program Files\Docker"
Remove-Item -Path "C:\Windows\system32\config\systemprofile\appData\Roaming\Docker" -Force -Recurse
#endregion UninstallDocker

#region Config
Explorer "C:\ProgramData\docker\config"

$DockerConfig = "$Env:ProgramData\docker\config\daemon.json"
$null = New-Item -Path $DockerConfig -Type File -Force
$Conf = @"
{ 
"hosts": ["tcp://0.0.0.0:2375", "npipe://"],
"graph" : "D:\\docker"
}
"@
<#
{
    "authorization-plugins": [],
    "dns": [],
    "dns-opts": [],
    "dns-search": [],
    "exec-opts": [],
    "storage-driver": "",
    "storage-opts": [],
    "labels": [],
    "log-driver": "", 
    "mtu": 0,
    "pidfile": "",
    "graph": "",
    "cluster-store": "",
    "cluster-advertise": "",
    "debug": true,
    "hosts": [],
    "log-level": "",
    "tlsverify": true,
    "tlscacert": "",
    "tlscert": "",
    "tlskey": "",
    "group": "",
    "default-ulimits": {},
    "bridge": "",
    "fixed-cidr": "",
    "raw-logs": false,
    "registry-mirrors": [],
    "insecure-registries": [],
    "disable-legacy-registry": false
}
#>
Add-Content -Path $DockerConfig -Value $Conf
notepad "C:\ProgramData\Docker\config\daemon.json"

Netsh advfirewall firewall add rule name="docker engine" dir=in action=allow protocol=TCP localport=2375

# Docker Log file C:\Users\Administrator\AppData\Local\Docker\log.txt
if (!Test-Path -Path "$($ENV:LOCALAPPDATA)\Docker\log.txt" -PathType Leaf) {
    $null = New-Item -Path "$($ENV:LOCALAPPDATA)\Docker\log.txt" -ItemType File -Force   
}
Restart-Service -Name docker

# Add Container CmdLets to PowerShell
Register-PSRepository -Name dockerps-dev -Sourcelocation "https://ci.appveyor.com/nuget/docker-powershell-dev"
Install-Module -Name "docker" -Repository "dockerps-dev" -Scope Currentuser -AllowClobber
Get-Command -Module docker
#endregion Config

#region FirstSteps
Explorer "C:\Program Files\Docker"
docker --help
docker version
docker info
docker images
docker search microsoft/mssql


# start first Container
docker pull hello-world:nanoserver
explorer "D:\docker\windowsfilter"

docker container run hello-world:nanoserver
docker container run --isolation=hyperv hello-world:nanoserver

# load more images
docker pull microsoft/nanoserver
docker pull microsoft/windowsservercore
docker pull microsoft/windowsservercore:10.0.14393.321
docker pull microsoft/mssql-server-linux:2017-latest #image operating system "linux" cannot be used on this platform
docker pull microsoft/mssql-server-windows-developer
docker pull microsoft/mssql-server-windows-express

docker images
docker image save --output d:\images\nano.tar microsoft/nanoserver
docker load -i d:\images\nano.tar

docker run -it microsoft/nanoserver powershell

docker run -name myiis -p 80:80 microsoft/iis
docker exec -it myiis powershell
docker ps
docker inspect myiis
docker inspect --format "{{ .NetworkSettings.Networks.nat.IPAddress }}" myiis
$URL = "http://" + $(docker inspect --format "{{ .NetworkSettings.Networks.nat.IPAddress }}" myiis)
& "C:\Program Files\Internet Explorer\iexplore.exe" $URL
docker stop
docker history myiis
docker diff myiis
docker rm myiis

# with powershell
Get-Command -Module docker | Select-Object -Property Name
$Container = New-Container -Name Test -ImageIdOrName "microsoft/windowsservercore"
$Container | Select-Object -Property *
Start-Container $Container
Get-ContainerImage | Select-Object -Property *
Get-Container | Where-Object {$PSItem.Names -match 'Test'} | Remove-Container
Get-Container | Get-ContainerDetail

ipconfig
Get-Process
Enter-PSSession -ContainerId $((Get-Container)[0].ID) -RunAsAdministrator
ipconfig
Get-Process
Exit-PSSession
Get-Process -Name csrss
#endregion FirstSteps


#region TroubleShooting
# (Invoke-Webrequest -UseBasicParsing -Uri "https://raw.githubusercontent.com/MicrosoftDocs/Virtualization-Documentation/live/windows-server-container-tools/Debug-ContainerHost/Debug-ContainerHost.ps1").Content
Invoke-Expression -Command (Invoke-Webrequest -UseBasicParsing -Uri "https://raw.githubusercontent.com/MicrosoftDocs/Virtualization-Documentation/live/windows-server-container-tools/Debug-ContainerHost/Debug-ContainerHost.ps1") -Verbose

# docker messages in Eventlogs
@"
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Application\docker]
"CustomSource"=dword:00000001
"EventMessageFile"="C:\\Program Files\\docker\\dockerd.exe"
"TypesSupported"=dword:00000007
"@ | Set-content "$Env:TEMP\EWT_Docker.reg"
Invoke-Item -Path  "$Env:TEMP\EWT_Docker.reg"

Get-EventLog -LogName Application -Source Docker -After (Get-Date).AddMinutes(-5) | Sort-Object Time 

# Service infos
sc.exe qc docker
# enable debug
sc.exe config docker binpath= "\"C:\Program Files\Docker\dockerd.exe\" --run-service -D"
dockerd -D

docker service logs --details SERVICE
#endregion TroubleShooting

Get-Command -Module Containers

#nested VM
$vm = "<virtual-machine>"
#configure virtual processor
Set-VMProcessor -VMName $vm -ExposeVirtualizationExtensions $true -Count 2
#disable dynamic memory
Set-VMMemory $vm -DynamicMemoryEnabled $false
#enable mac spoofing
Get-VMNetworkAdapter -VMName $vm | Set-VMNetworkAdapter -MacAddressSpoofing On

#region CreateNewImage
New-Item -Path "$Env:Temp\myfirstimage" -ItemType directory | Set-Location
@"
FROM microsoft/nanoserver
CMD echo Hello World
"@ | Set-Content -Path "Dockerfile" -Force
docker build -t myfirstimage .
docker run --name nano myfirstimage
docker stop nano
docker rm nano

$iisfolder = New-Item -Path "$Env:Temp\IISContainer" -ItemType Directory
if ($iisfolder) {
@"
FROM microsoft/iis
	MAINTAINER Sylvio Hellmann
	RUN mkdir C:\site
    SHELL ["powershell", "-Command", "$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue';"]
	RUN powershell -NoProfile -Command \
	    Import-module IISAdministration; \
	    New-IISSite -Name "Site" -PhysicalPath C:\site -BindingInformation "*:8080:"
	COPY index.html C:\site
	EXPOSE 8080
    # ADD content/ /site
"@ | Out-File -FilePath "$($iisfolder.FullName)\dockerfile" -Encoding ascii
    "<HTML><BODY><P>Testseite</P></BODY></HTML>" | Out-File -FilePath "$($iisfolder.FullName)\index.html"
    Set-Location -Path $iisfolder.FullName
    docker build -t mysecondimage .
    docker run -d --name myiis2 -p 8080:8080 mysecondimage
}
docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' myiis2
docker inspect --format "{{ .NetworkSettings.Networks.nat.IPAddress }}" myiis2
$URL = "http://" + $(docker inspect --format "{{ .NetworkSettings.Networks.nat.IPAddress }}" myiis2) + ":8080"
& "C:\Program Files\Internet Explorer\iexplore.exe" $URL

Start-Sleep -Seconds 60
docker stop myiis2
docker rm myiis2
docker rmi mysecondimage
Set-Location -Path "$Env:UserProfile"
Remove-Item -Path $iisfolder.FullName -Recurse -Force

# load image in docker cloud repository
$DOCKER_ID_USER="shellmann"
docker login -u $DOCKER_ID_USER
docker tag myfirstimage $DOCKER_ID_USER/myfirstimage
docker push "$DOCKER_ID_USER/myfirstimage:latest"
docker rmi myfirstimage

docker pull "$DOCKER_ID_USER/myfirstimage:latest"

# not working curre
docker run --name sylvio microsoft/nanoserver
Stop-Container -ContainerIdOrName sylvio
get-command -Module docker
Start-Container -ContainerIdOrName sylvio
docker run -it --isolation=hyperv microsoft/nanoserver cmd
#endregion CreateNewImage

# https://github.com/aspnet/MusicStore

#region SQL
& "$Env:windir\explorer.exe" "D:\docker\windowsfilter\d070ed0a37fe34cde6ee7ae9b08fc02f0a62972025703f492e5240bb43601beb\Files"
docker run --name SQL1 -d -p 1433:1433 -e sa_password="P@ssw0rd" -e ACCEPT_EULA=Y microsoft/mssql-server-windows-developer
docker inspect --format "{{ .NetworkSettings.Networks.nat.IPAddress }}" SQL1
Enter-PSSession -ContainerId $((Get-Container)[0].ID) -RunAsAdministrator
sqlcmd -Q "Select @@Version"
Exit-PSSession
$IP = (Get-Container -Name SQL1 | Get-ContainerDetail).Networksettings.Networks.nat.IPAddress
sqlcmd -U "sa" -P "P@ssw0rd" -S $IP -Q "Select @@Version"

docker cp "SQL1:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\data\sampleDB.mdf" C:\temp
docker cp "SQL1:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\data\sampleDB_log.ldf" C:\temp
docker volume create sqldata
# docker volume rm sqldata
docker volume inspect sqldata

# change to VS Code and Build an SQL Image
& "C:\Program Files\Microsoft VS Code\Code.exe"

docker run --name SQL2 `
    -p 1433:1433 -v sqldata:C:\data\ `
    -e "MSSQL_PID=Developer" -e sa_password=P@ssw0rd -e ACCEPT_EULA=Y `
    -e attach_dbs="[{'dbName':'SampleDB','dbFiles':['C:\\data\\sampledb.mdf','C:\\data\\sampledb_log.ldf']}]" `
    -a STDOUT sqldocker

docker exec SQL2 powershell -Command "Invoke-Sqlcmd -Query 'CREATE DATABASE SampleDB ON (FILENAME = N''C:\data\sampledb.mdf''),(FILENAME = N''C:\data\sampledb_log.ldf'') FOR ATTACH ;'"

$IP = (Get-Container -Name SQL2 | Get-ContainerDetail).Networksettings.Networks.nat.IPAddress
sqlcmd -U "sa" -P "P@ssw0rd" -S $IP -Q "Select name from sys.databases"

# https://github.com/dbafromthecold/  
docker search dbafromthecold/sqlserver2016dev

# Create docker-Object with docker.exe
$fields = "ContainerId","Image","Command","Created","Status","Port","Name" 
docker -H "tcp://$((Get-NetIPAddress)[0].Address)`:2375" ps |
    Select-Object -Skip 1 |
    ConvertFrom-String -Delimiter "[\s]{2,}" -PropertyNames $fields

# the one and only
docker run --name SQL3 -p 1435:1435 sqlsylvio # --cpus=2 --memory=2048m 
$IP = (Get-Container -Name SQL3 | Get-ContainerDetail).Networksettings.Networks.nat.IPAddress
sqlcmd -U "sa" -P "P@ssw0rd" -S $IP -Q "Select name from sys.databases"

docker stats

# /opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P '<YourPassword>'

#endregion SQL

