﻿$a = [Regex]'[0-9a-f]{8}[-]?[0-9a-f]{4}[-]?[0-9a-f]{4}[-]?[0-9a-f]{4}[-]?[0-9a-f]{12}[-]?'

$created = Get-WinEvent -FilterHashtable @{
  ProviderName = 'Microsoft-Windows-PowerShell'
  Id           = 4104
} | Select-Object *, @{n='ScriptBlockID';e={$a.Match($_[0].Message).Value}}

$uniqueScriptBlockIDs = $created.ScriptBlockID | Sort-Object | Select-Object -Unique

foreach ($uniqueScriptBlockID in $uniqueScriptBlockIDs)
{
    $sortedScripts = $created.Where{$_.ScriptBlockID -eq $uniqueScriptBlockID} | Sort-Object { $_.Properties[0].Value }
    $mergedScript = -join ($sortedScripts | % { $_.Properties[2].Value })
    $mergedScript | Out-File "c:\Temp\logs\$uniqueScriptBlockID.log"
}

$created | Group-Object {$_.ScriptBlockID} | Where-Object {$_.Count -gt 1}

break;

iex 'get-process'


$created.Where{$_.Message -like '*iex*'}









break;

$created = Get-WinEvent -FilterHashtable @{
  ProviderName = 'Microsoft-Windows-PowerShell'
  Id           = 4104
} 
    $sortedScripts = $created | sort { $_.Properties[0].Value }
$mergedScript = -join ($sortedScripts | % { $_.Properties[2].Value })
break



$created|Where-Object {$_.ActivityId -eq 'a899d302-bea8-0003-4cef-9ba8a8bed201'}
$created = $created | ForEach-Object {$_ | Add-Member NoteProperty Title((($_.Message).Split('ID: '))[1])}

$created = $created | Select-Object *, @{n='ScriptBlockID';e={(($_.Message).Split('ID: '))[1]}}


($created[0].Message).Split('ID: ')[9]
$a = [Regex]'[0-9a-f]{8}[-]?[0-9a-f]{4}[-]?[0-9a-f]{4}[-]?[0-9a-f]{4}[-]?[0-9a-f]{12}[-]?'
$a.Match($created[0].Message).Value
$created[0].Message | Select-String 
#https://msdn.microsoft.com/de-de/powershell/wmf/5.0/audit_script

$created = Get-WinEvent -FilterHashtable @{
  ProviderName = 'Microsoft-Windows-PowerShell'
  Id           = 4104
} # | Where-Object { $_.<...> }
$sortedScripts = $created | Sort-Object -Property {
  $_.Properties[0].Value 
}
$mergedScript = -join ($sortedScripts | ForEach-Object -Process {
    $_.Properties[2].Value 
}) -split 'prompt' #-join [System.Environment]::NewLine + [System.Environment]::NewLine + '_______________________'+ [System.Environment]::NewLine + [System.Environment]::NewLine


. "C:\OneDrive\Weiteres\PSConfEU - 2017\Scripts\Test.ps1"


$created = Get-WinEvent -FilterHashtable @{ ProviderName="Microsoft-Windows-PowerShell"; Id = 4104 } | Where-Object { $_.Message -like '*98eaf72b-87d1-4578-a945-48cde9343690*'}
$sortedScripts = $created | sort { $_.Properties[0].Value }
$mergedScript = -join ($sortedScripts | % { $_.Properties[2].Value })