﻿<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2016
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - PSRepoServer 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        
#> 

Get-Process

Set-ExecutionPolicy -Scope Process -ExecutionPolicy AllSigned
Set-ExecutionPolicy -Scope LocalMachine -ExecutionPolicy AllSigned
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy AllSigned