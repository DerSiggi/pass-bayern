:connect ALWAYSON-SRV2

DECLARE @localReplicaRole int

SET @localReplicaRole = (select role from [master].sys.dm_hadr_availability_replica_states ars JOIN [master].sys.dm_hadr_database_replica_states drs ON ars.group_id = drs.group_id WHERE (ars.is_local = 1) AND (drs.is_local = 1) AND (drs.database_id = db_id('AdventureworksDW')))
-- Role = 1 => primary
-- Role = 2 => secondary

IF (@localReplicaRole = 1)
BEGIN
    BACKUP DATABASE [AdventureworksDW] TO  DISK = N'\\ALWAYSON-SRV1\SQL-LogBackups\AdventureworksDW_Diff_Backup.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'AdventureworksDW-Differential Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
END
GO

DECLARE @localReplicaRole int

SET @localReplicaRole = (select role from [master].sys.dm_hadr_availability_replica_states ars JOIN [master].sys.dm_hadr_database_replica_states drs ON ars.group_id = drs.group_id WHERE (ars.is_local = 1) AND (drs.is_local = 1) AND (drs.database_id = db_id('AdventureWorksRef')))
-- Role = 1 => primary
-- Role = 2 => secondary

IF (@localReplicaRole = 1)
BEGIN
    BACKUP DATABASE [AdventureWorksRef] TO  DISK = N'\\ALWAYSON-SRV1\SQL-LogBackups\AdventureWorksRef_Diff_Backup.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'AdventureWorksRef-Differential Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
END
GO

