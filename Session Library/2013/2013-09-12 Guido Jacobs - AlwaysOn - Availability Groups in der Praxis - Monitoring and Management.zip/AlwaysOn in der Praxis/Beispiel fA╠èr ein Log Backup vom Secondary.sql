:connect ALWAYSON-SRV4

DECLARE @preferredReplica int

SET @preferredReplica = (SELECT [master].sys.fn_hadr_backup_is_preferred_replica('AdventureworksDW'))

IF (@preferredReplica = 1)
BEGIN
    BACKUP LOG [AdventureworksDW] TO  DISK = N'\\ALWAYSON-SRV1\SQL-LogBackups\AdventureworksDW_Log_backup.trn' WITH NOFORMAT, NOINIT,  NAME = N'AdventureworksDW_Log_Backup', SKIP, REWIND, NOUNLOAD,  STATS = 10
END
GO
DECLARE @preferredReplica int

SET @preferredReplica = (SELECT [master].sys.fn_hadr_backup_is_preferred_replica('AdventureWorksRef'))

IF (@preferredReplica = 1)
BEGIN
    BACKUP LOG [AdventureWorksRef] TO  DISK = N'\\ALWAYSON-SRV1\SQL-LogBackups\AdventureWorksRef_Log_backup.trn' WITH NOFORMAT, NOINIT,  NAME = N'AdventureWorksRef_Log _Backup', SKIP, REWIND, NOUNLOAD,  STATS = 10
END
