USE [msdb]
GO

/****** Object:  Alert [Alert for "on schedule" policy Failure]    Script Date: 19.08.2013 16:12:14 ******/
EXEC msdb.dbo.sp_add_alert @name=N'Alert for "on schedule" policy Failure', 
		@message_id=34052, 
		@severity=0, 
		@enabled=0, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@notification_message=N'There was a Policy Failure', 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO


