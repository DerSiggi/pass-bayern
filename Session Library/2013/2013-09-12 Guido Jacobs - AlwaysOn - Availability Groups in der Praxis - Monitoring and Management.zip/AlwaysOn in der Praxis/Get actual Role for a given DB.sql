:connect ALWAYSON-SRV2

select DB_NAME(database_id) as [Database], role_desc
from sys.dm_hadr_availability_replica_states ars 
join sys.dm_hadr_database_replica_states drs 
ON ars.replica_id = drs.replica_id and ars.group_id = drs.group_id
where database_id = DB_ID('AdventureworksDW') and drs.is_local = 1

 