1. Download the SQL Server 2012 AdventureWorks sample database from the CodePlex site,
attach it and rename it to AdventureWorks:

Adventure Works for SQL Server 2012
http://msftdbprodsamples.codeplex.com/releases/view/55330

2. Download the Credit sample database from the SQLSkills site and attach it:
http://www.sqlskills.com/pastconferences.asp

3. Run the CreatePerformanceSampleData.sql script to create the Performance database.