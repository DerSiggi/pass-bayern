USE Credit;
GO

DECLARE @Column INT = 2, 
        @Value  INT = 10;

SELECT
	m.member_no, 
    m.street, 
    m.city, 
    c.charge_no, 
    c.provider_no, 
    c.category_no, 
    c.charge_dt, 
    c.charge_amt, 
    c.charge_code 
FROM dbo.charge c
INNER JOIN dbo.member m
	ON m.member_no = c.member_no 
WHERE CHOOSE(@Column, c.provider_no, c.category_no) = @Value;