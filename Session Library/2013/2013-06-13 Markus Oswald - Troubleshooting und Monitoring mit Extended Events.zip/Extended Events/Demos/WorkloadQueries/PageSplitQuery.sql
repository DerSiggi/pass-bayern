USE PageSplits;
GO

SET NOCOUNT ON;

DECLARE @i INT = 0;
WHILE (@i < 10000)
BEGIN
    INSERT INTO dbo.MidSplits DEFAULT VALUES;
    INSERT INTO dbo.EndSplits DEFAULT VALUES;
    -- WAITFOR DELAY '00:00:00.005';
	SET @i += 1;
END
PRINT 'Command(s) completed successfully.';
GO
