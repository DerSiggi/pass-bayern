USE Credit;
GO

SELECT c.*, m.* FROM dbo.charge c
INNER JOIN dbo.member m ON m.member_no = c.member_no
ORDER BY m.lastname;
GO