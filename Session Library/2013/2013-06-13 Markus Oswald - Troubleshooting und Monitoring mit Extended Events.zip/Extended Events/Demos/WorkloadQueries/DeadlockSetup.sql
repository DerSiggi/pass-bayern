USE AdventureWorks;
GO

IF OBJECT_ID('spSerializableDeadlock') IS NOT NULL
	DROP PROCEDURE dbo.spSerializableDeadlock;
GO

CREATE PROCEDURE dbo.spSerializableDeadlock @NewSales XML
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

	BEGIN TRANSACTION
		IF NOT EXISTS (SELECT *
					FROM Sales.SalesOrderHeader
					WHERE CustomerID = 105)
		-- WAITFOR DELAY '00:00:02';
		BEGIN
			INSERT INTO [AdventureWorks].[Sales].[SalesOrderHeader]
				   ([RevisionNumber], [OrderDate], [DueDate], [ShipDate], [Status], 
					[OnlineOrderFlag], [PurchaseOrderNumber], [AccountNumber], [CustomerID], 
					[SalesPersonID], [TerritoryID], [BillToAddressID], [ShipToAddressID],
					[ShipMethodID], [CreditCardID], [CreditCardApprovalCode], [CurrencyRateID],
					[SubTotal], [TaxAmt], [Freight], [Comment])
			SELECT
				n.value('(RevisionNumber)[1]', 'int'),
				n.value('(OrderDate)[1]', 'datetime'),
				n.value('(DueDate)[1]', 'datetime'),
				n.value('(ShipDate)[1]', 'datetime'),
				n.value('(Status)[1]', 'tinyint'),
				n.value('(OnlineOrderFlag)[1]', 'bit'),
				n.value('(PurchaseOrderNumber)[1]', 'nvarchar(25)'),
				n.value('(AccountNumber)[1]', 'nvarchar(15)'),
				n.value('(CustomerID)[1]', 'nvarchar(15)'),
				n.value('(SalesPersonID)[1]', 'int'),
				n.value('(TerritoryID)[1]', 'int'),
				n.value('(BillToAddressID)[1]', 'int'),
				n.value('(ShipToAddressID)[1]', 'int'),
				n.value('(ShipMethodID)[1]', 'int'),
				n.value('(CreditCardID)[1]', 'int'),
				n.value('(CreditCardApprovalCode)[1]', 'varchar(15)'),
				n.value('(CurrencyRateID)[1]', 'int'),
				n.value('(SubTotal)[1]', 'money'),
				n.value('(TaxAmt)[1]', 'money'),
				n.value('(Freight)[1]', 'money'),
				n.value('(Comment)[1]', 'nvarchar(128)')
			FROM @NewSales.nodes('SalesOrders/SalesOrderHeader') q(n);
		END
	
	ROLLBACK TRANSACTION
END
GO