-- ensure that the Auto Create and Auto Update Statistics options are enabled in AdventureWorks
IF EXISTS
(
	SELECT
		is_auto_create_stats_on,
		is_auto_update_stats_on
	FROM sys.databases
	WHERE name = 'AdventureWorks'
	AND (is_auto_create_stats_on = 0 OR is_auto_update_stats_on = 0)
)
BEGIN
	ALTER DATABASE AdventureWorks SET AUTO_CREATE_STATISTICS ON;
	ALTER DATABASE AdventureWorks SET AUTO_UPDATE_STATISTICS ON;
END

/*
check statistics date with
DBCC SHOW_STATISTICS, STATS_DATE, sys.dm_db_stats_properties (available in SQL Server 2012 >= SP 1 and SQL Server 2008 R2 >= SP 2)
*/
USE AdventureWorks;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'Sales.TestSalesOrderDetail'), 'IsUserTable') IS NOT NULL
	DROP TABLE Sales.TestSalesOrderDetail;
GO

SELECT * 
INTO Sales.TestSalesOrderDetail
FROM Sales.SalesOrderDetail;
GO
CREATE CLUSTERED INDEX PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID
ON Sales.TestSalesOrderDetail (SalesOrderID, SalesOrderDetailID);
GO
CREATE UNIQUE NONCLUSTERED INDEX AK_TestSalesOrderDetail_rowguid
ON Sales.TestSalesOrderDetail (rowguid);
GO
CREATE NONCLUSTERED INDEX IX_TestSalesOrderDetail_ProductID
ON Sales.TestSalesOrderDetail (ProductID);
GO

-- show the statistics histogram for the primary clustered key PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID
DBCC SHOW_STATISTICS ('Sales.TestSalesOrderDetail', PK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID);

-- sys.dm_db_stats_properties (object_id, stats_id)
-- available in SQL Server 2012 >= SP 1 and SQL Server 2008 R2 >= SP 2
SELECT
    OBJECT_NAME(sp.object_id) AS table_name,
	-- sp.stats_id AS statistic_id,
	s.name AS statistic_name,
	sp.last_updated AS stats_last_updated,
	sp.rows AS row_count,
	sp.rows_sampled AS rows_sampled,
	sp.unfiltered_rows AS rows_unfiltered,
	sp.modification_counter AS rows_modified,
    CAST(((sp.modification_counter * 1.0 / sp.rows * 1.0) * 100.0) AS DECIMAL(18, 2)) AS rows_modified_percent,
	sp.steps AS histogram_steps
FROM sys.stats AS s
OUTER APPLY sys.dm_db_stats_properties (s.object_id, s.stats_id) AS sp
WHERE s.object_id = OBJECT_ID(N'Sales.TestSalesOrderDetail');

/*
The Sales.SalesOrderDetail table has 121317 rows:
(121317 * 0.20) + 500 = 24764
The bulk insert below loads 24775 rows, which should be enough to invalidate statistics. 
*/
BULK INSERT AdventureWorks.Sales.TestSalesOrderDetail
FROM 'C:\Data\SalesOrderDetails.txt'
WITH
(
	DATAFILETYPE = 'native',
	TABLOCK
);

-- check the statistics again
SELECT
	s.name AS statistic_name,
	sp.last_updated AS stats_last_updated,
	sp.rows AS row_count,
	sp.modification_counter AS rows_modified,
    CAST(((sp.modification_counter * 1.0 / sp.rows * 1.0) * 100.0) AS DECIMAL(18, 2)) AS rows_modified_percent
FROM sys.stats AS s
OUTER APPLY sys.dm_db_stats_properties (s.object_id, s.stats_id) AS sp
WHERE s.object_id = OBJECT_ID(N'Sales.TestSalesOrderDetail');

-- invoking the automatic update of the statistics
SELECT * FROM Sales.TestSalesOrderDetail WHERE SalesOrderID = 75123;
GO
UPDATE Sales.TestSalesOrderDetail SET ProductID = 717 WHERE SalesOrderID = 75123;
GO
-- (3 row(s) affected)

-- check the statistics again
SELECT
	s.name AS statistic_name,
	sp.last_updated AS stats_last_updated,
	sp.rows AS row_count,
	sp.modification_counter AS rows_modified,
    CAST(((sp.modification_counter *  1.0 / sp.rows) * 100.0) AS DECIMAL(18, 2)) AS rows_modified_percent
FROM sys.stats AS s
OUTER APPLY sys.dm_db_stats_properties (s.object_id, s.stats_id) AS sp
WHERE s.object_id = OBJECT_ID(N'Sales.TestSalesOrderDetail');

-- capture statistics information from the query plan
-- look for wszStatName in the XML query plan
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
GO
DBCC TRACEON (8666);
GO
WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS p)
SELECT
	qt.text AS query_text,
	qp.query_plan,
	StatsUsed.XMLColumn.value('@FieldValue','NVarChar(500)') AS statistic_name
FROM sys.dm_exec_cached_plans cp
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) qp
CROSS APPLY sys.dm_exec_sql_text (cp.plan_handle) qt
CROSS APPLY query_plan.nodes('//p:Field[@FieldName="wszStatName"]') StatsUsed(XMLColumn)
WHERE qt.text LIKE '%UPDATE%'
AND qt.text LIKE '%ProductID%' OPTION (MAXDOP 1);
GO
DBCC TRACEOFF(8666);
GO

-- run a query against UnitPrice
SELECT COUNT(*) FROM Sales.TestSalesOrderDetail
WHERE UnitPrice > 1000.0;

-- show all statistics for the table and look for the auto created stats for the UnitPrice column
EXECUTE sp_helpstats 'Sales.TestSalesOrderDetail', 'ALL';

-- data distribution for the UnitPrice
DBCC SHOW_STATISTICS ('Sales.TestSalesOrderDetail', <statistics_name>);

-- update the statistics manually, here with a higher sample rate
UPDATE STATISTICS Sales.TestSalesOrderDetail <statistics_name> -- WITH FULLSCAN, NORECOMPUTE | SAMPLE 80 PERCENT;

-- cleanup
USE AdventureWorks;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'Sales.TestSalesOrderDetail'), 'IsUserTable') IS NOT NULL
	DROP TABLE Sales.TestSalesOrderDetail;
GO