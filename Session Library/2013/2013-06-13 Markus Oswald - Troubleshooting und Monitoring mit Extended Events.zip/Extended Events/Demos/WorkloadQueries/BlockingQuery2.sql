USE AdventureWorks;
GO

SELECT * FROM Person.Address -- WITH (NOLOCK) -- WITH (ROWLOCK)
WHERE AddressID <> 12;