USE LockEscalation;
GO

BEGIN TRANSACTION
	UPDATE dbo.LockTable WITH (ROWLOCK)
	SET c2 = c1
	WHERE c1 <= 6084;

	SELECT
		resource_type,
		request_mode,
		COUNT(1) AS lock_count 
	FROM sys.dm_tran_locks WHERE request_session_id = @@SPID 
	GROUP BY resource_type, request_mode;
ROLLBACK TRANSACTION