SELECT * 
FROM AdventureWorks.Sales.SalesOrderHeader;
GO 10
