USE AdventureWorks;
GO

DECLARE @NewSales XML =
	(SELECT RevisionNumber, OrderDate, DueDate, ShipDate, Status, 
		OnlineOrderFlag, PurchaseOrderNumber, AccountNumber, 105 AS CustomerID, 
		SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID,
		ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID,
		SubTotal, TaxAmt, Freight, Comment
	FROM Sales.SalesOrderHeader -- WITH (NOLOCK)
	WHERE CustomerID = 11000
	FOR XML PATH('SalesOrderHeader'), ROOT('SalesOrders'), TYPE);

WHILE (1=1)
BEGIN
	EXEC dbo.spSerializableDeadlock @NewSales;
END
