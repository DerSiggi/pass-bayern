USE AdventureWorks;
GO

SET STATISTICS TIME ON;
GO
SELECT * FROM Sales.SalesOrderDetail
ORDER BY UnitPriceDiscount DESC;
GO
SET STATISTICS TIME OFF;
GO