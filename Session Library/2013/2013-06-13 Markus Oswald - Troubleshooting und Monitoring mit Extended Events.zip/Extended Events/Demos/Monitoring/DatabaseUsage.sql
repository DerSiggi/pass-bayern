-- extended event session to track database usage
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'DatabaseUsage')
	DROP EVENT SESSION DatabaseUsage ON SERVER;
GO

-- number of databases in the instance
SELECT COUNT(*) AS database_count FROM sys.sysdatabases
WHERE dbid > 4;

-- create the event session
CREATE EVENT SESSION DatabaseUsage
ON SERVER 
ADD EVENT sqlserver.lock_acquired( 
	WHERE owner_type = 4 -- SharedXactWorkspace
	  AND resource_type = 2 -- database level lock
	  AND database_id > 4 -- non system database
	  AND sqlserver.is_system = 0 -- must be a user process
) 
ADD TARGET package0.histogram
( SET slots = 14, -- adjust based on number of databases in instance
	  filtering_event_name='sqlserver.lock_acquired', -- aggregate on the lock_acquired event
	  source_type=0, -- event data and not action data
	  source='database_id' -- aggregate by the database_id
); -- dispatch immediately and don't wait for full buffers
GO

-- start the event session
ALTER EVENT SESSION DatabaseUsage ON SERVER STATE = START;
GO

-- parse the session data to determine the databases being used
SELECT
	slot.value('./@count', 'int') AS lock_occurence_count,
    DB_NAME(slot.query('./value').value('.', 'int')) AS database_name
FROM
(
	SELECT CAST(target_data AS XML) AS target_data
	FROM sys.dm_xe_session_targets AS t
    INNER JOIN sys.dm_xe_sessions AS s 
		ON t.event_session_address = s.address
	WHERE s.name = 'DatabaseUsage'
	  AND t.target_name = 'histogram') AS tgt(target_data)
CROSS APPLY target_data.nodes('/HistogramTarget/Slot') AS bucket(slot)
ORDER BY slot.value('./@count', 'int') DESC;

-- stop the event session
ALTER EVENT SESSION DatabaseUsage ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION DatabaseUsage ON SERVER;
GO