USE master;
GO

IF DATABASEPROPERTYEX ('LockEscalation', 'Version') > 0
	DROP DATABASE LockEscalation;

CREATE DATABASE LockEscalation;
GO

USE LockEscalation;
GO

SET NOCOUNT ON;
GO

-- create table
CREATE TABLE dbo.LockTable ( 
	c1 BIGINT IDENTITY(1,1),
	c2 CHAR(200) NOT NULL,
		CONSTRAINT PK_TestTable PRIMARY KEY (c1));
GO

-- load data
WITH
	X1 AS (SELECT REVERSE(name) AS C FROM sys.objects),
	X2 AS (SELECT DISTINCT REVERSE(name) AS C FROM sys.columns),
	X3 AS (SELECT REVERSE(name) AS C FROM sys.objects)
INSERT dbo.LockTable (c2)
SELECT TOP 50000 
	X1.C + ' ' + X2.C + ' ' + X3.C AS C1 
FROM X1 CROSS JOIN X2 CROSS JOIN X3;
GO

-- try 4999, then 5000 and then 6084, this is the magic number for this table
BEGIN TRANSACTION
	UPDATE dbo.LockTable WITH (ROWLOCK) -- WITH (PAGLOCK), WITH (TABLOCK)
	SET c2 = c1
	WHERE c1 <= 4999;

	SELECT
		resource_type,
		request_mode,
		COUNT(1) AS lock_count 
	FROM sys.dm_tran_locks WHERE request_session_id = @@SPID 
	GROUP BY resource_type, request_mode;
ROLLBACK TRANSACTION

-- lock escalation is triggered when a single statement acquires
-- at least 5.000 locks on a single nonpartitioned table or index
BEGIN TRANSACTION
	UPDATE dbo.LockTable WITH (ROWLOCK) -- WITH (PAGLOCK), WITH (TABLOCK)
	SET c2 = c1
	WHERE c1 <= 4999;

	UPDATE dbo.LockTable WITH (ROWLOCK) -- WITH (PAGLOCK), WITH (TABLOCK)
	SET c2 = c1
	WHERE c1 > 4999
	AND c1 <= 9999;

	SELECT
		resource_type,
		request_mode,
		COUNT(1) AS lock_count 
	FROM sys.dm_tran_locks WHERE request_session_id = @@SPID 
	GROUP BY resource_type, request_mode;
ROLLBACK TRANSACTION

-- create an extended event session to capture lock escalation
/*
SQL Server 2012: sqlserver.lock_escalation
SQL Server < 2012: sqlserver.lock_acquired to identify object level locking (resource_type = 5)
along with sqlserver.sql_sp_statement_starting and sqlserver.sql_statement_starting
and TRACK_CAUSALITY
*/
CREATE EVENT SESSION LockEscalation ON SERVER 
ADD EVENT sqlserver.lock_escalation( 
	ACTION (sqlserver.sql_text,
			sqlserver.database_name,
			sqlserver.client_hostname,
			sqlserver.username,
			sqlserver.tsql_stack,
			sqlserver.server_instance_name,
			sqlserver.session_id) 
	)
ADD TARGET package0.event_file
	(SET FILENAME = N'C:\Temp\LockEscalation.xel')
		WITH (MAX_MEMORY = 4096 KB,
			EVENT_RETENTION_MODE = ALLOW_SINGLE_EVENT_LOSS,
			MAX_DISPATCH_LATENCY = 30 SECONDS,
			MAX_EVENT_SIZE = 0 KB,
			MEMORY_PARTITION_MODE = NONE,
			TRACK_CAUSALITY = OFF,
			STARTUP_STATE = OFF);
GO 
 
-- start the session
ALTER EVENT SESSION LockEscalation
	ON SERVER STATE = START;
GO

-- run workload query to trigger lock escalation

-- disable lock escalation for the table and rerun the above transaction
ALTER TABLE dbo.LockTable SET (LOCK_ESCALATION = DISABLE);

-- wait for few minutes to capture some activity and stop the session
ALTER EVENT SESSION LockEscalation 
	ON SERVER STATE = STOP;
GO

-- drop the event session
DROP EVENT SESSION LockEscalation ON SERVER;
GO

-- query the XML to get the target data
SELECT
	final_data.R.value ('@name', 'nvarchar(50)') AS event_name,
	final_data.R.value ('(action[@name="sql_text"]/value)[1]', 'nvarchar(2000)') AS sql_text,
	final_data.R.value ('(data[@name="escalation_cause"]/value)[1]', 'varchar(50)') 
		+ ' - ' + final_data.R.value ('(data[@name="escalation_cause"]/text)[1]', 'varchar(50)') AS escalation_cause,
	final_data.R.value ('(data[@name="hobt_lock_count"]/value)[1]', 'varchar(50)') AS hobt_lock_count,
	final_data.R.value ('(data[@name="escalated_lock_count"]/value)[1]', 'varchar(50)') AS escalated_lock_count,
	final_data.R.value ('(data[@name="mode"]/value)[1]', 'varchar(50)')
		+ ' - ' + final_data.R.value ('(data[@name="mode"]/text)[1]', 'varchar(50)') AS resource_mode,
	final_data.R.value ('(data[@name="resource_type"]/value)[1]', 'varchar(50)') 
		+ ' - ' + final_data.R.value ('(data[@name="resource_type"]/text)[1]', 'varchar(50)') AS resource_type
FROM ( 
SELECT
	CAST(event_data AS XML) AS xml_data
	FROM sys.fn_xe_file_target_read_file 
	(N'C:\Temp\LockEscalation*.xel', NULL, NULL, NULL)) async_file_data 
CROSS APPLY xml_data.nodes ('//event') AS final_data (R);

-- cleanup
USE master;
GO

IF DATABASEPROPERTYEX ('LockEscalation', 'Version') > 0
BEGIN
	ALTER DATABASE LockEscalation SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE LockEscalation;
END
GO

EXECUTE sys.sp_configure 'show advanced options', 1;
RECONFIGURE;
 
EXECUTE sys.sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

EXECUTE sys.xp_cmdshell 'DEL C:\Temp\LockEscalation*';
GO

EXECUTE sys.sp_configure 'xp_cmdshell', 0;
RECONFIGURE;