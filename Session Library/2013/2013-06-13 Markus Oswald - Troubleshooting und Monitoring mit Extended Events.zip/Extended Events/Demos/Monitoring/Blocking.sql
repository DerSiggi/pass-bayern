-- configure blocked process threshold
EXECUTE sp_configure 'show advanced options', 1;
RECONFIGURE;
GO
EXECUTE sp_configure 'blocked process threshold', 15;
RECONFIGURE;
GO
EXECUTE sp_configure 'show advanced options', 0;
RECONFIGURE;
GO

-- extended event session to find blocking queries
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'BlockingQueries')
	DROP EVENT SESSION BlockingQueries ON SERVER;
GO

-- create event session
CREATE EVENT SESSION BlockingQueries
ON SERVER
ADD EVENT sqlserver.blocked_process_report
ADD TARGET package0.ring_buffer
	(SET MAX_MEMORY = 4096)	WITH (MAX_DISPATCH_LATENCY = 1 SECONDS);
GO

ALTER EVENT SESSION BlockingQueries
ON SERVER STATE = START;

-- run blocking queries

-- query the XML to get the target data
SELECT 
    DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
        n.value('(event/@timestamp)[1]', 'datetime2')) AS timestamp,
    ISNULL(n.value('(event/data[@name="database_id"]/value)[1]', 'int'),
        n.value('(event/action[@name="database_id"]/value)[1]', 'int')) AS database_id,
    n.value('(event/data[@name="database_name"]/value)[1]', 'nvarchar(128)') AS database_name,
    n.value('(event/data[@name="object_id"]/value)[1]', 'int') AS object_id,
    n.value('(event/data[@name="index_id"]/value)[1]', 'int') AS index_id,
    CAST(n.value('(event/data[@name="duration"]/value)[1]', 'bigint')/1000.0 AS decimal(12,2)) AS duration_ms,
    n.value('(event/data[@name="lock_mode"]/text)[1]', 'nvarchar(10)') AS lock_mode,
    n.value('(event/data[@name="transaction_id"]/value)[1]', 'bigint') AS transaction_id,
    n.value('(event/data[@name="resource_owner_type"]/text)[1]', 'nvarchar(10)') AS resource_owner_type,
    n.query('event/data[@name="blocked_process"]') AS blocked_process_report
FROM
(   SELECT td.query('.') AS n
    FROM 
    (
        SELECT CAST(target_data AS XML) AS target_data
        FROM sys.dm_xe_sessions AS s    
        INNER JOIN sys.dm_xe_session_targets AS t
            ON s.address = t.event_session_address
        WHERE s.name = 'BlockingQueries'
          AND t.target_name = 'ring_buffer'
    ) AS sub
    CROSS APPLY target_data.nodes('RingBufferTarget/event') AS q(td)
) AS tab;
GO

-- stop the event session
ALTER EVENT SESSION BlockingQueries ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION BlockingQueries ON SERVER;
GO

EXECUTE sp_configure 'show advanced options', 1;
RECONFIGURE;
GO
EXECUTE sp_configure 'blocked process threshold', 0;
RECONFIGURE;
GO
EXECUTE sp_configure 'show advanced options', 0;
RECONFIGURE;
GO
