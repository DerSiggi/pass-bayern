-- extended event session to find recompiling queries
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'RecompilingQueries')
	DROP EVENT SESSION RecompilingQueries ON SERVER;
GO

CREATE EVENT SESSION RecompilingQueries ON SERVER 
ADD EVENT sqlserver.sp_statement_starting(
    WHERE ([state]=(1))),
ADD EVENT sqlserver.sql_statement_recompile(SET collect_object_name=(1),collect_statement=(1)),
ADD EVENT sqlserver.sql_statement_starting(
    WHERE ([state]=(1))) 
ADD TARGET package0.event_file
	(SET FILENAME = N'C:\Temp\RecompilingQueries.xel'),
ADD TARGET package0.ring_buffer
	(SET MAX_MEMORY = 4096) WITH (MAX_DISPATCH_LATENCY = 1 SECONDS);
GO

-- start the event session
ALTER EVENT SESSION RecompilingQueries ON SERVER STATE = START;

-- watch live data for the session and run recompiling queries

-- read the data from the ring buffer
SELECT
	CAST(st.target_data AS XML) AS target_data
FROM sys.dm_xe_session_targets st
INNER JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
INNER JOIN sys.server_event_sessions ses ON s.name = ses.name
WHERE st.target_name = 'ring_buffer'
AND s.name = 'RecompilingQueries';
GO

-- read the data from the event file target
SELECT
	CAST(event_data AS XML) AS event_data
FROM sys.fn_xe_file_target_read_file
	('C:\Temp\RecompilingQueries*.xel', NULL, NULL, NULL);

-- identify recompiling SPs with DMVs
SELECT 
	st.text,
	qs.sql_handle,
	qs.plan_generation_num,
	qs.creation_time,
	qs.execution_count,
	st.dbid,
	st.objectid 
FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
WHERE qs.plan_generation_num > 1
	AND st.objectid IS NOT NULL
	AND st.dbid = DB_ID(N'AdventureWorks')
ORDER BY qs.plan_generation_num DESC;

-- stop the event
ALTER EVENT SESSION RecompilingQueries ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION RecompilingQueries ON SERVER;
GO

EXECUTE sys.sp_configure 'show advanced options', 1;
RECONFIGURE;
 
EXECUTE sys.sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

EXECUTE sys.xp_cmdshell 'DEL C:\Temp\RecompilingQueries*';
GO

EXECUTE sys.sp_configure 'xp_cmdshell', 0;
RECONFIGURE;

EXECUTE sys.sp_configure 'show advanced options', 0;
RECONFIGURE;
