-- extended event session to collect a mini dump
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'CollectMiniDump')
	DROP EVENT SESSION CollectMiniDump ON SERVER;
GO

-- create event session to collect a dump for 
-- error 50000, severity 16, and state 1
CREATE EVENT SESSION CollectMiniDump
ON SERVER
ADD EVENT sqlserver.error_reported(
	ACTION (sqlserver.create_dump_single_thread)
	WHERE (error_number = 50000 AND
		   severity = 16 AND
		   state = 1));
		   --AND package0.counter = 1
		   --AND sqlserver.session_id = <session_id>
GO

-- start the event session
ALTER EVENT SESSION CollectMiniDump ON SERVER STATE = START;
GO

-- open the following path in Windows
-- C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Log

-- Generate a error matching the event criteria
RAISERROR('PASS Test Message', 16, 1);
GO

-- stop the event session
ALTER EVENT SESSION CollectMiniDump ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION CollectMiniDump ON SERVER;
GO