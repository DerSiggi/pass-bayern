-- extended event to find inaccurate cardinality estimates
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'InaccurateCardinalityEstimates')
	DROP EVENT SESSION InaccurateCardinalityEstimates ON SERVER;
GO

-- create event session
CREATE EVENT SESSION InaccurateCardinalityEstimates
ON SERVER 
ADD EVENT sqlserver.inaccurate_cardinality_estimate(
	ACTION (sqlserver.plan_handle, sqlserver.sql_text
	)
)
ADD TARGET package0.ring_buffer 
-- WITH (STARTUP_STATE = ON);
GO

ALTER EVENT SESSION InaccurateCardinalityEstimates
ON SERVER STATE = START;

-- run workload query

-- read the data from the ring buffer
SELECT
	CAST(st.target_data AS XML) AS target_data
FROM sys.dm_xe_session_targets st
INNER JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
INNER JOIN sys.server_event_sessions ses ON s.name = ses.name
WHERE st.target_name = 'ring_buffer'
AND s.name = 'InaccurateCardinalityEstimates';
GO

-- query the XML to get the target data
SELECT 
	--event_data.value('(@name)[1]','varchar(50)') AS event_name, 
	DATEADD(hh,DATEDIFF(hh,GETUTCDATE(),CURRENT_TIMESTAMP),event_data.value('(@timestamp)[1]','datetime2')) AS [timestamp], 
	event_data.value('(data[@name="estimated_rows"]/value)[1]','int') AS estimated_rows, 
	event_data.value('(data[@name="actual_rows"]/value)[1]','int') AS actual_rows, 
	event_data.value('(data[@name="node_id"]/value)[1]','int') AS node_id, 
	event_data.value('(data[@name="fire_count"]/value)[1]','int') AS fire_count, 
	event_data.value('xs:hexBinary((action[@name="plan_handle"]/value)[1])','varbinary(64)') AS plan_handle,
	event_data.value('(action[@name="sql_text"]/value)[1]','nvarchar(max)') AS sql_text
FROM (
	SELECT CAST(target_data AS XML) target_data 
	FROM sys.dm_xe_sessions s 
	INNER JOIN sys.dm_xe_session_targets t 
	ON s.address = t.event_session_address 
	WHERE s.name = 'InaccurateCardinalityEstimates' 
	AND t.target_name = 'ring_buffer' 
) AS tab 
CROSS APPLY target_data.nodes ('RingBufferTarget/event') AS p(event_data);
GO

-- check the query plan
SELECT
	query_plan
FROM sys.dm_exec_query_plan (<plan_handle>);

-- stop the event session
ALTER EVENT SESSION InaccurateCardinalityEstimates ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION InaccurateCardinalityEstimates ON SERVER;
GO