USE AdventureWorks;
GO

-- create procedure to generate a lot of statement level events
IF OBJECT_ID(N'ExecuteLotsOfStatements') IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.ExecuteLotsOfStatements
END
GO
CREATE PROCEDURE dbo.ExecuteLotsOfStatements
(@ExecutionLoopCount INT = 1000)
AS
	DECLARE @Loop1 INT = 0;
	DECLARE @Loop2 INT;
	WHILE @Loop1 < @ExecutionLoopCount
	BEGIN
		SELECT @Loop2 = @Loop1;
	
		SET @Loop1 += 1;
	END
GO

-- if the event session exists drop it
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'XEOverhead')
	DROP EVENT SESSION XEOverhead ON SERVER;
GO

-- create an event session to capture statement events
CREATE EVENT SESSION XEOverhead
ON SERVER
ADD EVENT sqlserver.module_end(
	ACTION 
	(
			  sqlserver.client_app_name
			, sqlserver.client_pid
			, sqlserver.nt_username
			, sqlserver.server_principal_name
			, sqlserver.session_id
	)
),
ADD EVENT sqlserver.sp_statement_completed(
	ACTION 
	(
			  sqlserver.client_app_name
			, sqlserver.client_pid
			, sqlserver.nt_username
			, sqlserver.server_principal_name
			, sqlserver.session_id
	)
);
GO

-- start the event session
ALTER EVENT SESSION XEOverhead ON SERVER STATE = START;
GO

-- open the Live Data View for the session

-- run the following to generate a lot of statement events
EXECUTE dbo.ExecuteLotsOfStatements @ExecutionLoopCount = 1000000;
GO

-- stop the session and reconfigure it to have more memory
-- then run the test again

-- stop the event session
ALTER EVENT SESSION XEOverhead ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION XEOverhead ON SERVER;
GO
