-- extended event session to find long running queries
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'LongRunningQueries')
	DROP EVENT SESSION LongRunningQueries ON SERVER;
GO
 
-- create event session
CREATE EVENT SESSION LongRunningQueries
ON SERVER
ADD EVENT sqlserver.sql_statement_completed
(
	ACTION (sqlserver.sql_text, sqlserver.tsql_stack)
	WHERE sqlserver.sql_statement_completed.duration > 1000000  -- 1000000 microseconds to get > 1s
)
ADD TARGET package0.event_file
	(SET FILENAME = N'C:\Temp\LongRunningQueries.xel'), -- METADATAFILE = N'C:\Temp\LongRunningQueries.xem'),
ADD TARGET package0.ring_buffer
	(SET MAX_MEMORY = 4096)	WITH (MAX_DISPATCH_LATENCY = 1 SECONDS);
GO

-- enable event session 
ALTER EVENT SESSION LongRunningQueries ON SERVER STATE = START;
GO

-- run long running query (> 1000 ms)
 
-- read the data from the ring buffer
SELECT CAST(st.target_data AS XML) AS target_data_xml
FROM sys.dm_xe_session_targets st
INNER JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
INNER JOIN sys.server_event_sessions ses ON s.name = ses.name
WHERE st.target_name = 'ring_buffer'
AND s.name = 'LongRunningQueries';
GO

-- read the data from the XML file
SELECT 
	event_data,
	event_data.value('(event/@timestamp)[1]','datetime2') AS timestamp,
	CAST(event_data.value('(event/data[@name="duration"])[1]','int')/1000.0 AS decimal(12,2)) AS duration_ms,
	CAST(event_data.value('(event/data[@name="cpu_time"])[1]','int')/1000.0 AS decimal(12,2)) AS cpu_time_ms,
	event_data.value('(event/data[@name="physical_reads"])[1]','int') AS physical_reads,
	event_data.value('(event/data[@name="logical_reads"])[1]','int') AS logical_reads,
	event_data.value('(event/data[@name="writes"])[1]','int') AS writes,
	event_data.value('(event/data[@name="row_count"])[1]','int') AS row_count,
	event_data.value('(event/data[@name="statement"])[1]', 'nvarchar(max)') AS statement
	--event_data.value('(./@handle)', 'varchar(max)') AS sql_handle
	-- , st.text
FROM
(
	SELECT CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file
	-- ('C:\Temp\LongRunningQueries*.xel', 'C:\Temp\LongRunningQueries*.xem', NULL, NULL)
	('C:\Temp\LongRunningQueries*.xel', NULL, NULL, NULL)
) T
CROSS APPLY event_data.nodes('event/action[@name="tsql_stack"]/value/frames/frame') (frame_data_xml)
-- CROSS APPLY sys.dm_exec_sql_text(frame_data_xml.value('xs:hexBinary(substring(./@handle, 3))', 'varbinary(max)')) st
GO
 
-- stop the event session
ALTER EVENT SESSION LongRunningQueries ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION LongRunningQueries ON SERVER;
GO

EXECUTE sys.sp_configure 'show advanced options', 1;
RECONFIGURE;
 
EXECUTE sys.sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

EXECUTE sys.xp_cmdshell 'DEL C:\Temp\LongRunningQueries*';
GO

EXECUTE sys.sp_configure 'xp_cmdshell', 0;
RECONFIGURE;

EXECUTE sys.sp_configure 'show advanced options', 0;
RECONFIGURE;