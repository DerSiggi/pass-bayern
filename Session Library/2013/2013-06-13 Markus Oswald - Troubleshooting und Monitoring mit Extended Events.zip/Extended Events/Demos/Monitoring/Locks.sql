-- -- extended event session to find blocking queries
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'FindBlockers')
    DROP EVENT SESSION FindBlockers ON SERVER;
GO

-- create the event session and allow creating a predicate on the AdventureWorks database id.
DECLARE @dbid int = DB_ID('AdventureWorks');

IF @dbid IS NULL
BEGIN
    RAISERROR('AdventureWorks is not installed. Install AdventureWorks before proceeding', 17, 1);
    RETURN
END

DECLARE @sql nvarchar(1024);
SET @sql = '
CREATE EVENT SESSION FindBlockers ON SERVER
ADD EVENT sqlserver.lock_acquired 
    (ACTION 
        ( sqlserver.sql_text, sqlserver.database_id, sqlserver.tsql_stack,
         sqlserver.plan_handle, sqlserver.session_id)
    WHERE ( database_id=' + CAST(@dbid AS nvarchar) + ' AND resource_0!=0) 
    ),
ADD EVENT sqlserver.lock_released 
    (WHERE ( database_id=' + CAST(@dbid AS nvarchar) + ' AND resource_0!=0 ))
ADD TARGET package0.pair_matching 
    ( SET begin_event=''sqlserver.lock_acquired'', 
            begin_matching_columns=''database_id, resource_0, resource_1, resource_2, transaction_id, mode'', 
            end_event=''sqlserver.lock_released'', 
            end_matching_columns=''database_id, resource_0, resource_1, resource_2, transaction_id, mode'',
    respond_to_memory_pressure=1)
WITH (MAX_DISPATCH_LATENCY = 1 SECONDS);'

EXEC (@sql);

-- start the event session
ALTER EVENT SESSION FindBlockers ON SERVER STATE = START;

-- run blocking queries

-- The pair matching targets report current unpaired events using 
-- the sys.dm_xe_session_targets dynamic management view (DMV) in XML format.
-- The following query retrieves the data from the DMV and stores
-- key data in a temporary table to speed subsequent access and retrieval.
SELECT 
	event_data.value('(action[@name="session_id"]/value)[1]', 'int') AS session_id,
    event_data.value('(data[@name="database_id"]/value)[1]', 'int') AS database_id,
    event_data.value('(data[@name="resource_type"]/text)[1]', 'nvarchar(50)' ) AS resource_type,
    event_data.value('(data[@name="resource_0"]/value)[1]', 'bigint') AS resource_0,
    event_data.value('(data[@name="resource_1"]/value)[1]', 'bigint') AS resource_1,
    event_data.value('(data[@name="resource_2"]/value)[1]', 'bigint') AS resource_2,
    event_data.value('(data[@name="mode"]/text)[1]', 'nvarchar(50)') AS mode,
    event_data.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS sql_text,
    event_data.value('xs:hexBinary((action[@name="plan_handle"]/value)[1])','varbinary(64)') AS plan_handle,
	CAST(event_data.value('(action[@name="tsql_stack"]/value)[1]', 'nvarchar(max)') AS xml) AS tsql_stack
INTO #XEResults
FROM
	(SELECT
		CAST(xest.target_data AS xml) lockinfo
     FROM sys.dm_xe_session_targets xest
     JOIN sys.dm_xe_sessions xes ON xes.address = xest.event_session_address
     WHERE xest.target_name = 'pair_matching' AND xes.name = 'FindBlockers'
	) AS locks
CROSS APPLY lockinfo.nodes('//event[@name="lock_acquired"]') AS T(event_data);

-- join the data acquired from the pairing target with other 
-- DMVs to return provide additional information about blockers
SELECT ul.*
    FROM #XEResults ul
    INNER JOIN sys.dm_tran_locks tl ON ul.database_id = tl.resource_database_id AND ul.resource_type = tl.resource_type COLLATE DATABASE_DEFAULT
    WHERE resource_0 IS NOT NULL
    AND session_id IN 
        (SELECT blocking_session_id	FROM sys.dm_exec_requests
			WHERE blocking_session_id != 0)
	AND tl.request_status='wait';

-- after identifying the issues, drop any temporary tables and the event session
DROP TABLE #XEResults;
DROP EVENT SESSION FindBlockers ON SERVER;