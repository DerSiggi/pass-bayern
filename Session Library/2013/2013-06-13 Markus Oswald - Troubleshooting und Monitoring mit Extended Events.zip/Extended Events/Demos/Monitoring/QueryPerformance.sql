-- extended event session to monitor query performance
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'QueryPerformance')
	DROP EVENT SESSION QueryPerformance ON SERVER;
GO

SELECT DB_ID('Performance') AS database_id;

-- create event session
CREATE EVENT SESSION QueryPerformance ON SERVER 
ADD EVENT sqlserver.sp_statement_completed(
    ACTION(sqlserver.query_hash)
    WHERE sqlserver.database_id = <database_id> AND sqlserver.query_hash <> 0),
ADD EVENT sqlserver.sql_statement_completed(
    ACTION(sqlserver.query_hash)
    WHERE sqlserver.database_id = <database_id> AND sqlserver.query_hash <> 0)
ADD TARGET package0.event_file(SET FILENAME = N'C:\Temp\QueryPerformance.xel');

-- enable event session
ALTER EVENT SESSION QueryPerformance ON SERVER STATE = START;
GO

-- run performance queries

-- extract query performance info into a temp table #Queries
SELECT
  event_data.value ('(/event/action[@name=''query_hash'']/value)[1]', 'BINARY(8)') AS query_hash,
  event_data.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT') AS duration,
  event_data.value ('(/event/data[@name=''cpu_time'']/value)[1]', 'BIGINT') AS cpu_time,
  event_data.value ('(/event/data[@name=''physical_reads'']/value)[1]', 'BIGINT') AS physical_reads,
  event_data.value ('(/event/data[@name=''logical_reads'']/value)[1]', 'BIGINT') AS logical_reads,
  event_data.value ('(/event/data[@name=''writes'']/value)[1]', 'BIGINT') AS writes,
  event_data.value ('(/event/data[@name=''row_count'']/value)[1]', 'BIGINT') AS row_count,
  event_data.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(4000)') AS statement
INTO #Queries
FROM (
	SELECT CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file('C:\Temp\QueryPerformance*.xel', NULL, NULL, NULL)
) AS queries;

CREATE CLUSTERED INDEX idx_cl_query_hash ON #Queries(query_hash);

-- examine query info
SELECT * FROM #Queries;

-- group by query hash and compute running total percent
SELECT
	query_hash,
	COUNT(*) AS num_queries,
	SUM(logical_reads) AS sum_logical_reads,
	CAST(100.0 * SUM(logical_reads)
             / SUM(SUM(logical_reads)) OVER() AS NUMERIC(5, 2)) AS pct,
	CAST(100.0 * SUM(SUM(logical_reads)) OVER(ORDER BY SUM(logical_reads) DESC
                                            ROWS UNBOUNDED PRECEDING)
             / SUM(SUM(logical_reads)) OVER()
       AS NUMERIC(5, 2)) AS running_pct
FROM #Queries
GROUP BY query_hash
ORDER BY sum_logical_reads DESC;

-- simplified
WITH QueryHashTotals AS
(
  SELECT
	query_hash,
    COUNT(*) AS num_queries,
    SUM(logical_reads) AS sum_logical_reads
  FROM #Queries
  GROUP BY query_hash
)
SELECT query_hash, num_queries, sum_logical_reads,
  CAST(100. * sum_logical_reads
            / SUM(sum_logical_reads) OVER()
       AS NUMERIC(5, 2)) AS pct,
  CAST(100. * SUM(sum_logical_reads) OVER(ORDER BY sum_logical_reads DESC
                                          ROWS UNBOUNDED PRECEDING)
            / SUM(sum_logical_reads) OVER()
       AS NUMERIC(5, 2)) AS running_pct
FROM QueryHashTotals
ORDER BY sum_logical_reads DESC;

-- filter and include a sample query
WITH QueryHashTotals AS
(
  SELECT
	query_hash,
    COUNT(*) AS num_queries,
    SUM(logical_reads) AS sum_logical_reads
  FROM #Queries
  GROUP BY query_hash
),
RunningTotals AS
(
  SELECT query_hash, num_queries, sum_logical_reads,
    CAST(100. * sum_logical_reads
              / SUM(sum_logical_reads) OVER()
         AS NUMERIC(5, 2)) AS pct,
    CAST(100. * SUM(sum_logical_reads) OVER(ORDER BY sum_logical_reads DESC
                                             ROWS UNBOUNDED PRECEDING)
              / SUM(sum_logical_reads) OVER()
         AS NUMERIC(5, 2)) AS running_pct
  FROM QueryHashTotals
)
SELECT RT.*, (SELECT TOP (1) statement
              FROM #Queries AS Q
              WHERE Q.query_hash = RT.query_hash) AS sample_statement
FROM RunningTotals AS RT
WHERE running_pct - pct < 80.00
ORDER BY sum_logical_reads DESC;

-- create clustered index
USE Performance;
GO
CREATE CLUSTERED INDEX idx_cl_od ON dbo.Orders(orderdate);

-- cleanup
DROP TABLE #Queries;

-- stop the event
ALTER EVENT SESSION QueryPerformance ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION QueryPerformance ON SERVER;
GO

EXECUTE sys.sp_configure 'show advanced options', 1;
RECONFIGURE;
 
EXECUTE sys.sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

EXECUTE sys.xp_cmdshell 'DEL C:\Temp\QueryPerformance*';
GO

EXECUTE sys.sp_configure 'xp_cmdshell', 0;
RECONFIGURE;

EXECUTE sys.sp_configure 'show advanced options', 0;
RECONFIGURE;