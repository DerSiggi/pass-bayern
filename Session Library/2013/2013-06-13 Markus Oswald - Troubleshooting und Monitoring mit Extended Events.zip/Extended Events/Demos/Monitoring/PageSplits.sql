/*
When we look at page splits, we should differentiate between an end page split that occurs for an ever increasing index,
versus a mid-page split for a random index that leads to fragmentation and page density issues in the database.
Both of these are technically splits inside the storage engine,
even if we as DBA�s don�t really care about the end-page split for a increasing key value like an IDENTITY column in the database.
Pulling out the mid-page, fragmenting splits is incredibly simple using the sqlserver.transaction_log event,
which can be used to track mid-page splits in a database.
*/
SELECT 
    oc.name, 
    oc.type_name, 
    oc.description
FROM sys.dm_xe_packages AS p
INNER JOIN sys.dm_xe_objects AS o
    ON p.guid = o.package_guid
INNER JOIN sys.dm_xe_object_columns AS oc
    ON oc.object_name = o.name
        AND oc.object_package_guid = o.package_guid
WHERE o.name = 'transaction_log'
  AND oc.column_type = 'data';

/* 
For the purposes of identifying the mid-page splits, we want to look at the operation column that is output by the event,
which contains the specific operation being logged.
In the case of a mid-page split occurring, the operation will be a LOP_DELETE_SPLIT,
which marks the delete of rows from a page as a result of the split.
To build our event session, we are going to need the map_key for the LOP_DELETE_SPLIT log_op map.
This can be obtained from the sys.dm_xe_map_values DMV:
*/
SELECT *
FROM sys.dm_xe_map_values
WHERE name = 'log_op'
  AND map_value = 'LOP_DELETE_SPLIT';

/*
With the map_key value, we have a couple of ways to collect the information with our targets.
We could collect everything into an event_file, but that doesn�t really make sense for this event.
Instead the best target for this type of information is the histogram target
which will bucket our results based on how we configure the target and tell us how frequently the event fires based on our bucketing criteria.
If we don�t know anything about the server in question,
we can start off with a very general event session that has a predicate on the operation only,
and then aggregate the information in the histogram target based on the database_id to find the databases
that have the most mid-page splits occurring in them in the instance.
*/

-- drop the event session
IF EXISTS (SELECT 1 FROM sys.server_event_sessions 
            WHERE name = 'TrackPageSplits')
    DROP EVENT SESSION TrackPageSplits ON SERVER;

-- create the event session to track LOP_DELETE_SPLIT transaction_log operations in the server
CREATE EVENT SESSION TrackPageSplits
ON SERVER
ADD EVENT sqlserver.transaction_log (
    WHERE operation = 11  -- LOP_DELETE_SPLIT 
)
ADD TARGET package0.histogram (
    SET filtering_event_name = 'sqlserver.transaction_log',
        source_type = 0, -- Event Column
        source = 'database_id');
GO
        
-- start the event session
ALTER EVENT SESSION TrackPageSplits ON SERVER STATE = START;
GO

/*
This event session will allow you to track the worst splitting database on the server,
and the event data can be parsed out of the histogram target.
To demonstrate this, we can create a database that has tables and indexes prone to mid-page splits
and run a default workload to test the event session:
*/
USE master;
GO

-- drop the PageSplits database if it exists
IF DB_ID('PageSplits') IS NOT NULL
BEGIN
    ALTER DATABASE PageSplits SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE PageSplits;
END
GO

-- create the database
CREATE DATABASE PageSplits;
GO

USE PageSplits;
GO

-- create a mid splitting clustered index table
CREATE TABLE MidSplits
(
	RowID UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID()
		CONSTRAINT PK_MidSplits_RowID_MidSplitting PRIMARY KEY CLUSTERED,
	ColVal INT NOT NULL DEFAULT (RAND()*1000),
	ChangeDate DATETIME2 NOT NULL DEFAULT CURRENT_TIMESTAMP
);
GO

--  this index should mid-split based on the DEFAULT column value
CREATE INDEX IX_MidSplits_ColVal_MidSplitting ON MidSplits (ColVal);
GO

-- this index should end-split based on the DEFAULT column value
CREATE INDEX IX_MidSplits_ChangeDate_EndSplitting ON MidSplits (ChangeDate);
GO

-- create a table with an increasing clustered index
CREATE TABLE EndSplits
(
	RowID INT IDENTITY NOT NULL
		CONSTRAINT PK_EndSplits_RowID PRIMARY KEY CLUSTERED,
	ColVal INT NOT NULL DEFAULT (RAND()*1000),
	ChangeDate DATETIME2 NOT NULL DEFAULT DATEADD(mi, RAND()*-1000, CURRENT_TIMESTAMP)
);
GO

-- this index should mid-split based on the DEFAULT column value
CREATE INDEX IX_EndSplits_ChangeDate_MidSplitting ON EndSplits (ChangeDate);
GO

-- run workload query

/*
If we startup this workload and allow it to run for a couple of minutes,
we can then query the histogram target for our session to find the database
that has the mid-page splits occurring.
*/

-- query the target data to identify the worst splitting database_id
SELECT 
    n.value('(value)[1]', 'bigint') AS database_id,
    DB_NAME(n.value('(value)[1]', 'bigint')) AS database_name,
    n.value('(@count)[1]', 'bigint') AS split_count
FROM
(SELECT CAST(target_data AS XML) target_data
 FROM sys.dm_xe_sessions AS s 
 JOIN sys.dm_xe_session_targets t
     ON s.address = t.event_session_address
 WHERE s.name = 'TrackPageSplits'
  AND t.target_name = 'histogram' ) AS tab
CROSS APPLY target_data.nodes('HistogramTarget/Slot') AS q(n);
 
/*
With the database_id of the worst splitting database,
we can then change our event session configuration to only look at this database,
and then change our histogram target configuration to bucket on the alloc_unit_id
so that we can then track down the worst splitting indexes in the database experiencing the worst mid-page splits.
*/

PRINT DB_ID('PageSplits');

-- drop the event session so we can recreate it to focus on the highest splitting database
DROP EVENT SESSION TrackPageSplits ON SERVER;

-- create the event session to track LOP_DELETE_SPLIT transaction_log operations in the server
CREATE EVENT SESSION TrackPageSplits ON SERVER
ADD EVENT sqlserver.transaction_log(
    WHERE operation = 11  -- LOP_DELETE_SPLIT 
      AND database_id = 11 -- CHANGE THIS BASED ON TOP SPLITTING DATABASE!
)
ADD TARGET package0.histogram(
    SET filtering_event_name = 'sqlserver.transaction_log',
        source_type = 0, -- Event Column
        source = 'alloc_unit_id');
GO

-- start the event session again
ALTER EVENT SESSION TrackPageSplits ON SERVER STATE = START;
GO

-- run workload query

-- query Target Data to get the top splitting objects in the database
SELECT
    o.name AS table_name,
    i.name AS index_name,
    tab.split_count,
    i.fill_factor
FROM (SELECT 
            n.value('(value)[1]', 'bigint') AS alloc_unit_id,
            n.value('(@count)[1]', 'bigint') AS split_count
        FROM
        (SELECT CAST(target_data AS XML) target_data
         FROM sys.dm_xe_sessions AS s 
         JOIN sys.dm_xe_session_targets t
             ON s.address = t.event_session_address
         WHERE s.name = 'TrackPageSplits'
          AND t.target_name = 'histogram' ) As tab
        CROSS APPLY target_data.nodes('HistogramTarget/Slot') AS q(n)
) AS tab
INNER JOIN sys.allocation_units AS au
    ON tab.alloc_unit_id = au.allocation_unit_id
INNER JOIN sys.partitions AS p
    ON au.container_id = p.partition_id
INNER JOIN sys.indexes AS i
    ON p.object_id = i.object_id
        AND p.index_id = i.index_id
INNER JOIN sys.objects AS o
    ON p.object_id = o.object_id
WHERE o.is_ms_shipped = 0;

-- look at the index fragmentation
SELECT
	OBJECT_NAME (ips.[object_id],
	DB_ID ('PageSplits')) AS 'object_name',
	i.name AS 'index_name',
	-- ips.alloc_unit_type_desc,
	ROUND (ips.avg_fragmentation_in_percent, 2) AS 'fragmentation',
	ips.page_count AS 'pages',
	ROUND (ips.avg_page_space_used_in_percent, 2) AS 'page_density',
	ips.record_count AS 'records'
FROM sys.dm_db_index_physical_stats (
	DB_ID ('PageSplits'),
	NULL,
	NULL,
	NULL,
	'DETAILED') ips
CROSS APPLY PageSplits.sys.indexes i
WHERE
	i.object_id = ips.object_id
	AND i.index_id = ips.index_id
    AND ips.index_level = 0
	ORDER BY [object_name], [index_name] ASC;
GO
 
/*
With this information we can now go back and change our FillFactor specifications and retest/monitor the impact
to determine whether we�ve had the appropriate reduction in mid-page splits
to accommodate the time between our index rebuild operations
*/

-- Change FillFactor based on split occurences
ALTER INDEX PK_MidSplits_RowID_MidSplitting ON MidSplits REBUILD
	WITH (FILLFACTOR = 70);
ALTER INDEX IX_MidSplits_ColVal_MidSplitting ON MidSplits REBUILD
	WITH (FILLFACTOR = 70);
ALTER INDEX IX_EndSplits_ChangeDate_MidSplitting ON EndSplits REBUILD
	WITH (FILLFACTOR = 80);
GO

-- stop the event session to clear the target
ALTER EVENT SESSION TrackPageSplits ON SERVER STATE = STOP;
GO

-- start the event session again
ALTER EVENT SESSION TrackPageSplits ON SERVER STATE = START;
GO

/*
With the reset performed we can again start up our workload generation
and begin monitoring the effect of the FillFactor specifications on the indexes with our code.
With this information we can go back and again attempt to tune our FillFactor values for the worst splitting indexes
and rinse/repeat until we determine the best FillFactor for each of the indexes to minimize splits.
This is an incredibly powerful tool for the DBA moving into SQL Server 2012,
and will definitely change how we perform index fragmentation analysis and troubleshoot problems with excessive log generation in SQL Server 2012 onwards.
*/

-- cleanup
USE master;
GO

IF EXISTS (SELECT 1 FROM sys.server_event_sessions 
	    WHERE name = 'TrackPageSplits')
	BEGIN
		ALTER EVENT SESSION TrackPageSplits ON SERVER STATE = STOP;
		DROP EVENT SESSION TrackPageSplits ON SERVER;
	END

IF DB_ID('PageSplits') IS NOT NULL
	BEGIN
		ALTER DATABASE PageSplits SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
		DROP DATABASE PageSplits;
	END
