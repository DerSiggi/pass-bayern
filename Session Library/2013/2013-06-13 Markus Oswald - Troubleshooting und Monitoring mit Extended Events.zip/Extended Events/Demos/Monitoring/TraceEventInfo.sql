-- view running traces on the system
SELECT * FROM sys.traces;

-- get trace event info
SELECT 
 	e.name AS event_name, 
 	c.name AS column_name
FROM fn_trace_geteventinfo(<traceid>) i
INNER JOIN sys.trace_events e ON i.eventid = e.trace_event_id 
INNER JOIN sys.trace_columns c ON i.columnid = c.trace_column_id;

-- read trace file
SELECT
	e.Name,
	t.DatabaseName,
	t.NTUserName,
	t.ApplicationName,
	t.CPU,
	t.Duration,
	t.Reads,
	t.RowCounts,
	t.Writes,
	t.TextData
FROM ::fn_trace_gettable('C:\Temp\TS_<MachineName>.trc', default) t
JOIN sys.trace_events e ON t.EventClass = e.trace_event_id
WHERE t.Duration > 0
AND t.EventClass IN (12, 41, 45) -- 12 (SQL:BatchCompleted), 41 (SQL:StmtCompleted), 45 (SP:StmtCompleted)
-- AND t.EventClass = 137           -- 137 Blocked process report
-- AND e.name LIKE 'Blocked process report%'
-- AND t.Duration > 100 * POWER(10, 6);

-- stop the trace, but keep its definition on the server
EXEC sp_trace_setstatus <traceid>, 0;

-- close the trace and delete its definition from the server
EXEC sp_trace_setstatus <traceid>, 2;