USE master;
GO

IF DB_ID('Errors') IS NOT NULL
BEGIN
	ALTER DATABASE Errors SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE Errors;
END
GO
CREATE DATABASE Errors;
GO

USE Errors;
GO

-- create data truncation procedure
CREATE PROCEDURE dbo.StringTruncation
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @SourceTable TABLE
	(
		RowValue CHAR(100) NOT NULL DEFAULT(REPLICATE('A', 100))
	);

	INSERT INTO @SourceTable DEFAULT VALUES;

	DECLARE @TargetTable TABLE
	(
		RowValue VARCHAR(50) NOT NULL
	);

	INSERT INTO @TargetTable(RowValue)
	SELECT RowValue FROM @SourceTable;
END
GO

-- extended event session to find errors reported
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name = 'ErrorReported')
	DROP EVENT SESSION ErrorReported ON SERVER;
GO

-- create the event session
CREATE EVENT SESSION ErrorReported
ON SERVER
ADD EVENT sqlserver.error_reported
(
	ACTION (
		sqlserver.session_id,
		sqlserver.query_hash,
		sqlserver.sql_text,
		sqlserver.tsql_stack,
		sqlserver.client_app_name,
		sqlserver.client_hostname,
		sqlserver.database_id,
		sqlserver.username)
WHERE
(severity > 10 AND severity < 20) -- anything above 20 is captured by the system_health session
AND [error_number] = 8152)
ADD TARGET package0.ring_buffer
	(SET MAX_MEMORY = 4096)	WITH (MAX_DISPATCH_LATENCY = 1 SECONDS);
GO

-- enable the event session 
ALTER EVENT SESSION ErrorReported ON SERVER STATE = START;

-- execute the procedure to generate an error
EXECUTE dbo.StringTruncation;
GO

-- read the data from ring buffer
SELECT
	DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), 
	n.value('(@timestamp)[1]', 'datetime2')) AS 'timestamp', 
    n.value('(data[@name="error_number"]/value)[1]', 'int') AS 'error_number',
    n.value('(data[@name="severity"]/value)[1]', 'smallint') AS severity,
    n.value('(data[@name="message"]/value)[1]', 'nvarchar(250)') AS 'error_message',
    n.value('(action[@name="session_id"]/value)[1]', 'int') AS session_id,
    n.value('(action[@name="database_id"]/value)[1]', 'int') AS database_id,
    n.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS sql_text,
    n.value('(action[@name="client_hostname"]/value)[1]', 'nvarchar(128)') AS client_hostname,
    n.value('(action[@name="username"]/value)[1]', 'nvarchar(128)') AS username
FROM
	(SELECT
		CAST(st.target_data AS XML) AS target_data
	 FROM sys.dm_xe_sessions AS s 
	 INNER JOIN sys.dm_xe_session_targets AS st
       ON s.address = st.event_session_address
	 WHERE s.name = N'ErrorReported'
	 AND st.target_name = N'ring_buffer'
	) AS tab
CROSS APPLY target_data.nodes('RingBufferTarget/event') AS q(n);

-- stop the event
ALTER EVENT SESSION ErrorReported ON SERVER STATE = STOP;
GO
 
-- cleanup
USE master;
GO

DROP EVENT SESSION ErrorReported ON SERVER;
GO

IF DATABASEPROPERTYEX ('Errors', 'Version') > 0
BEGIN
	ALTER DATABASE Errors SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE Errors;
END
GO