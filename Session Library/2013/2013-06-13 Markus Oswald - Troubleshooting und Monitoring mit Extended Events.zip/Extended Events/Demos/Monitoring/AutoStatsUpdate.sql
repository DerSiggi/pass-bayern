-- extended event to capture autostats update
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'AutoStatsUpdate')
	DROP EVENT SESSION AutoStatsUpdate ON SERVER;
GO

-- create event session
CREATE EVENT SESSION AutoStatsUpdate
ON SERVER 
ADD EVENT sqlserver.auto_stats(SET collect_database_name=(1)
    ACTION(sqlserver.sql_text)
	) 
ADD TARGET package0.ring_buffer
WITH (MAX_MEMORY = 4096 KB)
GO

ALTER EVENT SESSION AutoStatsUpdate
ON SERVER STATE = START;

-- run workload queries

-- read the data from the ring buffer
SELECT
	CAST(st.target_data AS XML) AS target_data
FROM sys.dm_xe_session_targets st
INNER JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
INNER JOIN sys.server_event_sessions ses ON s.name = ses.name
WHERE st.target_name = 'ring_buffer'
AND s.name = 'AutoStatsUpdate';
GO

-- query the XML to get the target data
SELECT
	DATEADD(hh,DATEDIFF(hh,GETUTCDATE(),CURRENT_TIMESTAMP),event_data.value('(@timestamp)[1]','datetime2')) AS [timestamp], 
	event_data.value('(data[@name="count"]/value)[1]','int') AS [count], 
	event_data.value('(data[@name="database_name"]/value)[1]','nvarchar(128)') AS database_name, 
	CAST(event_data.value('(data[@name="duration"]/value)[1]', 'bigint')/1000.0 AS decimal(12,2)) AS duration_ms,
	event_data.value('(data[@name="index_id"]/value)[1]','int') AS index_id, 
	event_data.value('(data[@name="error"]/value)[1]','int') AS error, 
	event_data.value('(data[@name="object_id"]/value)[1]','int') AS [object_id], 
	event_data.value('(data[@name="statistics_list"]/value)[1]','nvarchar(128)') AS statistics_list,
	event_data.value('(data[@name="success"]/value)[1]','bit') AS success,
	event_data.value('(action[@name="sql_text"]/value)[1]','nvarchar(max)') AS sql_text
FROM (
	SELECT CAST(target_data AS XML) target_data 
	FROM sys.dm_xe_sessions s 
	INNER JOIN sys.dm_xe_session_targets t 
	ON s.address = t.event_session_address 
	WHERE s.name = 'AutoStatsUpdate' 
	AND t.target_name = 'ring_buffer' 
) AS tab 
CROSS APPLY target_data.nodes ('RingBufferTarget/event') AS p(event_data);
GO

-- stop the event session
ALTER EVENT SESSION AutoStatsUpdate ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION AutoStatsUpdate ON SERVER;
GO