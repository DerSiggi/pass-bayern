-- return all available packages
SELECT *
FROM sys.dm_xe_packages
WHERE (capabilities IS NULL OR capabilities <> 1);

-- return all available events
SELECT p.name AS package, c.event, k.keyword, c.channel, c.description
FROM
(
	SELECT event_package=o.package_guid, o.description,
		   event=c.object_name, channel=v.map_value
	FROM sys.dm_xe_objects o
		   LEFT JOIN sys.dm_xe_object_columns c ON o.name = c.object_name
		   INNER JOIN sys.dm_xe_map_values v ON c.type_name = v.name
				  AND c.column_value = cast(v.map_key AS nvarchar)
	WHERE object_type = 'event' AND (c.name = 'channel' OR c.name IS NULL)
) c LEFT JOIN
(
    SELECT event_package=c.object_package_guid, event=c.object_name,
            keyword=v.map_value
    FROM sys.dm_xe_object_columns c INNER JOIN sys.dm_xe_map_values v
    ON c.type_name = v.name AND c.column_value = v.map_key
            AND c.type_package_guid = v.object_package_guid
    INNER JOIN sys.dm_xe_objects o ON o.name = c.object_name
            AND o.package_guid=c.object_package_guid
    WHERE object_type = 'event' AND c.name = 'keyword'
) k
ON
k.event_package = c.event_package AND (k.event = c.event OR k.event IS NULL)
INNER JOIN sys.dm_xe_packages p ON p.guid = c.event_package
WHERE (p.capabilities IS NULL OR p.capabilities & 1 = 0)
ORDER BY channel, keyword, event;

-- each event has a set of columns that can be found in the sys.dm_xe_object_columns table.
-- There are three types of columns that can exist for an event.
-- The first type is a read-only column which is a set of descriptor columns that provide information about the event like the event ID, UUID, version, channel, and keyword. 
SELECT
	p.name AS package_name,
    o.name AS event_name,
    c.column_id,
    c.column_type,
    c.name column_name,
    c.column_value,
    c.description
FROM sys.dm_xe_objects o
       INNER JOIN sys.dm_xe_packages p
              ON o.package_guid = p.guid
       INNER JOIN sys.dm_xe_object_columns c
              ON o.name = c.object_name
WHERE o.object_type = 'event'
  AND c.column_type = 'readonly'
  AND (p.capabilities IS NULL OR p.capabilities <> 1)
ORDER BY package_name, event_name, column_type, column_id;

-- the second type of column is the data column, which defines the default payload or column set that is collected when the event fires.
-- these columns are automatically included with the event details when they are dispatched to the session targets.
SELECT
	p.name AS package_name,
    o.name AS event_name,
    c.column_id,
    c.column_type,
    c.name AS column_name
FROM sys.dm_xe_objects o
       INNER JOIN sys.dm_xe_packages p
              ON o.package_guid = p.guid
       INNER JOIN sys.dm_xe_object_columns c
              ON o.name = c.object_name
WHERE o.object_type = 'event'
  AND c.column_type = 'data'
  AND (p.capabilities IS NULL OR p.capabilities <> 1)
ORDER BY package_name, event_name, column_type, column_id;

-- system health events selected by the Microsoft CSS team
-- when the ring_buffer target gets to 4MB,
-- the oldest events are flushed from the target and overwritten
SELECT CAST(xet.target_data AS xml) AS target_data_xml
FROM sys.dm_xe_session_targets xet
       INNER JOIN sys.dm_xe_sessions xe
              ON (xe.address = xet.event_session_address)
WHERE xe.name = 'system_health';

-- event mapping
-- view to retrieve information about how SQL Trace event classes are related to XEvents
SELECT
	te.name,
	em.package_name,
	em.xe_event_name
FROM sys.trace_events te
LEFT JOIN sys.trace_xe_event_map em
	ON te.trace_event_id = em.trace_event_id
WHERE em.trace_event_id IS NOT NULL;

-- action mapping
-- view to retrieve information about how SQL Trace columns are related to actions
SELECT
	tc.name AS trace_column,
	am.package_name,
	am.xe_action_name
FROM sys.trace_columns tc
INNER JOIN sys.trace_xe_action_map am
	ON tc.trace_column_id = am.trace_column_id;