USE master;
GO

-- create a queue
DECLARE
    @rc INT,
    @TraceID INT,
    @TraceName NVARCHAR(245) = N'C:\Temp\TS_' +
        CONVERT(SYSNAME, SERVERPROPERTY('MachineName')),
    @MaxFileSize BIGINT = 200,
	@FileCount INT = 5;

-- the .trc extension will be appended to the filename automatically
EXEC @rc = sp_trace_create @TraceID OUTPUT, 2, @TraceName, @MaxFileSize, NULL, @FileCount;

-- set the events
EXEC sp_trace_setevent @TraceID, 10, 16, 1;
EXEC sp_trace_setevent @TraceID, 10, 48, 1;
EXEC sp_trace_setevent @TraceID, 10, 1,  1;
EXEC sp_trace_setevent @TraceID, 10, 17, 1;
EXEC sp_trace_setevent @TraceID, 10, 10, 1;
EXEC sp_trace_setevent @TraceID, 10, 18, 1;
EXEC sp_trace_setevent @TraceID, 10, 3,  1;
EXEC sp_trace_setevent @TraceID, 10, 11, 1;
EXEC sp_trace_setevent @TraceID, 10, 35, 1;
EXEC sp_trace_setevent @TraceID, 10, 12, 1;
EXEC sp_trace_setevent @TraceID, 10, 13, 1;
EXEC sp_trace_setevent @TraceID, 10, 6,  1;
EXEC sp_trace_setevent @TraceID, 45, 16, 1;
EXEC sp_trace_setevent @TraceID, 45, 48, 1;
EXEC sp_trace_setevent @TraceID, 45, 1,  1;
EXEC sp_trace_setevent @TraceID, 45, 17, 1;
EXEC sp_trace_setevent @TraceID, 45, 10, 1;
EXEC sp_trace_setevent @TraceID, 45, 18, 1;
EXEC sp_trace_setevent @TraceID, 45, 3,  1;
EXEC sp_trace_setevent @TraceID, 45, 11, 1;
EXEC sp_trace_setevent @TraceID, 45, 35, 1;
EXEC sp_trace_setevent @TraceID, 45, 12, 1;
EXEC sp_trace_setevent @TraceID, 45, 28, 1;
EXEC sp_trace_setevent @TraceID, 45, 13, 1;
EXEC sp_trace_setevent @TraceID, 45, 6,  1;
EXEC sp_trace_setevent @TraceID, 12, 16, 1;
EXEC sp_trace_setevent @TraceID, 12, 48, 1;
EXEC sp_trace_setevent @TraceID, 12, 1,  1;
EXEC sp_trace_setevent @TraceID, 12, 17, 1;
EXEC sp_trace_setevent @TraceID, 12, 6,  1;
EXEC sp_trace_setevent @TraceID, 12, 10, 1;
EXEC sp_trace_setevent @TraceID, 12, 18, 1;
EXEC sp_trace_setevent @TraceID, 12, 3,  1;
EXEC sp_trace_setevent @TraceID, 12, 11, 1;
EXEC sp_trace_setevent @TraceID, 12, 35, 1;
EXEC sp_trace_setevent @TraceID, 12, 12, 1;
EXEC sp_trace_setevent @TraceID, 12, 13, 1;

-- set the filters (reads > 1000)
DECLARE @Reads BIGINT = 1000;
EXEC sp_trace_setfilter @TraceID, 16, 0, 4, @Reads;

-- set the trace status to start
EXEC sp_trace_setstatus @TraceID, 1;

-- display trace id and trace name
SELECT TraceID = @TraceID, TraceFile = @TraceName + N'.trc';