-- lookup the map key for the NETWORK_IO wait type
SELECT map_key, map_value
FROM sys.dm_xe_map_values
WHERE map_value = N'NETWORK_IO'
  AND name = N'wait_types';
GO  

-- if the event session exists drop it
IF EXISTS (SELECT 1 FROM sys.server_event_sessions 
			WHERE name = N'TrackNetworkWaits_AppName')
	DROP EVENT SESSION TrackNetworkWaits_AppName ON SERVER;
GO

-- create event session to track network waits by application
CREATE EVENT SESSION TrackNetworkWaits_AppName
ON SERVER 
ADD EVENT sqlos.wait_info
(    
    ACTION(sqlos.scheduler_id, sqlserver.client_app_name)
    WHERE
        (opcode = 1 -- end events only
            AND duration > 0 AND (wait_type = 99) -- network waits
		)            
)
ADD TARGET package0.histogram(
	SET filtering_event_name = N'sqlos.wait_info',
		source_type = 1, -- action
		source = N'sqlserver.client_app_name');
GO

--CREATE EVENT SESSION [TrackNetworkWaits_HostName]
--ON SERVER 
--ADD EVENT  sqlos.wait_info
--(   
--    ACTION(sqlos.scheduler_id, sqlserver.client_hostname)
--    WHERE
--        (opcode = 1 -- end events only
--            AND duration > 0 AND (wait_type = 99) -- network waits
--		)            
--)
--ADD TARGET package0.histogram(
--	SET filtering_event_name = N'sqlos.wait_info',
--		source_type = 1, -- action
--		source = N'sqlserver.client_hostname');
--GO

-- start the event session
ALTER EVENT SESSION TrackNetworkWaits_AppName 
ON SERVER STATE = START;
GO

-- run the workload queries

-- query target data
SELECT 
    n.value('(value)[1]', 'nvarchar(4000)') AS application_name,
    n.value('(@count)[1]', 'int') AS network_wait_count
FROM
(SELECT CAST(target_data AS XML) target_data
 FROM sys.dm_xe_sessions AS s 
 JOIN sys.dm_xe_session_targets t
     ON s.address = t.event_session_address
 WHERE s.name = N'TrackNetworkWaits_AppName'
 -- WHERE s.name = N'TrackNetworkWaits_HostName'
   AND t.target_name = N'histogram') as tab
CROSS APPLY target_data.nodes('HistogramTarget/Slot') as q(n)
ORDER BY application_name;
GO

-- drop the event session
DROP EVENT SESSION TrackNetworkWaits_AppName
ON SERVER;
GO