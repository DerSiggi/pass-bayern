-- events collected by the default trace
SELECT DISTINCT
	e.trace_event_id,
    e.name
FROM sys.fn_trace_geteventinfo (1) t
     JOIN sys.trace_events e ON t.eventID = e.trace_event_id;
GO

-- current file name for existing traces
SELECT * FROM ::fn_trace_getinfo(0);

-- find out more about who/when/why a database is dropped or created
DECLARE @filename NVARCHAR(260);
SELECT
	@filename = CAST(value AS NVARCHAR(260))
FROM ::fn_trace_getinfo(default)
WHERE traceid = 1 AND property = 2;
 
-- get information about CREATE/DROP database
SELECT
	spid, loginname, ntusername, ntdomainname, hostname,
	applicationname, starttime, servername, databasename
      ,CASE eventclass
            WHEN 46 THEN 'CREATE'
            WHEN 47 THEN 'DROP'
            ELSE 'OTHER'
       END AS eventclass
      , CASE objecttype
            WHEN 16964 THEN 'DATABASE'
            ELSE 'OTHER'
       END AS objecttype
FROM fn_trace_gettable(@filename, default)
WHERE objecttype = 16964 /* Database */ AND eventsubclass = 1 /* Committed */
ORDER BY starttime ASC;
GO