/*============================================================================
	File:		0060 - demonstration of SOS_SCHEDULER_YIELD.sql

	Summary:	This script monitors / forces the 
				SOS_SCHEDULER_YIELD wait stat

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- Flush any data from the buffer pool to disk!
DBCC DROPCLEANBUFFERS;
GO

-- Start the wait stats analysis session (WATCH YOUR SPID!)
EXEC master..sp_CreateXESession @SPID = @@SPID;
GO

DECLARE	@Name			VARCHAR(255);
DECLARE	@OrderYear		INT;
DECLARE	@Orders			INT;
DECLARE	@OrderAmount	MONEY;

SELECT	@Name			= C.Name,
		@OrderYear		= YEAR(CO.OrderDate),
		@Orders			= COUNT_BIG(DISTINCT CO.Id),
		@OrderAmount	= SUM(COD.Quantity * COD.Price)
FROM	dbo.Customers AS C
		INNER JOIN dbo.CustomerOrders AS CO ON (C.Id = CO.Customer_Id)
		INNER JOIN dbo.CustomerOrderDetails AS COD ON (CO.Id = COD.Order_Id)
GROUP BY
		C.Name,
		YEAR(CO.OrderDate);

-- Stop the wait stats analysis session
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO
