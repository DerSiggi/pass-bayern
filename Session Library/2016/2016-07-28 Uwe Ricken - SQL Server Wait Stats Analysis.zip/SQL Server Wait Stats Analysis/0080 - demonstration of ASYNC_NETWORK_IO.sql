/*============================================================================
	File:		0060 - demonstration of ASYNC_NETWORK_IO.sql

	Summary:	This script restores from an existing backup of a "large"
				database with customers and orders

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- Start the Microsoft Acces Application and open any SMALL table
-- to check the session_id of the application!
SELECT	C.most_recent_session_id,
		DEST.text
FROM	sys.dm_exec_connections AS C INNER JOIN sys.dm_exec_sessions AS S
		ON (C.most_recent_session_id = S.session_id)
		CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) AS DEST
WHERE	S.is_user_process = 1 AND
		-- status = N'running' AND
		S.program_name LIKE N'Microsoft Office%';
GO

-- now open the table dbo.CustomerOrderDetails (3.000.000 records)
-- and check the waiting stats
SELECT	*
FROM	sys.dm_os_waiting_tasks
WHERE	session_id IN 
		(
			SELECT	session_id
			FROM	sys.dm_exec_sessions
			WHERE	is_user_process = 1 AND
					status = N'running' AND
					program_name LIKE N'Microsoft Office%'
		);
GO

-- start the xe session to monitor the waits for the spid
-- of the access application
DECLARE	@ReturnValue INT;
EXEC	@ReturnValue = master..sp_CreateXESession 57;
GO

-- what resources are blocked by the application?
SELECT *
FROM	sys.dm_tran_locks AS DTL
WHERE	DTL.request_session_id = 53;
GO

-- what Id are on the "LOCKED" page?
DBCC TRACEON (3604);
DBCC PAGE (CustomerOrders, 1,24532, 3);
GO

-- now try to update the very first record on the page!
UPDATE	dbo.CustomerOrderDetails
SET		Unit = 'Stk'
WHERE	Order_Id = 607465;
GO

SELECT * FROM sys.dm_os_wait_stats AS DOWS
WHERE	DOWS.wait_type LIKE '%NETWORK%';
GO

-- when all data have been loaded the XE session can be closed
-- Stop the wait stats analysis session
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO
