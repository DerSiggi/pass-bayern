/*============================================================================
	File:		0010 - restore demo database with existing relations.sql

	Summary:	This script restores from an existing backup of a "large"
				database with customers and orders

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Enable Zeroing out for the creation of files (Zeroing out!)
DBCC TRACEOFF (1806, -1);
GO

IF DB_ID('CustomerOrders') IS NOT NULL
BEGIN
	ALTER DATABASE [CustomerOrders] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [CustomerOrders];
END
GO

-- What database files are in the backup file?
RESTORE FILELISTONLY FROM DISK = 'S:\Backup\CustomerOrders.bak';
GO

-- restore the database CustomerOrders from existing backup
-- Note that the database will be restored on a SLOW disk!
RESTORE DATABASE [CustomerOrders]
FROM DISK = N'S:\Backup\CustomerOrders.bak'
WITH
	MOVE N'CustomerOrders_Data' TO N'S:\MSSQL12.SQL_2014\MSSQL\DATA\CustomerOrders.mdf',
	MOVE N'CustomerOrders_Log' TO N'S:\MSSQL12.SQL_2014\MSSQL\DATA\CustomerOrders.ldf',
	REPLACE,
	STATS = 10;
GO

-- Now set the database to recovery model simple and set the owner to sa
ALTER DATABASE [CustomerOrders] SET RECOVERY SIMPLE;
ALTER AUTHORIZATION ON DATABASE::[CustomerOrders] TO sa;
GO

