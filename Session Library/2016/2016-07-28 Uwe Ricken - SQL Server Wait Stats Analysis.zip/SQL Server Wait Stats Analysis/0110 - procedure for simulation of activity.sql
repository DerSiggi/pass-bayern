/*============================================================================
	File:		0110 - procedure for simulation of activity.sql

	Summary:	This script uses the CustomerOrders-database to generate workloads
				by using three different access patterns based on a random id!

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	modified by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/

USE CustomerOrders;
GO

IF OBJECT_ID('dbo.proc_Simulate_Activity', 'P') IS NOT NULL
	DROP PROC dbo.proc_Simulate_Activity;
	GO

CREATE PROC dbo.proc_Simulate_Activity
AS
	SET NOCOUNT ON;

	DECLARE	@Customer_Id	INT

	WHILE (1 = 1)
	BEGIN
		SET		@Customer_Id	=	CAST(RAND() * 75000 AS INT);

		IF @Customer_Id % 3 = 0
			SELECT * FROM dbo.Customers WHERE Id <= @Customer_Id;

		IF @Customer_Id % 3 = 1
			SELECT	C.Name,
					CO.*
			FROM	dbo.Customers AS C INNER JOIN dbo.CustomerOrders AS CO
					ON (C.Id = CO.Customer_Id)
			WHERE	CO.OrderDate = '20150101';

		IF @Customer_Id % 3 = 2
			SELECT	C.Name,
					YEAR(CO.OrderDate)				AS	OrderYear,
					COUNT_BIG(DISTINCT CO.Id)		AS	Orders,
					SUM(COD.Quantity * COD.Price)	AS	OrderAmount
			FROM	dbo.Customers AS C INNER JOIN dbo.CustomerOrders AS CO
					ON (C.Id = CO.Customer_Id) INNER JOIN dbo.CustomerOrderDetails AS COD
					ON (CO.Id = COD.Order_Id)
			WHERE	C.Id = @Customer_Id
			GROUP BY
					C.Name,
					YEAR(CO.OrderDate);

		WAITFOR DELAY '00:00:01';
	END

	SET NOCOUNT OFF;
GO
