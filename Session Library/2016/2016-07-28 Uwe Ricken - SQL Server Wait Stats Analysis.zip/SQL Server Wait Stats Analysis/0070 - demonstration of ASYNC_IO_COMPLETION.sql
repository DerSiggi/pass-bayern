/*============================================================================
	File:		0070 - demonstration of ASYNC_IO_COMPLETION.sql

	Summary:	This script monitors / forces the 
				ASYNC_NETWORK_IO wait stat

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- First of all a new database will be created on the
-- VERY slow disk
IF DB_ID('ASYNC_IO_DB') IS NOT NULL
BEGIN
	ALTER DATABASE ASYNC_IO_DB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE ASYNC_IO_DB;
END
GO

-- Deaktivate Instant File Initialization
DBCC TRACEON (1806, -1)
GO

EXEC	master..sp_CreateXESession @SPID = @@SPID;
GO

CREATE DATABASE ASYNC_IO_DB
ON PRIMARY
(
	NAME		= N'ASYNC_IO_DB',
	FILENAME	= N'S:\MSSQL11.SQL_2012\MSSQL\DATA\ASYNC_IO_DB.mdf',
	-- FILENAME	= N'F:\SQLData\ASYNC_IO_DB.mdf',
	SIZE		= 1000MB,
	FILEGROWTH	= 1MB
)
LOG ON
(
	NAME		= N'ASYNC_IO_LOG',
	FILENAME	= N'S:\MSSQL11.SQL_2012\MSSQL\DATA\ASYNC_IO_DB.ldf',
	-- N'F:\SQLData\ASYNC_IO_DB.ldf',
	SIZE		= 1000MB,
	FILEGROWTH	= 1MB
);
GO

-- Now we stop the XE session and watch the wait stats
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO

-- Wrong sizing will cause heavy wait stats, too!
USE master;
GO

IF DB_ID('ASYNC_IO_DB') IS NOT NULL
BEGIN
	ALTER DATABASE ASYNC_IO_DB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE ASYNC_IO_DB;
END
GO

---- Deaktivate Instant File Initialization
--DBCC TRACEON (1806, -1)
--GO
CREATE DATABASE ASYNC_IO_DB
ON PRIMARY
(
	NAME		= N'ASYNC_IO_DB',
	FILENAME	= N'S:\MSSQL11.SQL_2012\MSSQL\DATA\ASYNC_IO_DB.mdf',
	-- FILENAME	= N'F:\SQLData\ASYNC_IO_DB.mdf',
	SIZE		= 3MB,
	FILEGROWTH	= 1MB
)
LOG ON
(
	NAME		= N'ASYNC_IO_LOG',
	FILENAME	= N'S:\MSSQL11.SQL_2012\MSSQL\DATA\ASYNC_IO_DB.ldf',
	-- N'F:\SQLData\ASYNC_IO_DB.ldf',
	SIZE		= 5MB,
	FILEGROWTH	= 1MB
);
GO

USE ASYNC_IO_DB;
GO

CREATE TABLE dbo.Customer
(
	Id	INT			NOT NULL	IDENTITY (1, 1) PRIMARY KEY CLUSTERED,
	C1	CHAR(8000)	NOT NULL	DEFAULT ('only a filler')
);
GO

SET NOCOUNT ON;
GO

-- now the XE session will be created
EXEC	master..sp_CreateXESession @SPID = @@SPID;
GO

-- Now we insert 1.280 records into the table (100 MB)
INSERT INTO dbo.Customer DEFAULT VALUES;
GO 12800

-- Now we stop the XE session and watch the wait stats
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO

USE master;
GO

-- Clean the kitchen!
IF DB_ID('ASYNC_IO_DB') IS NOT NULL
BEGIN
	ALTER DATABASE ASYNC_IO_DB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE ASYNC_IO_DB;
END
GO
