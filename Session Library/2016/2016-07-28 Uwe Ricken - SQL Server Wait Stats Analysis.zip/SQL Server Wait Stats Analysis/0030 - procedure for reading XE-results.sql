/*============================================================================
	File:		0030 - procedure for reading XE-results.sql

	Summary:	This script is based on the article "Capturing wait stats for a single operation"
				from Paul Randal (SQLSkills) and can be found in original here:
				http://www.sqlskills.com/blogs/paul/capturing-wait-stats-for-a-single-operation/

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	modified by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Create intermediate temp table for raw event data
IF OBJECT_ID('dbo.sp_AnalyzeWaits', 'P') IS NOT NULL
	DROP PROC dbo.sp_AnalyzeWaits;
	GO

CREATE PROC dbo.sp_AnalyzeWaits
AS
	SET NOCOUNT ON;

	CREATE TABLE #RawEventData
	(
		Rowid		INT IDENTITY PRIMARY KEY,
		event_data	XML
	);

	-- Read the file data into intermediate temp table
	INSERT INTO #RawEventData (event_data)
	SELECT	CAST (event_data AS XML)
	FROM	sys.fn_xe_file_target_read_file
			(
				'F:\WaitStatAnalysis\WaitStats*.xel',
				'F:\WaitStatAnalysis\WaitStats.xem',
				NULL,
				NULL
			);

	SELECT	waits.[Wait Type],
			COUNT_BIG(*)											AS [Wait Count],
			SUM (waits.[Duration])									AS [Total Wait Time (ms)],
			SUM (waits.[Duration]) - SUM (waits.[Signal Duration])	AS [Total Resource Wait Time (ms)],
			SUM (waits.[Signal Duration])							AS [Total Signal Wait Time (ms)]
	FROM
	(
		SELECT	event_data.value ('(/event/@timestamp)[1]', 'DATETIME') AS [Time],
				event_data.value ('(/event/data[@name=''wait_type'']/text)[1]', 'VARCHAR(100)') AS [Wait Type],
				event_data.value ('(/event/data[@name=''opcode'']/text)[1]', 'VARCHAR(100)') AS [Op],
				event_data.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT') AS [Duration],
				event_data.value ('(/event/data[@name=''signal_duration'']/value)[1]', 'BIGINT') AS [Signal Duration]
		FROM #RawEventData
	) AS waits
	WHERE waits.[op] = 'End'
	GROUP BY waits.[Wait Type]
	ORDER BY [Total Wait Time (ms)] DESC;

	SET NOCOUNT OFF;
GO

EXEC sp_MS_marksystemobject @objname = 'dbo.sp_AnalyzeWaits', @namespace = NULL;
GO