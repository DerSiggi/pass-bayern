/*============================================================================
	File:		0020 - procedure for captering waits for dedicated SPID.sql

	Summary:	This script is based on the article "Capturing wait stats for a single operation"
				from Paul Randal (SQLSkills) and can be found in original here:
				http://www.sqlskills.com/blogs/paul/capturing-wait-stats-for-a-single-operation/

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	modified by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

IF OBJECT_ID('dbo.sp_CreateXESession', 'P') IS NOT NULL
	DROP PROCEDURE dbo.sp_CreateXESession;
	GO

CREATE PROCEDURE dbo.sp_CreateXESession
	@SPID INT
AS
	SET NOCOUNT ON;
	DECLARE	@stmt	NVARCHAR(4000);

	RAISERROR ('Deleting existing XE session from server!', 0, 1) WITH NOWAIT;
	IF EXISTS (SELECT * FROM sys.server_event_sessions AS SES WHERE [name] = N'WaitStatBySession')
		DROP EVENT SESSION WaitStatBySession ON SERVER

	-- make sure that the path exists for saving the files
	RAISERROR ('Creating a new XE session on server!', 0, 1) WITH NOWAIT;
	SET	@stmt =	N'
	CREATE EVENT SESSION WaitStatBySession ON SERVER
	ADD EVENT sqlos.wait_info
	(
		WHERE
			sqlserver.session_id = ' + CAST(@SPID AS NVARCHAR(10)) + N'
	)
	ADD TARGET package0.asynchronous_file_target
	(
		SET FILENAME	= N''F:\WaitStatAnalysis\WaitStats.xel'', 
		METADATAFILE	= N''F:\WaitStatAnalysis\WaitStats.xem''
	)
	WITH (max_dispatch_latency = 1 seconds);';

	EXEC sp_executesql @stmt;

	IF EXISTS (SELECT * FROM sys.server_event_sessions AS SES WHERE [name] = N'WaitStatBySession')
	BEGIN
		RAISERROR ('XE session has been created and is up and running!', 0, 1) WITH NOWAIT;
		ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = START;
		RETURN 0;
	END
	ELSE
	BEGIN
		RAISERROR ('XE session has not been created due to a failure', 0, 1) WITH NOWAIT;
		RETURN 1;
	END

	SET NOCOUNT OFF;
GO

EXEC sp_MS_marksystemobject @objname = 'dbo.sp_CreateXESession', @namespace = NULL;
GO