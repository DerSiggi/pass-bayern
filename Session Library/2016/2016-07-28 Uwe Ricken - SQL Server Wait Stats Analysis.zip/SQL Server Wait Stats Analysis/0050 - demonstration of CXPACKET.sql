/*============================================================================
	File:		0050 - demonstration of CXPACKET.sql

	Summary:	This script monitors / forces the 
				ASYNC_NETWORK_IO wait stat

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- reconfigure the threshold for parallelism to default value!
EXEC sys.sp_configure N'cost threshold for parallelism', N'5'
RECONFIGURE WITH OVERRIDE
GO

-- Flush any data from the buffer pool to disk!
DBCC DROPCLEANBUFFERS;
GO

-- Start the wait stats analysis session (WATCH YOUR SPID!)
EXEC master..sp_CreateXESession @SPID = @@SPID;
GO

SELECT	C.Name,
		YEAR(CO.OrderDate)	AS	YearOfOrder,
		COUNT_BIG(*)		AS	NumOfOrders
FROM	CustomerOrders.dbo.Customers AS C INNER JOIN CustomerOrders.dbo.CustomerOrders AS CO
		ON (C.Id = CO.Customer_Id)
WHERE	C.Id <= 10
GROUP BY
		C.Name,
		YEAR(OrderDate)
ORDER BY
		C.Name
OPTION (RECOMPILE, QUERYTRACEON 9130);
GO

-- ERST AB SQL SERVER 2016
SELECT * FROM sys.dm_exec_session_wait_stats AS DESWS
WHERE	session_id = @@SPID;
GO


-- Stop the wait stats analysis session
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO

-- How to resolve CXPACKET waits with indexing...
-- Create a clustered index on dbo.Customers
CREATE UNIQUE CLUSTERED INDEX cuix_Customers_Id
ON dbo.Customers (ID);
GO

CREATE UNIQUE CLUSTERED INDEX cuix_CustomerOrders_Id
ON dbo.CustomerOrders (Id);
GO

CREATE INDEX ix_CustomerOrders_Customer_Id
ON dbo.CustomerOrders (Customer_Id)
INCLUDE (OrderDate);
GO

-- Flush any data from the buffer pool to disk!
DBCC DROPCLEANBUFFERS;
GO

EXEC master..sp_CreateXESession @SPID = @@SPID;
GO

SELECT	C.Name,
		YEAR(OrderDate)	AS	YearOfOrder,
		COUNT_BIG(*)	AS	NumOfOrders
FROM	dbo.Customers AS C INNER JOIN dbo.CustomerOrders AS CO
		ON (C.Id = CO.Customer_Id)
WHERE	C.Id <= 10
GROUP BY
		C.Name,
		YEAR(OrderDate)
ORDER BY
		C.Name
OPTION	(RECOMPILE);
GO

-- Stop the wait stats analysis session
ALTER EVENT SESSION WaitStatBySession ON SERVER STATE = STOP;
GO

EXEC master..sp_AnalyzeWaits;
GO