/*============================================================================
	File:		0080 - demonstration of THREADPOOL.sql

	Summary:	This script creates demo database and inside a simple table.
				In one dedicated thread an X-Lock will be set on the table
				while 1000 other threads try to access this table.

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Wait Stats Analysis"

	Date:		March 2014

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Paul Randal, SQL Skills

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- How much worker threads do we have in the machine?
SELECT	DOSI.cpu_count,
		DOSI.max_workers_count
FROM sys.dm_os_sys_info AS DOSI;
GO

-- Now a new database demo_db will be created with a simple table
IF DB_ID('demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

CREATE DATABASE demo_db
ON PRIMARY
(
	NAME		= 'demo_db',
	FILENAME	= 'F:\Data\demo_db.mdf',
	SIZE		= 100MB,
	MAXSIZE		= 100MB
)
LOG ON
(
	NAME		= N'demo_log',
	FILENAME	= N'F:\Data\demo.ldf',
	SIZE		= 10MB,
	MAXSIZE		= 100MB
);
GO

-- Now we create a table in the new database
USE demo_db;
GO

CREATE TABLE dbo.demo
(
	Id INT			NOT NULL	IDENTITY (1, 1) PRIMARY KEY CLUSTERED,
	C1	CHAR(20)	NOT NULL	DEFAULT ('just stuff')
);
GO

SET NOCOUNT ON;
GO

INSERT INTO dbo.demo DEFAULT VALUES;
GO 100

SELECT * FROM dbo.demo;
GO

-- Now a single transaction blocks the table for any access
BEGIN TRANSACTION;
GO
	UPDATE	dbo.demo
	SET		C1 = 'Uwe Ricken'
	WHERE	Id = 10;

ROLLBACK TRANSACTION;

-- what resources are locked?
SELECT * FROM sys.dm_tran_locks AS DTL
WHERE DTL.resource_database_id = DB_ID();
-- COMMIT TRANSACTION;

/*
	Now start 600 simultanious connections with a SELECT on the locked resource
	ostress -E -SNB-LENOVO-I\SQL_2014 -Q"SELECT * FROM dbo.demo WHERE Id = 10;" -n600 -ddemo_db
*/
SELECT	DER.session_id,
		DER.start_time,
		DER.status
FROM	sys.dm_exec_sessions AS DES INNER JOIN sys.dm_exec_requests AS DER
		ON (DES.session_id = DER.session_id)
WHERE	DES.is_user_process = 1 AND
		DES.session_id != @@SPID;
GO

SELECT	DOWT.wait_type,
		DOWT.blocking_session_id,
		COUNT_BIG(*)		AS	wait_type_no
FROM	sys.dm_os_waiting_tasks DOWT
WHERE	session_id > 50 AND
		session_id != @@SPID
GROUP BY
		DOWT.wait_type,
		DOWT.blocking_session_id;
GO

SELECT * FROM sys.dm_os_waiting_tasks
WHERE	wait_type = 'THREADPOOL';
GO
