SELECT cp.cacheobjtype
     , cp.objtype
     , cp.usecounts
     , st.text
     , qp.query_plan
     
     , creation_time                            = qs.creation_time                           
     , last_execution_time                      = qs.last_execution_time                     
     , execution_count                          = qs.execution_count                         
     
     , total_elapsed_time                       = qs.total_elapsed_time                      
     , last_elapsed_time                        = qs.last_elapsed_time                       
     , min_elapsed_time                         = qs.min_elapsed_time                        
     , max_elapsed_time                         = qs.max_elapsed_time                        

     , total_rows                               = qs.total_rows                              
     , last_rows                                = qs.last_rows                               
     , min_rows                                 = qs.min_rows                                
     , max_rows                                 = qs.max_rows              
                       
     , total_worker_time                        = qs.total_worker_time                       
     , last_worker_time                         = qs.last_worker_time                        
     , min_worker_time                          = qs.min_worker_time                         
     , max_worker_time                          = qs.max_worker_time                         

     , total_logical_reads                      = qs.total_logical_reads                     
     , last_logical_reads                       = qs.last_logical_reads                      
     , min_logical_reads                        = qs.min_logical_reads                       
     , max_logical_reads                        = qs.max_logical_reads                       

     , total_logical_writes                     = qs.total_logical_writes                    
     , last_logical_writes                      = qs.last_logical_writes                     
     , min_logical_writes                       = qs.min_logical_writes                      
     , max_logical_writes                       = qs.max_logical_writes                      

     , total_physical_reads                     = qs.total_physical_reads                    
     , last_physical_reads                      = qs.last_physical_reads                     
     , min_physical_reads                       = qs.min_physical_reads                      
     , max_physical_reads                       = qs.max_physical_reads                      

     , total_clr_time                           = qs.total_clr_time                          
     , last_clr_time                            = qs.last_clr_time                           
     , min_clr_time                             = qs.min_clr_time                            
     , max_clr_time                             = qs.max_clr_time                            

     , sql_handle                               = qs.sql_handle                              
     , statement_start_offset                   = qs.statement_start_offset                  
     , statement_end_offset                     = qs.statement_end_offset                    
     , query_plan_hash                          = qs.query_plan_hash                         
     , statement_sql_handle                     = qs.statement_sql_handle                    
     , statement_context_id                     = qs.statement_context_id                    
     , plan_generation_num                      = qs.plan_generation_num                     
     , plan_handle                              = qs.plan_handle                             
     , query_hash                               = qs.query_hash                              
 
  FROM              sys.dm_exec_query_stats                  qs 
       INNER JOIN   sys.dm_exec_cached_plans                 cp ON cp.plan_handle = qs.plan_handle
       CROSS APPLY  sys.dm_exec_sql_text(   qs.sql_handle )  st
       CROSS APPLY  sys.dm_exec_query_plan( qs.plan_handle ) qp
 ORDER 
    BY cp.cacheobjtype, cp.objtype, cp.usecounts DESC        
       
 