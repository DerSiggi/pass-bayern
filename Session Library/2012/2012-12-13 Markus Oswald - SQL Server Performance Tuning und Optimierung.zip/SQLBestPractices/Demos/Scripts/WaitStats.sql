-- isolate top waits
WITH Waits AS
     (SELECT
         wait_type,
         wait_time_ms / 1000.0 AS wait_time_s,
         (wait_time_ms - signal_wait_time_ms) / 1000.0 AS resource_wait_time_s,
         signal_wait_time_ms / 1000.0 AS signal_wait_time_s,
         waiting_tasks_count AS wait_count,
         100.0 * wait_time_ms / SUM (wait_time_ms) OVER() AS wait_percentage,
         ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS row_num
     FROM sys.dm_os_wait_stats
     WHERE wait_type NOT IN (
         'CLR_SEMAPHORE',        'LAZYWRITER_SLEEP',
		 'RESOURCE_QUEUE',       'SLEEP_TASK',
         'SLEEP_SYSTEMTASK',     'SQLTRACE_BUFFER_FLUSH',
		 'WAITFOR',              'LOGMGR_QUEUE',
         'CHECKPOINT_QUEUE',     'REQUEST_FOR_DEADLOCK_SEARCH',
		 'XE_TIMER_EVENT',       'BROKER_TO_FLUSH',
         'BROKER_TASK_STOP',     'CLR_MANUAL_EVENT',
		 'CLR_AUTO_EVENT',       'DISPATCHER_QUEUE_SEMAPHORE',
         'XE_DISPATCHER_WAIT',   'FT_IFTS_SCHEDULER_IDLE_WAIT',
		 'XE_DISPATCHER_JOIN',   'BROKER_EVENTHANDLER',
         'TRACEWRITE',           'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
		 'FT_IFTSHC_MUTEX',      'BROKER_RECEIVE_WAITFOR',
		 'ONDEMAND_TASK_QUEUE',  'DBMIRROR_EVENTS_QUEUE',
         'DBMIRRORING_CMD',      'BROKER_TRANSMITTER',
		 'SLEEP_BPOOL_FLUSH',    'SQLTRACE_LOCK',
		 'SQLTRACE_WAIT_ENTRIES','HADR_FILESTREAM_IOMGR_IOCOMPLETION',
		 'DIRTY_PAGE_POLL',      'SP_SERVER_DIAGNOSTICS_SLEEP')
     )
 SELECT
     W1.wait_type AS wait_type, 
     CAST (W1.wait_time_s AS DECIMAL(14, 2)) AS wait_time_s,
     CAST (W1.resource_wait_time_s AS DECIMAL(14, 2)) AS resource_wait_time_s,
     CAST (W1.signal_wait_time_s AS DECIMAL(14, 2)) AS signal_wait_time_s,
     W1.wait_count AS wait_count,
     CAST (W1.wait_percentage AS DECIMAL(4, 2)) AS wait_percentage,
     CAST ((W1.wait_time_s / W1.wait_count) AS DECIMAL (14, 4)) AS avg_wait_time_s,
     CAST ((W1.resource_wait_time_s / W1.wait_count) AS DECIMAL (14, 4)) AS avg_resource_wait_time_s,
     CAST ((W1.signal_wait_time_s / W1.wait_count) AS DECIMAL (14, 4)) AS avg_signal_wait_time_s
 FROM Waits AS W1
     INNER JOIN Waits AS W2 ON W2.row_num <= W1.row_num
 GROUP BY W1.row_num, W1.wait_type, W1.wait_time_s, W1.resource_wait_time_s, W1.signal_wait_time_s, W1.wait_count, W1.wait_percentage
 HAVING SUM (W2.wait_percentage) - W1.wait_percentage < 95; -- percentage threshold
 