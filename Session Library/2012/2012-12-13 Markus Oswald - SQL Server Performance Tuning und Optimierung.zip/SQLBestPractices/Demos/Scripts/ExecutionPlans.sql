-- plan cache interrogation
-- note: sys.dm_exec_cached_plans is diminutive version of syscacheobjects
   -- no dbid, setopts
-- we want reusable code, absence of ad hoc SQL and relatively few rows with low usecounts
SELECT
	cp.objtype,
	cp.usecounts,
	cp.refcounts,
	cp.size_in_bytes,
	st.dbid,
	st.objectid, 
	st.text AS query_text,
	qp.query_plan 
FROM sys.dm_exec_cached_plans AS cp
    CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
	CROSS APPLY sys.dm_exec_query_plan (cp.plan_handle) qp
WHERE cp.cacheobjtype = 'Compiled Plan'
ORDER BY cp.usecounts DESC;

-- query plans that may run in parallel
SELECT
	p.dbid,
	p.objectid,
	p.query_plan,
	q.text,
	cp.plan_handle,
	cp.usecounts
FROM sys.dm_exec_cached_plans cp
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) p
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS q
WHERE cp.cacheobjtype = 'Compiled Plan'
AND p.query_plan.value('declare namespace p="http://schemas.microsoft.com/sqlserver/2004/07/showplan"; max(//p:RelOp/@Parallel)', 'float') > 0;

-- determining the estimated cost of parallel execution plans
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

WITH XMLNAMESPACES
(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
SELECT
	query_plan AS CompleteQueryPlan ,
    n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS StatementText,
    n.value('(@StatementOptmLevel)[1]', 'VARCHAR(25)') AS StatementOptimizationLevel,
    n.value('(@StatementSubTreeCost)[1]', 'VARCHAR(128)') AS StatementSubTreeCost,
    n.query('.') AS ParallelSubTreeXML,
    ecp.usecounts,
    ecp.size_in_bytes
FROM sys.dm_exec_cached_plans AS ecp
     CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS eqp
     CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple')
     AS qn ( n )
WHERE n.query('.').exist('//RelOp[@PhysicalOp="Parallelism"]') = 1;

-- find high compile resource plans in the plan cache
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
WITH XMLNAMESPACES 
(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
SELECT TOP 10
	compile_time_ms,
	compile_cpu_ms,
	compile_memory_kb,
	qs.execution_count,
	qs.total_elapsed_time/1000 AS duration_ms,
	qs.total_worker_time/1000 AS cpu_time_ms,
	(qs.total_elapsed_time/qs.execution_count)/1000 AS avg_duration_ms,
	(qs.total_worker_time/qs.execution_count)/1000 AS avg_cpu_time_ms,
	qs.max_elapsed_time/1000 AS max_duration_ms,
	qs.max_worker_time/1000 AS max_cpu_time_ms,
	SUBSTRING(st.text, (qs.statement_start_offset / 2) + 1,
	(CASE qs.statement_end_offset
	WHEN -1 THEN DATALENGTH(st.text)
	ELSE qs.statement_end_offset
	END - qs.statement_start_offset) / 2 + 1) AS statement_text,
	qs.query_hash,
	qs.query_plan_hash
FROM
(
	SELECT 
		c.value('xs:hexBinary(substring((@QueryHash)[1],3))', 'varbinary(max)') AS query_hash,
		c.value('xs:hexBinary(substring((@QueryPlanHash)[1],3))', 'varbinary(max)') AS query_plan_hash,
		c.value('(QueryPlan/@CompileTime)[1]', 'int') AS compile_time_ms,
		c.value('(QueryPlan/@CompileCPU)[1]', 'int') AS compile_cpu_ms,
		c.value('(QueryPlan/@CompileMemory)[1]', 'int') AS compile_memory_kb,
		qp.query_plan
	FROM sys.dm_exec_cached_plans AS cp
	CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
	CROSS APPLY qp.query_plan.nodes('ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS n(c)
) AS tab
JOIN sys.dm_exec_query_stats AS qs
ON tab.query_hash = qs.query_hash
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
ORDER BY compile_time_ms DESC
OPTION(RECOMPILE, MAXDOP 1);
