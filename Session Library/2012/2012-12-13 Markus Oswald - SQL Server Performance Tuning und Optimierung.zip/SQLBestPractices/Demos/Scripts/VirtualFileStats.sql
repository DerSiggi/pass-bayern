-- I/O statistics by file for all databases
SELECT
	DB_NAME(vfs.database_id) AS database_name,
	vfs.database_id,
	vfs.file_id,
	vfs.io_stall_read_ms / NULLIF(vfs.num_of_reads, 0) AS avg_read_latency_ms,
	vfs.io_stall_write_ms / NULLIF(vfs.num_of_writes, 0) AS avg_write_latency_ms,
	io_stall / NULLIF(vfs.num_of_reads + vfs.num_of_writes, 0) AS avg_total_latency_ms,
	vfs.num_of_bytes_read / NULLIF(vfs.num_of_reads, 0) AS avg_bytes_per_read,
	vfs.num_of_bytes_written / NULLIF(vfs.num_of_writes, 0) AS avg_bytes_per_write,
	vfs.io_stall AS io_stall_ms,
	vfs.num_of_reads,
	vfs.num_of_bytes_read,
	vfs.io_stall_read_ms,
	vfs.num_of_writes,
	vfs.num_of_bytes_written,
	vfs.io_stall_write_ms,
	CAST(vfs.size_on_disk_bytes / (1024 * 1024) AS NUMERIC(12, 2)) AS size_on_disk_mb,
	mf.physical_name
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
JOIN sys.master_files AS mf ON vfs.database_id = mf.database_id
AND vfs.file_id = mf.file_id
ORDER BY avg_total_latency_ms DESC;