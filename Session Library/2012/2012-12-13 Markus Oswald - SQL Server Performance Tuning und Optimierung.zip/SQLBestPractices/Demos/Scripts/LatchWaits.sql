-- most common latch waits that have occurred on your system
WITH Latches AS
     (SELECT
         latch_class,
         wait_time_ms / 1000.0 AS wait_time_s,
         waiting_requests_count AS wait_count,
         100.0 * wait_time_ms / SUM (wait_time_ms) OVER() AS wait_percentage,
         ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS row_num
     FROM sys.dm_os_latch_stats
     WHERE latch_class NOT IN (
         'BUFFER')
     AND wait_time_ms > 0
     )
 SELECT
     W1.latch_class AS latch_class, 
     CAST (W1.wait_time_s AS DECIMAL(14, 2)) AS wait_time_s,
     W1.wait_count AS wait_count,
     CAST (W1.wait_percentage AS DECIMAL(14, 2)) AS wait_time_percent,
     CAST ((W1.wait_time_s / W1.wait_count) AS DECIMAL (14, 4)) AS avg_wait_time_s
 FROM Latches AS W1
 INNER JOIN Latches AS W2
     ON W2.row_num <= W1.row_num
 WHERE W1.wait_count > 0
 GROUP BY W1.row_num, W1.latch_class, W1.wait_time_s, W1.wait_count, W1.wait_percentage
 HAVING SUM (W2.wait_percentage) - W1.wait_percentage < 95; -- percentage threshold
