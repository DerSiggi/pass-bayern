USE <database_name>;
GO

-- table size
SELECT
	OBJECT_NAME(p.object_id) AS table_name,
    SUM(au.total_pages) AS page_count,
	SUM(au.total_pages) * 8 AS table_size_kb 
FROM sys.partitions p 
INNER JOIN sys.allocation_units au ON p.hobt_id = au.container_id 
GROUP BY p.object_id 
ORDER BY table_size_kb DESC;

-- index size
SELECT
	OBJECT_NAME(i.object_id) AS table_name,
	i.name AS index_name,
	i.index_id AS index_id,
	SUM(au.used_pages) AS page_count,
	SUM(au.used_pages) * 8 AS index_size_kb
FROM sys.indexes i
INNER JOIN sys.partitions p ON p.object_id = i.object_id AND p.index_id = i.index_id
INNER JOIN sys.allocation_units au ON au.container_id = p.partition_id
GROUP BY i.object_id, i.index_id, i.name
ORDER BY OBJECT_NAME(i.object_id), i.index_id;

-- tables with missing clustered index
SELECT DISTINCT
	table_name = OBJECT_NAME(object_id)
FROM sys.indexes
WHERE index_id = 0 AND OBJECTPROPERTY(object_id,'IsUserTable') = 1
ORDER BY table_name;

-- list clustered indexes with datatypes
SELECT
	st.name AS table_name,
	si.index_id, si.name AS index_name,
	SUBSTRING((SELECT  ', ' + ac.name + '(' + tp.name + ')'
	FROM sys.tables t
	INNER JOIN sys.indexes i ON t.object_id = i.object_id
	INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id
		AND i.index_id = ic.index_id
	INNER JOIN sys.all_columns ac ON t.object_id = ac.object_id
		AND ic.column_id = ac.column_id
	INNER JOIN sys.types tp ON ac.system_type_id = tp.system_type_id
	WHERE si.object_id = i.object_id
		AND si.index_id = i.index_id
	ORDER BY ic.key_ordinal
FOR XML PATH('')), 2, 8000) AS columns
FROM sys.indexes si
INNER JOIN sys.tables st ON st.object_id = si.object_id
WHERE si.index_id =1
ORDER BY table_name;

-- identifying single-column, non-indexed FOREIGN KEYs
SELECT
	fk.name AS constraint_name,
    s.name AS 'schema_name',
    o.name AS table_name,
    fkc_c.name AS constraint_column_name
FROM sys.foreign_keys AS fk
    JOIN sys.foreign_key_columns AS fkc ON fk.object_id = fkc.constraint_object_id
    JOIN sys.columns AS fkc_c ON fkc.parent_object_id = fkc_c.object_id
		AND fkc.parent_column_id = fkc_c.column_id
    LEFT JOIN sys.index_columns ic
    JOIN sys.columns AS c ON ic.object_id = c.object_id
        AND ic.column_id = c.column_id ON fkc.parent_object_id = ic.object_id
        AND fkc.parent_column_id = ic.column_id
    JOIN sys.objects AS o ON o.object_id = fk.parent_object_id
    JOIN sys.schemas AS s ON o.schema_id = s.schema_id
WHERE c.name IS NULL;

-- identify unused indexes
/*
since SQL Server keeps data of all used indexes,
getting the unused indexes is a simple matter of comparing used indexes to all existing indexes.
those that exist but are not used are of course unused indexes.
*/
SELECT
	OBJECT_SCHEMA_NAME(i.object_id) AS 'schema_name',
    OBJECT_NAME(i.object_id) AS 'object_name',
    i.name AS index_name        
FROM sys.indexes i
WHERE   -- only get indexes for user created tables
	OBJECTPROPERTY(i.object_id, 'IsUserTable') = 1 
    -- find all indexes that exists but are NOT used
    AND NOT EXISTS ( 
		SELECT index_id
			FROM sys.dm_db_index_usage_stats
            WHERE object_id = i.object_id 
				AND i.index_id = index_id 
                -- limit our query only for the current db
                AND database_id = DB_ID()) 
ORDER BY [schema_name], [object_name], [index_name];

-- index usage statistics
SELECT
	OBJECT_NAME(s.object_id) AS 'object_name',
	s.object_id,
	i.name AS 'index_name',
	i.index_id,
	user_seeks,
	user_scans,
	user_lookups,
	user_updates,
	last_user_seek,
	last_user_scan,
	last_user_lookup,
	last_user_update
FROM sys.dm_db_index_usage_stats s INNER JOIN sys.indexes i 
ON i.object_id = s.object_id
	AND i.index_id = s.index_id
WHERE database_id = DB_ID() AND OBJECTPROPERTY(s.object_id,'IsUserTable') = 1
ORDER BY (user_seeks + user_scans + user_lookups) ASC;

-- examine fragmentation for all tables and indexes in a database
DECLARE @dbid SMALLINT = DB_ID();

SELECT 
	ips.object_id AS 'object_id',
	OBJECT_NAME(ips.object_id, @dbid) AS 'object_name',
	ips.partition_number,
	ips.index_id,
	si.name AS 'index_name',
	ips.index_type_desc,
	ips.alloc_unit_type_desc,
	ips.index_depth,
	-- ips.index_level,
	ROUND(ips.avg_fragmentation_in_percent, 2) AS 'fragmentation_in_percent',
	ips.fragment_count,
	ips.avg_fragment_size_in_pages,
	ips.page_count,
	ROUND(ips.avg_page_space_used_in_percent, 2) AS 'page_density',
	ips.record_count,
	ips.ghost_record_count
FROM sys.dm_db_index_physical_stats(@dbid, NULL, NULL, NULL , 'DETAILED') ips
CROSS APPLY sys.indexes si
WHERE si.object_id = ips.object_id
	AND si.index_id = ips.index_id
	AND ips.index_level = 0;
GO

-- missing index details
-- look for improvement_measures > 50 (sqlskills) and avg_user_impact > 80 (microsoft)
SELECT
  CONVERT (DECIMAL (28,1), 
	migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans)
  ) AS improvement_measure, 
  mid.statement AS table_name,
  mid.equality_columns,
  mid.inequality_columns,
  mid.included_columns,
  migs.avg_user_impact,
  migs.unique_compiles,
  migs.user_seeks,
  migs.user_scans,
  migs.last_user_seek,
  migs.last_user_scan,
  'CREATE INDEX [missing_index_'
	  + CONVERT (VARCHAR, mig.index_group_handle) + '_'
	  + CONVERT (VARCHAR, mid.index_handle) + '_'
	  + LEFT(PARSENAME(mid.statement, 1), 32) + ']' + ' ON '
	  + mid.statement
	  + ' (' + ISNULL(mid.equality_columns, '')
	  + CASE WHEN mid.equality_columns IS NOT NULL
	  AND mid.inequality_columns IS NOT NULL THEN ','
	  ELSE ''
	  END + ISNULL(mid.inequality_columns, '') + ')'
	  + ISNULL(' INCLUDE (' + mid.included_columns + ')', '')
  AS create_index_statement
FROM sys.dm_db_missing_index_groups mig
INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
--WHERE migs.avg_total_user_cost * ( migs.avg_user_impact / 100.0 )
--	* ( migs.user_seeks + migs.user_scans ) > 10
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC;