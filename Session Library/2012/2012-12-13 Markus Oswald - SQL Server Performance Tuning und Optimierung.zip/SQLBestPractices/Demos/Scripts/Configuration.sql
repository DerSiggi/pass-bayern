USE master;
GO

-- edition and product version
SELECT @@VERSION AS sql_server_and_os_version_info;

-- service accounts
SELECT
	servicename,
	startup_type_desc,
	status_desc,
	last_startup_time,
	service_account,
	filename
FROM sys.dm_server_services;

-- CPU and scheduler
SELECT 
	cpu_count,
	max_workers_count,
	hyperthread_ratio,
	scheduler_count,
	virtual_machine_type_desc, -- NONE | HYPERVISOR | OTHER
	CONVERT(VARCHAR,DATEADD(s,((-1)*(ms_ticks/1000)),GETDATE()), 100) AS server_startup_time
FROM sys.dm_os_sys_info;

-- memory configuration
SELECT
     physical_memory_kb / 1024 AS physical_memory_mb,
     physical_memory_in_use_kb / 1024 AS physical_memory_in_use_mb,
     available_physical_memory_kb / 1024 AS available_physical_memory_mb,
     locked_page_allocations_kb / 1024 AS locked_page_allocations_mb,
     virtual_memory_kb / 1024 AS virtual_memory_mb,
	 committed_kb / 1024 AS bufferpool_committed_mb,
	 committed_target_kb / 1024 AS bufferpool_target_mb,
	 visible_target_kb / 1024 AS bufferpool_visible_mb,
	 system_memory_state_desc,
	 max_server_memory_mb,
     min_server_memory_mb
 FROM sys.dm_os_sys_info
 CROSS JOIN sys.dm_os_process_memory
 CROSS JOIN sys.dm_os_sys_memory
 CROSS JOIN (
     SELECT value_in_use AS max_server_memory_mb
     FROM sys.configurations
     WHERE [name] = 'max server memory (MB)') AS c1
 CROSS JOIN (
     SELECT value_in_use AS min_server_memory_mb
     FROM sys.configurations
     WHERE [name] = 'min server memory (MB)') AS c2;

-- configuration values for the instance
/*
focus on:
backup compression default (should be 1)
clr enabled (only enable if it is needed)
lightweight pooling (should be 0)
max degree of parallelism (depends on your workload)
max server memory (MB) (set to an appropriate value)
optimize for ad hoc workloads (should be 1)
priority boost (should be 0)
*/
SELECT
	name,
	value,
	value_in_use,
	[description]
FROM sys.configurations
ORDER BY name ASC;

-- determine whether the instance is using "locked pages"
SELECT
	osn.node_id,
	osn.memory_node_id,
	osn.node_state_desc,
	omn.locked_page_allocations_kb
FROM sys.dm_os_memory_nodes omn
INNER JOIN sys.dm_os_nodes osn ON omn.memory_node_id = osn.memory_node_id
WHERE osn.node_state_desc <> 'ONLINE DAC';

-- memory allocated to the buffer pool
SELECT
    'SQLBUFFERPOOL' AS memory_clerk_type,
	SUM(pages_kb 
        + virtual_memory_committed_kb
        + shared_memory_committed_kb
        + awe_allocated_kb) / 1024 AS pages_mb
FROM sys.dm_os_memory_clerks 
WHERE type = 'MEMORYCLERK_SQLBUFFERPOOL'
UNION

-- memory allocated to sql excluding the buffer pool
SELECT
	'NON_SQLBUFFERPOOL' AS memory_clerk_type,
    SUM(pages_kb 
        + virtual_memory_committed_kb
        + shared_memory_committed_kb) / 1024 AS pages_mb
FROM sys.dm_os_memory_clerks 
WHERE type <> 'MEMORYCLERK_SQLBUFFERPOOL';

-- lazywriter activity
SELECT * FROM sys.dm_os_memory_cache_clock_hands
WHERE rounds_count > 0 AND removed_all_rounds_count > 0;

-- system memory usage
SELECT  
    event_time, 
    record.value('(/Record/ResourceMonitor/Notification)[1]', 'varchar(max)') AS event_type,
	record.value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'int') AS indicators_process, 
    record.value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'int') AS indicators_system, 
    record.value('(/Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint') AS available_physical_memory_kb, 
    record.value('(/Record/MemoryRecord/AvailableVirtualAddressSpace)[1]', 'bigint') AS available_virtual_address_space_kb 
FROM ( 
    SELECT 
        DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS event_time, 
        CONVERT (xml, record) AS record 
    FROM sys.dm_os_ring_buffers 
    CROSS JOIN sys.dm_os_sys_info 
    WHERE ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR') AS tab 
ORDER BY event_time DESC;

-- monitoring critical I/O paths
SELECT
	'WRITELOG' AS wait_type,
	wait_time_ms/waiting_tasks_count AS avg_wait_time_ms
FROM sys.dm_os_wait_stats
WHERE wait_type = 'WRITELOG'
UNION SELECT
	'PAGEIOLATCH' AS wait_type,
	SUM(wait_time_ms)/SUM(waiting_tasks_count) AS avg_wait_time_ms
FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGEIOLATCH%';

-- buffer pool usage per database
SELECT 
   (CASE WHEN (database_id = 32767)
        THEN 'Resource Database'
        ELSE DB_NAME (database_id) END) AS database_id,
    COUNT (*) * 8 / 1024 AS used_space_mb,
    SUM (CAST (free_space_in_bytes AS BIGINT)) / (1024 * 1024) AS free_space_mb
FROM sys.dm_os_buffer_descriptors
GROUP BY database_id;

-- track the database file growth
DECLARE @filename NVARCHAR(260);
SELECT @filename = SUBSTRING(path, 1, LEN(path) - CHARINDEX('\', REVERSE(path))) + '\log.trc'
FROM sys.traces WHERE is_default = 1;

SELECT
	databasename,
    e.name AS eventname,
    ct.name AS categoryname,
    starttime,
    e.category_id,
    loginname,
    spid,
    hostname,
    applicationname,
    servername,
    eventclass,
    eventsubclass
FROM ::fn_trace_gettable(@filename, DEFAULT)
       INNER JOIN sys.trace_events e
         ON eventclass = trace_event_id
       INNER JOIN sys.trace_categories AS ct
         ON e.category_id = ct.category_id
WHERE e.name IN ( 'Data File Auto Grow', 'Log File Auto Grow' )
ORDER BY starttime DESC;
