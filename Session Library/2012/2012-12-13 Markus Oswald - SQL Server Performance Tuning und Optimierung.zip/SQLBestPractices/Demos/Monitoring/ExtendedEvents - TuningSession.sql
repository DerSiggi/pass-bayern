-- EXECUTE master.dbo.sp_SQLskills_ConvertTraceToExtendedEvents @TraceID = <TraceID>, @SessionName = N'TuningSession', @PrintOutput = 1, @Execute = 0;

IF EXISTS (SELECT 1 FROM sys.server_event_sessions WHERE name = 'TuningSession')
	DROP EVENT SESSION TuningSession ON SERVER;
GO

CREATE EVENT SESSION TuningSession
ON SERVER
ADD EVENT sqlserver.rpc_completed(
	ACTION 
	(
			  sqlserver.client_app_name	-- ApplicationName from SQLTrace
			, sqlserver.database_id	-- DatabaseID from SQLTrace
			, sqlserver.database_name	-- DatabaseName from SQLTrace
			, sqlserver.nt_username	-- NTUserName from SQLTrace
			, sqlserver.nt_username	-- NTDomainName from SQLTrace
			, sqlserver.server_principal_name	-- LoginName from SQLTrace
			, sqlserver.session_id	-- SPID from SQLTrace
			-- BinaryData not implemented in XE for this event
	)
),
ADD EVENT sqlserver.sp_statement_completed(
	ACTION 
	(
			  sqlserver.client_app_name	-- ApplicationName from SQLTrace
			, sqlserver.database_id	-- DatabaseID from SQLTrace
			, sqlserver.database_name	-- DatabaseName from SQLTrace
			, sqlserver.nt_username	-- NTUserName from SQLTrace
			, sqlserver.nt_username	-- NTDomainName from SQLTrace
			, sqlserver.server_principal_name	-- LoginName from SQLTrace
			, sqlserver.session_id	-- SPID from SQLTrace
	)
),
ADD EVENT sqlserver.sql_batch_completed(
	ACTION 
	(
			  sqlserver.client_app_name	-- ApplicationName from SQLTrace
			, sqlserver.database_id	-- DatabaseID from SQLTrace
			, sqlserver.database_name	-- DatabaseName from SQLTrace
			, sqlserver.nt_username	-- NTUserName from SQLTrace
			, sqlserver.nt_username	-- NTDomainName from SQLTrace
			, sqlserver.server_principal_name	-- LoginName from SQLTrace
			, sqlserver.session_id	-- SPID from SQLTrace
	)
)
ADD TARGET package0.event_file
(
	SET FILENAME = 'C:\Temp\TuningSession.xel',
		MAX_FILE_SIZE = 5,
		MAX_ROLLOVER_FILES = 0
)

-- enable event
ALTER EVENT SESSION TuningSession ON SERVER STATE = START;
GO

-- run sample queries

-- read the data from the XML file
SELECT 
	event_data,
	event_data.value('(event/@name)[1]', 'nvarchar(128)') AS event_name,
	event_data.value('(event/action[@name="nt_username"])[1]', 'nvarchar(128)') AS nt_user_name,
	event_data.value('(event/action[@name="client_app_name"])[1]', 'nvarchar(128)') AS client_app_name,
	event_data.value('(event/action[@name="database_name"])[1]', 'nvarchar(128)') AS database_name,
	event_data.value('(event/@timestamp)[1]','datetime2') AS timestamp,
	CAST(event_data.value('(event/data[@name="duration"])[1]','int')/1000.0 AS decimal(12,2)) AS duration_ms,
	CAST(event_data.value('(event/data[@name="cpu_time"])[1]','int')/1000.0 AS decimal(12,2)) AS cpu_time_ms,
	event_data.value('(event/data[@name="physical_reads"])[1]','int') AS physical_reads,
	event_data.value('(event/data[@name="logical_reads"])[1]','int') AS logical_reads,
	event_data.value('(event/data[@name="writes"])[1]','int') AS writes,
	event_data.value('(event/data[@name="row_count"])[1]','int') AS row_count,
	event_data.value('(event/action[@name="session_id"])[1]','int') AS session_id,
	event_data.value('(event/data[@name="statement"])[1]', 'nvarchar(max)') AS statement,
	event_data.value('(event/data[@name="batch_text"])[1]', 'nvarchar(max)') AS batch_text
FROM
(
	SELECT CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file
	('C:\Temp\TuningSession*.xel', NULL, NULL, NULL)
) AS tab
-- CROSS APPLY event_data.nodes('event') AS q(n);
GO

-- stop the event
ALTER EVENT SESSION TuningSession ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION TuningSession ON SERVER;
GO

EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
 
EXEC sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

EXEC xp_cmdshell 'DEL C:\Temp\TuningSession*';
GO

EXEC sp_configure 'xp_cmdshell', 0;
RECONFIGURE;

EXEC sp_configure 'show advanced options', 0;
RECONFIGURE;