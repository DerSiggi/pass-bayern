

-- Find blocking resource
-- KEY: 12:72057594038845440 (8194443284a0)
-- RID: 10:1:160:4
use LockTest
go

-- Read trace file into table
if (object_id('LockTrace', 'U') is not null)
  drop table LockTrace
go  
select te.name as event_class
      ,cast(case when te.name = 'SQLTransaction'
         then sc.subclass_name + ' Transaction'
         else cast(tt.TextData as nvarchar(max))
       end as nvarchar(max)) as text_data
      ,tt.EventSequence as event_sequence
      ,tt.TransactionID as transaction_id
      ,tt.SPID as session_id
      ,tt.StartTime as start_time, tt.EndTime as end_time
      ,tt.Duration * 0.001 as duration_ms
      ,tt.Reads, tt.Writes
      ,tt.CPU * 0.001 as cpu_ms
  into LockTrace
  from fn_trace_gettable('C:\Users\Holger\Documents\Presentations\Blockings and Timeouts\LockTrace.trc', default) as tt
       inner join sys.trace_events as te
               on te.trace_event_id = tt.EventClass
       left outer join sys.trace_subclass_values as sc
               on sc.trace_event_id = tt.EventClass
              and sc.subclass_value = tt.EventSubClass
go

-- Find Blocked Process Reports
select cast(text_data as xml),* 
  from LockTrace
 where event_class like 'Blocked Process%'
go

select * from sys.databases where database_id =10
go
-- RID: 10:1:160:8
select %%lockres%%,*
  from t1
 where %%lockres%% = '1:160:8'
go

-- Also possible
dbcc traceon(3604)
dbcc page(10,1,160,3)
dbcc traceoff(3604)
go

--"KEY: 10:72057594038845440 (a6d5e8c8c0ce)"
-- Find index
select object_name(i.object_id) as table_name
      ,i.name as index_name
  from sys.partitions as  p
       inner join sys.indexes as i 
               on p.object_id = i.object_id
              and p.index_id  = i.index_id
              and p.hobt_id = 72057594038845440
go

select *,%%lockres%%
  from T1 with (index=PK__t1__3213663B7F60ED59)  
 where %%lockres%% = '(a6d5e8c8c0ce)'
go



-- Find timeouts
select * from LockTrace
 where text_data like 'Lock request time out%'
go

-- Start and end for timed-out transactions
select transaction_id
      ,min(event_sequence) as tran_start
      ,max(event_sequence) as tran_end
  from LockTrace
 where transaction_id in (select transaction_id
                            from LockTrace
                           where text_data like 'Lock request time out%')
 group by transaction_id
go

-- All transactions that were active during one specific timeout
select distinct transaction_id
  from LockTrace 
 where event_sequence between 13981 and	14113
go

-- All transactions that were active during timed-out transactions
with timed_out_trans as
 (
  select transaction_id
        ,min(event_sequence) as tran_start
        ,max(event_sequence) as tran_end
    from LockTrace
   where transaction_id in (select transaction_id
                              from LockTrace
                             where text_data like 'Lock request time out%')
   group by transaction_id
 )
select transaction_id as timed_out_tran
      ,stuff((select distinct ','+cast(transaction_id as nvarchar(10)) as [text()]
                from LockTrace as lt
                where lt.event_sequence between tot.tran_start and tot.tran_end
                  for xml path('')), 1, 1, '') as active_transactions
  from timed_out_trans as tot
go

-- Extended: All transactions that were active during timed-out transactions
with timed_out_trans as
 (
  select transaction_id
        ,min(event_sequence) as tran_start
        ,max(event_sequence) as tran_end
    from LockTrace
   where transaction_id in (select transaction_id
                              from LockTrace
                             where text_data like 'Lock request time out%')
   group by transaction_id
 )
select stuff((select distinct ','+cast(transaction_id as nvarchar(10)) as [text()]
                from LockTrace as lt
                where lt.event_sequence between tot.tran_start and tot.tran_end
                  for xml path('')), 1, 1, '') as active_transactions
      ,stuff((select distinct ',['+cast(transaction_id as nvarchar(10)) +']' as [text()]
                from LockTrace as lt
                where lt.event_sequence between tot.tran_start and tot.tran_end
                  for xml path('')), 1, 1, '') as active_tran_columns            
  from timed_out_trans as tot
go

-- Template for Locktrace pivot. Every transaction in one separate column, time running top to bottom
select *
  from (
        select event_class,text_data,event_sequence
              ,transaction_id,session_id 
              ,start_time,duration_ms
          from LockTrace
         where transaction_id in (/*list of transaction ids here*/)
       ) as t
 pivot (min(text_data) for transaction_id in (/*list of columns (transaction ids)*/)) aspvt
 order by event_sequence
go

-- Pivot Locktrace. Every transaction in one separate column, time running top to bottom
select *
  from (
        select event_class,text_data,event_sequence
              ,transaction_id,session_id 
              ,start_time,duration_ms
          from LockTrace
         where transaction_id in (216628,216630,216647,216648,216649,216650,216652,216653,216654,216655)
       ) as t
 pivot (min(text_data) for transaction_id in ([216628],[216630],[216647],[216648],[216649],[216650],[216652],[216653],[216654],[216655])) aspvt
 order by event_sequence
go


