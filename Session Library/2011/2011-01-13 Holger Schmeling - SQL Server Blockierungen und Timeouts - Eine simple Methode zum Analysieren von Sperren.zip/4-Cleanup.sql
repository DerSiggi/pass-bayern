use master
go
alter database LockTest set single_user with rollback immediate
go
drop database LockTest
go
