
use master
go
if db_id('LockTest') is not null
  begin
    alter database LockTest set single_user with rollback immediate
    drop database LockTest
  end
go

-- Create DB with one sinlge table
create database LockTest
go
use LockTest
go
create table t1
 (
  c1 int identity(1,1) not null --primary key clustered
 ,c2 int not null
 ,c3 nchar(100) not null)
go
-- insert some test data
insert t1(c2, c3)
  select language_id, stopword
    from sys.fulltext_system_stopwords
go

-- defrag and update stats
alter index all on t1 rebuild
go

select * from t1
go

-- set blocked process threshold to 2 seconds
-- This is an advanced options, so we have to enable
-- advanced options first
exec sp_configure 'show advanced options', 1
reconfigure

exec sp_configure 'blocked process threshold (s)', 2
reconfigure
go
select * from sys.configurations
 where name = 'blocked process threshold (s)'
