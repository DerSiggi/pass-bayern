

-- use OSTRESS for executing this script, e.g.
-- "C:\Program Files\Microsoft Corporation\RMLUtils\ostress" -E -S.\kanapali -o. -dLockTest -i".\2-Block.sql" -n4 -r20

set nocount on

-- 5 Seconds lock timeout
set lock_timeout 5000

 begin try
   begin tran

    update T1 set c2 = abs(checksum(newid()) % 10) 
     where c1 = 300+(abs(checksum(newid())) % 10)
    waitfor delay '00:00:04'
       
   commit
 end try
 -- Cleanup
 begin catch
   while (@@trancount > 0)
     rollback
 end catch
    
go
-- Cleanup
;while (@@trancount > 0)
  rollback
