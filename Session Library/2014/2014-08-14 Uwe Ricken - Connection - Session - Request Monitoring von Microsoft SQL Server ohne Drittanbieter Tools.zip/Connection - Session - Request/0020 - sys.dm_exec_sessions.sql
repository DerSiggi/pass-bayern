/*============================================================================
	File:		0020 - sys.dm_exec_sessions.sql

	Summary:	Dieses Script zeigt Beispiele serverinternen Sitzungen und die
				�ber eine Connection aufgebauten Benutzersitzungen.

				PS: F�r einen Test mit mehreren Sessions m�ssen folgende Bedingungen
					erf�llt sein:

				osstress ist auf dem Computer vorhanden
				http://support.microsoft.com/kb/944837/en-us

				Sowohl die Datenbank demo_db als auch die Prozedur f�r den Stresstest
				sind implementiert:

				0001 - create database and relations.sql
				0002 - Stored Procedure for execution with ostress.exe.sql

	Date:		Januar 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
/* generelle Informationen �ber sys.dm_exec_sessions */
EXEC sp_help 'sys.dm_exec_sessions';
EXEC sp_helptext 'sys.dm_exec_sessions';
GO

-- Serverinterne Sessions (Sitzungen) haben die session_id <= 50
SELECT * FROM sys.dm_exec_sessions;

-- Alle Sessions, die keine g�ltige Connection besitzen, sind Systemsessions
SELECT * FROM sys.dm_exec_sessions
WHERE	session_id NOT IN (SELECT session_id FROM sys.dm_exec_connections);
GO

-- ODER
SELECT * FROM sys.dm_exec_sessions WHERE is_user_process = 1;

-- Informationen �ber die Clientanwendung
SELECT	s.session_id,
		s.login_time,
		s.host_name,
		s.program_name,
		s.host_process_id,
		s.client_interface_name,
		s.login_name,
		s.nt_domain,
		s.original_security_id,
		s.original_login_name
FROM	sys.dm_exec_connections c INNER JOIN sys.dm_exec_sessions s
		ON (c.most_recent_session_id = s.session_id);
GO

-- Informationen �ber die Aktivi�ten (vergangen!) einer Session
SELECT	s.session_id,
		s.status,
		s.context_info,
		s.cpu_time,
		s.memory_usage,
		s.total_scheduled_time,
		s.total_elapsed_time,
		s.last_request_start_time,
		s.last_request_end_time,
		s.reads,
		s.writes,
		s.logical_reads,
		s.row_count,
		s.prev_error
FROM	sys.dm_exec_connections c INNER JOIN sys.dm_exec_sessions s
		ON (c.most_recent_session_id = s.session_id);
GO

-- Wer bin ich tats�chlich?
EXECUTE AS Login = 'sa';
SELECT TOP 1 * FROM master.sys.all_columns;

-- Informationen �ber die Clientanwendung
SELECT	s.session_id,
		s.login_time,
		s.security_id,
		s.login_name,
		s.nt_domain,
		s.original_security_id,
		s.original_login_name
FROM	sys.dm_exec_connections c INNER JOIN sys.dm_exec_sessions s
		ON (c.most_recent_session_id = s.session_id)
WHERE	c.most_recent_session_id = @@SPID;
REVERT
GO