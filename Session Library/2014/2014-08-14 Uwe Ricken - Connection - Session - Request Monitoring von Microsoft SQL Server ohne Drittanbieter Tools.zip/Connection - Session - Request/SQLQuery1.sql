-- Summary

-- 1. What user connections are open
