/*============================================================================
	File:		0050 - sys.dm_exec_query_plan.sql

	Summary:	Dieses Script zeigt Beispiele f�r die momentanen Verbindungen,
				die zum Server aufgebaut sind.

				PS: F�r einen Test mit mehreren Sessions m�ssen folgende Bedingungen
					erf�llt sein:

				osstress ist auf dem Computer vorhanden
				http://support.microsoft.com/kb/944837/en-us

				Sowohl die Datenbank demo_db als auch die Prozedur f�r den Stresstest
				sind implementiert:

				0001 - create database and relations.sql
				0002 - Stored Procedure for execution with ostress.exe.sql

	Date:		Mai 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
/* generelle Informationen �ber sys.dm_exec_sessions */
EXEC sp_help 'sys.dm_exec_query_plan';
EXEC sp_helptext 'sys.dm_exec_query_plan';
GO

SELECT	num_reads,
		num_writes,
		most_recent_sql_handle
FROM	sys.dm_exec_connections AS DEC;

SELECT	num_reads,
		num_writes,
		most_recent_sql_handle,
		DEQP.query_plan,
		DEC.*
FROM	sys.dm_exec_connections AS DEC
		OUTER APPLY sys.dm_exec_query_plan(DEC.most_recent_sql_handle) AS DEQP
GO

SELECT	DEC.*,
		DEQP.*
FROM	sys.dm_exec_connections AS DEC INNER JOIN sys.dm_exec_query_stats AS DEQS
		ON	(dec.most_recent_sql_handle = DEQS.sql_handle)
		CROSS APPLY sys.dm_exec_query_plan(DEQS.plan_handle) AS DEQP;

SELECT * FROM sys.dm_exec_procedure_stats AS DEPS