/*============================================================================
	File:		0002 - Stored Procedure for execution with ostress.exe.sql

	Summary:	Dieses Script muss im CMD-Modus ausgef�hrt werden, um sich
				auf den angebenen SQL Server zu verbinden. Anschlie�end werden
				unterschiedliche Abfragen auf die demo_db Datenbank ausgef�hrt!

	Date:		Januar 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db
GO

IF OBJECT_ID('dbo.proc_Simulate_Activity', 'P') IS NOT NULL
	DROP PROCEDURE dbo.proc_Simulate_Activity;
	GO

CREATE PROCEDURE dbo.proc_Simulate_Activity
AS
	SET NOCOUNT ON;
	DECLARE	@CustomerId	int	=	CAST(RAND() * 71 AS int);
	DECLARE	@stmt	NVARCHAR(2000);
	DECLARE	@parms	NVARCHAR(100);

	WHILE (1 = 1)
	BEGIN
		IF @CustomerId % 3 = 0
		BEGIN
			SET	@stmt	=	N'SELECT * FROM dbo.Customer WHERE Id = @CustomerId;';
			SET	@parms	=	N'@CustomerId int';

			EXEC	sp_executeSQL @stmt, @parms, @CustomerId;
			GOTO Looping
		END

		IF @CustomerId % 3 = 1
		BEGIN
			SET	@stmt	=	N'SELECT c.Id AS	CustomerId, c.CustomerName, YEAR(InvoiceDate) AS InvoiceYear, SUM(InvoiceAmount) AS	InvoiceAmount
FROM dbo.Customer c INNER JOIN dbo.Invoices i ON (c.Id = i.Customer_Id)
WHERE	c.Id <= @CustomerId
GROUP BY c.Id, c.CustomerName, YEAR(InvoiceDate);';
			SET	@parms	=	N'@CustomerId int';

			EXEC	sp_executeSQL @stmt, @parms, @CustomerId;
			GOTO Looping
		END

		IF @CustomerId % 3 = 2
		BEGIN
			SET	@stmt	=	N'UPDATE dbo.Customer SET CustomerName = ''I am Customer '' + CAST(@CustomerId AS varchar(20)) WHERE Id = @CustomerId;';
			SET	@parms	=	N'@CustomerId int';

			EXEC	sys.sp_executesql	@stmt, @parms, @CustomerId;
			GOTO Looping
		END

Looping:
		SET	@CustomerId	= CAST(RAND() * 71 AS int);
	END

	SET NOCOUNT OFF;
GO
