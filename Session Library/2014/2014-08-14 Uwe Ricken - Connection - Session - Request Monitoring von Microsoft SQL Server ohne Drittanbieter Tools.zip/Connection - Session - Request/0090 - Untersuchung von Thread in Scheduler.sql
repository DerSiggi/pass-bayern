/*============================================================================
	File:		0090 - Untersuchung von Thread in Scheduler.sql

	Summary:	Dieses Script zeigt Beispiele der Stati von Threads, die pro
				Scheduler laufen

				PS: F�r einen Test mit mehreren Sessions m�ssen folgende Bedingungen
					erf�llt sein:

				osstress ist auf dem Computer vorhanden
				http://support.microsoft.com/kb/944837/en-us

				Sowohl die Datenbank demo_db als auch die Prozedur f�r den Stresstest
				sind implementiert:

				0001 - create database and relations.sql
				0002 - Stored Procedure for execution with ostress.exe.sql

	Date:		April 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

/*
	HINWEIS:	Vor der Analyse der Stati von SQL Server Schedulers sollten
				100 Sessions mittels ostress.exe die oben genannte Prozedur
				ausf�hren!

				In einem CMD-Fenster folgenden Befehl ausf�hren:
				"C:\Program Files\Microsoft Corporation\RMLUtils\ostress.exe" -E -SNB-LENOVO-I\SQL_2012 -Q"EXEC dbo.proc_Simulate_Activity;" -ddemo_db -n100 -q
				(Gross- und Kleinschreibung beachten und den Servernamen (-S) ersetzen
*/

SELECT	dot.scheduler_id,
		dot.task_state,
		COUNT_BIG(*) 		AS Sum_Tasks
FROM	sys.dm_os_tasks AS dot INNER JOIN sys.dm_exec_requests AS der
		ON	(
				dot.request_id = der.request_id AND
				dot.session_id = der.session_id
			) INNER JOIN sys.dm_exec_sessions des
		ON	(der.session_id = des.session_id)
WHERE	des.is_user_process = 1
GROUP BY
		dot.scheduler_id,
		dot.task_state
ORDER BY
		dot.scheduler_id,
		dot.task_state;

-- Welche Tasks m�ssen warten?
SELECT	dowt.*
FROM	sys.dm_os_waiting_tasks AS dowt INNER JOIN sys.dm_exec_sessions des
		ON	(dowt.session_id = des.session_id)
WHERE	des.is_user_process = 1;

-- Warteliste: Wer wird von wem geblockt?
WITH blocking_hierarchy
AS
(
	SELECT	1									AS	Level,
			dowt.session_id,
			dowt.wait_type,
			dowt.resource_description,
			dowt.blocking_session_id			AS	blocking_session,
			CAST(dowt.session_id AS VARCHAR(20))	AS	Path
	FROM	sys.dm_os_waiting_tasks AS dowt INNER JOIN sys.dm_exec_sessions des
			ON	(dowt.session_id = des.session_id)
	WHERE	des.is_user_process = 1 AND
			dowt.blocking_session_id IS NULL

	UNION ALL

	SELECT	bh.Level + 1																AS	Level,
			dowt.session_id,
			dowt.wait_type,
			dowt.resource_description,
			dowt.blocking_session_id,
			CAST(bh.Path + '.' + CAST(dowt.session_id AS VARCHAR(20)) AS VARCHAR(20))	AS	Path
	FROM	sys.dm_os_waiting_tasks AS DOWT INNER JOIN blocking_hierarchy AS bh
			ON	(dowt.blocking_session_id = bh.session_id)
)
SELECT	CAST(REPLICATE('-', (level - 1) * 2) AS VARCHAR(5)) +  CAST(session_id AS VARCHAR(5)),
		CAST(wait_type AS VARCHAR(30))			AS	wait_type,
		resource_description
FROM	blocking_hierarchy
ORDER BY
		Path;