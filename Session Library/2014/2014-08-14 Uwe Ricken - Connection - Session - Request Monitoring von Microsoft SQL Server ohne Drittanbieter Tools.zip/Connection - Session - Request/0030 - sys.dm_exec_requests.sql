/*============================================================================
	File:		0030 - sys.dm_exec_requests.sql

	Summary:	Dieses Script zeigt Beispiele von aktuellen Ausf�hrungen innerhalb
				von Benutzer-Sessions.

				PS: F�r einen Test mit mehreren Sessions m�ssen folgende Bedingungen
					erf�llt sein:

				osstress ist auf dem Computer vorhanden
				http://support.microsoft.com/kb/944837/en-us

				Sowohl die Datenbank demo_db als auch die Prozedur f�r den Stresstest
				sind implementiert:

				0001 - create database and relations.sql
				0002 - Stored Procedure for execution with ostress.exe.sql

	Date:		Januar 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
/* generelle Informationen �ber sys.dm_exec_sessions */
EXEC sp_help 'sys.dm_exec_sessions';
EXEC sp_helptext 'sys.dm_exec_sessions';
GO

/* welche sessions sind AKTUELL aktiv */
SELECT * FROM sys.dm_exec_requests;
GO

/* welche USER-Sessions sind AKTUELL aktiv */
SELECT	DER.*
FROM	sys.dm_exec_requests AS DER INNER JOIN sys.dm_exec_sessions AS DES
		ON	(DER.session_id = DES.session_id)
WHERE	DES.is_user_process = 1;

/* welcher User f�hrt die aktuelle Aktion aus */
SELECT	DES.login_time,
		DES.login_name,
		DES.program_name,
		DB_NAME(DER.database_id)	AS	database_name,
		DER.start_time,
		DER.status,
		DER.wait_type,
		DER.wait_time,
		DER.wait_resource
FROM	sys.dm_exec_sessions AS DES INNER JOIN sys.dm_exec_requests AS DER
		ON	(DES.session_id = DER.session_id)
WHERE	DES.is_user_process = 1;
GO

-- Was wurde in den Verbindungen ZULETZT ausgef�hrt?
SELECT	DEC.session_id,
		DEC.num_reads,
		DEC.num_writes,
		DEC.last_read,
		DEC.last_write,
		DEST.text
FROM	sys.dm_exec_connections AS DEC
		CROSS APPLY sys.dm_exec_sql_text(DEC.most_recent_sql_handle) AS DEST
WHERE	DEC.session_id != @@spid;
GO

-- Was wird AKTUELL auf dem SQL Server ausgef�hrt?
-- 1. Wie viele Connections sind aktiv?
SELECT	COUNT_BIG(*)
FROM	sys.dm_exec_connections AS DEC;
GO

-- 2. Wie viele der aktiven Verbindungen sind Benutzerverbindungen
SELECT	COUNT_BIG(DEC.Session_id)
FROM	sys.dm_exec_connections AS DEC INNER JOIN sys.dm_exec_sessions AS DES
		ON (DEC.session_id = DES.session_id)
WHERE	DES.is_user_process = 1;
GO

-- 3. In wie vielen Verbindungen wird AKTUELL gearbeitet?
SELECT	COUNT_BIG(DEC.Session_id)
FROM	sys.dm_exec_connections AS DEC INNER JOIN sys.dm_exec_sessions AS DES
		ON	(dec.session_id = des.session_id) INNER JOIN sys.dm_exec_requests AS DER
		ON	(des.session_id = der.session_id)
WHERE	des.is_user_process = 1;
GO

-- 4. Was wird in den einzelnen Prozessen aktuell (RUNNING) ausgef�hrt?
SELECT	DES.session_id,
		DES.login_time,
		DES.original_login_name,
		DES.status				AS	session_status,
		DER.status				AS	request_status,
		DER.Command,
		DER.blocking_session_id,
		DER.wait_type,
		DER.wait_resource,
		DER.open_transaction_count,
		DER.scheduler_id,
		DER.reads,
		DER.writes,
		DER.logical_reads
FROM	sys.dm_exec_sessions AS DES INNER JOIN sys.dm_exec_requests AS DER
		ON	(DES.session_id = DER.session_id)
WHERE	DES.session_id != @@spid AND
		DES.is_user_process = 1;
GO
