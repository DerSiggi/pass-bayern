/*============================================================================
	File:		0010 - sys.dm_exec_connections.sql

	Summary:	Dieses Script zeigt Beispiele f�r die momentanen Verbindungen,
				die zum Server aufgebaut sind.

				PS: F�r einen Test mit mehreren Sessions m�ssen folgende Bedingungen
					erf�llt sein:

				osstress ist auf dem Computer vorhanden
				http://support.microsoft.com/kb/944837/en-us

				Sowohl die Datenbank demo_db als auch die Prozedur f�r den Stresstest
				sind implementiert:

				0001 - create database and relations.sql
				0002 - Stored Procedure for execution with ostress.exe.sql

	Date:		Januar 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
/* generelle Informationen �ber sys.dm_exec_sessions */
EXEC sp_help 'sys.dm_exec_connections';
EXEC sp_helptext 'sys.dm_exec_connections';
GO

-- Alle aktuellen Verbindungen, die zum SQL Server aufgebaut wurden
SELECT * FROM sys.dm_exec_connections
WHERE	session_id != @@SPID;

-- Seit wann sind die Connections aktiv?
SELECT	session_id,
		most_recent_session_id,
		connect_time,
		net_transport,
		protocol_type,
		auth_scheme
FROM	sys.dm_exec_connections
WHERE	session_id != @@SPID;

-- What was the last known sql statement executed over the connection
SELECT	c.session_id,
		c.most_recent_session_id,
		st.text
FROM	sys.dm_exec_connections c
		CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) st
WHERE	most_recent_session_id != @@spid;
GO

-- What is the machine name which holds a connection to the sql server
SELECT	session_id,
		most_recent_session_id,
		local_net_address,
		local_tcp_port,
		client_net_address,
		client_tcp_port
FROM	sys.dm_exec_connections
WHERE	session_id != @@SPID;

-- Wieviel Workload ist �ber die Connection bereits gelaufen
-- und was war der letzte Befehl, der �ber diese Connection
-- ausgef�hrt wurde?
SELECT	c.session_id,
		c.most_recent_session_id,
		c.last_read,
		c.num_reads,
		c.last_write,
		c.num_writes,
		t.text				AS	Last_SQLCommand
FROM	sys.dm_exec_connections c CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) t
WHERE	c.session_id != @@SPID;