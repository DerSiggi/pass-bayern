/*============================================================================
	File:		0003 - sys.dm_exec_connections.sql

	Summary:	Dieses Script zeigt Beispiele f�r die momentanen Verbindungen,
				die zum Server aufgebaut sind.

				PS: Es sollten die folgenden Scripte bereits im Vorfeld
					gestartet worden sein:

					0001 - StartConnection_0001.sql
					0002 - StartConnection_0002.sql
					0003 - StartConnection_0003.sql

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
-- Allgemeine Informationen zur View
--EXEC sp_help 'sys.dm_os_schedulers';
--GO

-- Wie viele Schedulers / Cores gibt es auf dem Server
SELECT	status,
		is_online,
		COUNT_BIG(*)
FROM	sys.dm_os_schedulers
GROUP BY
		status,
		is_online;
GO

-- 
SELECT	scheduler_id,
		cpu_id,
		status,
		is_online,
		is_idle,
		current_tasks_count,
		runnable_tasks_count,
		current_workers_count
FROM	sys.dm_os_schedulers
WHERE	status = 'VISIBLE ONLINE';
GO
