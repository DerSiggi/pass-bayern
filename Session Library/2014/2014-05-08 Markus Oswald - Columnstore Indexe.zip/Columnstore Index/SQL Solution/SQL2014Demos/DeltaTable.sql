USE AdventureWorksDW;
GO

-- create a demo "delta" table
SELECT TOP 1000 *
INTO dbo.FactInternetSalesBig12Delta
FROM dbo.FactInternetSalesBig12;
GO

-- our delta table is read-writable
UPDATE dbo.FactInternetSalesBig12Delta
SET DueDate = GETDATE();
GO

-- add the actual execution plan (Ctrl+M)

-- now we can join the two tables via UNION ALL
-- note that * sometimes * UNION ALL can inhibit batch execution mode
WITH FactInternetSalesBig12Unified AS
(
	SELECT
		DueDate,
		SalesAmount
	FROM dbo.FactInternetSalesBig12
	UNION ALL
	SELECT
		DueDate,
		SalesAmount
	FROM dbo.FactInternetSalesBig12Delta
)
SELECT
	DueDate,
	SUM(SalesAmount) AS SalesAmount
FROM FactInternetSalesBig12Unified
GROUP BY DueDate
ORDER BY DueDate;
GO

-- cleanup
DROP TABLE dbo.FactInternetSalesBig12Delta;
GO