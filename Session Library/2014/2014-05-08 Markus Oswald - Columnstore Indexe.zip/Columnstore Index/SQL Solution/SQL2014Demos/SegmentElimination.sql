-- extended event to capture columnstore segment elimination
IF EXISTS(SELECT 1 FROM sys.server_event_sessions WHERE name = 'SegmentElimination')
	DROP EVENT SESSION SegmentElimination ON SERVER;
GO

-- create event session
CREATE EVENT SESSION SegmentElimination
ON SERVER 
-- note: this event is part of the DEBUG channel
ADD EVENT sqlserver.column_store_segment_eliminate
WITH (MAX_MEMORY = 4096 KB, MAX_DISPATCH_LATENCY = 3 SECONDS); -- note: MAX_DISPATCH_LATENCY >= 30 SECONDS on a production system
GO

ALTER EVENT SESSION SegmentElimination
ON SERVER STATE = START;

-- watch live data for the session

USE AdventureWorksDW;
GO

-- examine the CSIX_FactInternetSalesBig12 segments
SELECT
	s.column_id,
    s.min_data_id,
    s.max_data_id,
    s.segment_id
FROM sys.column_store_segments AS s
INNER JOIN sys.partitions AS p 
    ON s.hobt_id = p.hobt_id 
INNER JOIN sys.indexes AS i 
    ON p.object_id = i.object_id
WHERE i.name = 'CSIX_FactInternetSalesBig12' AND i.type = 6 AND s.column_id = 2 -- OrderDateKey
ORDER BY s.column_id, s.min_data_id, s.max_data_id, s.segment_id;

-- direct trace flag text output to the SQL Server error log file
DBCC TRACEON(3605, -1);
GO 

-- turn on text output that shows when segments (row groups) are eliminated
DBCC TRACEON(646, -1);
GO

EXEC sp_cycle_errorlog;
GO 

-- run a typical DWH workload query
SELECT
	OrderDateKey,
	ProductKey,
	PromotionKey,
    SUM(OrderQuantity) AS TotalOrderQuantity
FROM dbo.FactInternetSalesBig12
GROUP BY OrderDateKey, ProductKey, PromotionKey
HAVING OrderDateKey BETWEEN 20080101 AND 20080729
OPTION (RECOMPILE);

DBCC TRACEOFF(646, -1);
GO

DBCC TRACEOFF(3605, -1);
GO 

-- read the error log
EXEC sp_readerrorlog;

-- stop the event session
ALTER EVENT SESSION SegmentElimination ON SERVER STATE = STOP;
GO
 
-- cleanup
DROP EVENT SESSION SegmentElimination ON SERVER;
GO