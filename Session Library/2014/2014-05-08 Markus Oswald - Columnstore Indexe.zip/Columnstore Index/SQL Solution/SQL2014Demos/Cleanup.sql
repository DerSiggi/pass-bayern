-- cleanup
USE AdventureWorksDW;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'dbo.FactInternetSalesBig14'), 'IsUserTable') IS NOT NULL
	DROP TABLE dbo.FactInternetSalesBig14;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'dbo.FactInternetSalesBig12'), 'IsUserTable') IS NOT NULL
	DROP TABLE dbo.FactInternetSalesBig12;
GO

IF EXISTS (SELECT * FROM sys.partition_schemes WHERE name = 'psOrderDateMonth') 
	DROP PARTITION SCHEME psOrderDateMonth;
GO

IF EXISTS (SELECT * FROM sys.partition_functions WHERE name = 'pfOrderDateMonth') 
	DROP PARTITION FUNCTION pfOrderDateMonth;
GO