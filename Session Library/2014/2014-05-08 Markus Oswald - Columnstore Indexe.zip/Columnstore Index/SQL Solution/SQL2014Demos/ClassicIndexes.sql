USE AdventureWorksDW;
GO

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- run this DWH query
SELECT 
	ST.SalesTerritoryRegion AS Region, 
	MIN(P.EnglishProductName) AS Product, 
	D.CalendarYear, 
	D.CalendarQuarter,  
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
INNER JOIN
	dbo.DimProductSubcategory PS ON PS.ProductCategoryKey = P.ProductSubcategoryKey
INNER JOIN
	dbo.DimSalesTerritory ST ON ST.SalesTerritoryKey = FIS.SalesTerritoryKey
WHERE
		PS.EnglishProductSubcategoryName = 'Mountain Bikes' 
	AND 
		D.DateKey BETWEEN 20050101 AND 20083112
	AND
		FIS.SalesTerritoryKey = 3
GROUP BY
	ST.SalesTerritoryRegion, P.ProductKey, D.CalendarYear, D.CalendarQuarter
ORDER BY
	Region, Product, D.CalendarYear, D.CalendarQuarter;

/****************************************************************************************
	Tuning part 1: We help ourselves...
****************************************************************************************/

--
-- 1.) Idea:  Create a non clustered index on the SalesTerritoryKey, since it is part of the WHERE predicate
--

CREATE NONCLUSTERED INDEX IX_FactInternetSalesBig_SalesTerritoryKey 
ON dbo.FactInternetSalesBig
(
	SalesTerritoryKey ASC
);
GO

--
-- 2.) and test...
--

SELECT 
	ST.SalesTerritoryRegion AS Region, 
	MIN(P.EnglishProductName) AS Product, 
	D.CalendarYear, 
	D.CalendarQuarter,  
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
INNER JOIN
	dbo.DimProductSubcategory PS ON PS.ProductCategoryKey = P.ProductSubcategoryKey
INNER JOIN
	dbo.DimSalesTerritory ST ON ST.SalesTerritoryKey = FIS.SalesTerritoryKey
WHERE
		PS.EnglishProductSubcategoryName = 'Mountain Bikes' 
	AND 
		D.DateKey BETWEEN 20050101 AND 20083112
	AND
		FIS.SalesTerritoryKey = 3
GROUP BY
	ST.SalesTerritoryRegion, P.ProductKey, D.CalendarYear, D.CalendarQuarter
ORDER BY
	Region, Product, D.CalendarYear, D.CalendarQuarter;

-- 1,4 mio reads, 500 ms.
-- What happened?



--
-- 3) Look at the data distribution of the Sales Territories
--

SELECT 
	FIS.SalesTerritoryKey,
	COUNT(*) AS CountKeys
FROM
	dbo.FactInternetSales FIS
GROUP BY 
	FIS.SalesTerritoryKey
ORDER BY 
	COUNT(*) DESC;



--
-- 4) Test against the fact table
--

SELECT 
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSales FIS
WHERE
	FIS.SalesTerritoryKey = 3;

--  still 1,4 mio reads


--
-- 4.) Index hint, less matches
--

SELECT 
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSales FIS 
	WITH (INDEX (IX_FactInternetSales_SalesTerritoryKey))
WHERE
	FIS.SalesTerritoryKey = 3

--  yeah: 230.000 reads, 130 ms. That's *much* better.



--
-- 4.) Index hint, many matches
--

SELECT 
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSales FIS 
	WITH (INDEX (IX_FactInternetSales_SalesTerritoryKey))
WHERE
	FIS.SalesTerritoryKey = 4

-- ups: 2,5 mio reads, 1,3 s. That's *much* worse. 



/****************************************************************************************
	Tuning part 2: We let us help...
****************************************************************************************/

--
-- 2. Idea: Use the optimizer's Missing Index Recommendation
--

CREATE NONCLUSTERED INDEX IX_FactInternetSales_SalesTerritoryKey_OrderDateKey 
ON dbo.FactInternetSales(SalesTerritoryKey,OrderDateKey)
INCLUDE (ProductKey, OrderQuantity, SalesAmount);
GO


-- and test
SELECT 
	ST.SalesTerritoryRegion AS Region, 
	MIN(P.EnglishProductName) AS Product, 
	D.CalendarYear, 
	D.CalendarQuarter,  
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSales FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
INNER JOIN
	dbo.DimProductSubcategory PS ON PS.ProductCategoryKey = P.ProductSubcategoryKey
INNER JOIN
	dbo.DimSalesTerritory ST ON ST.SalesTerritoryKey = FIS.SalesTerritoryKey
WHERE
		PS.EnglishProductSubcategoryName = 'Mountain Bikes' 
	AND 
		D.DateKey BETWEEN 20080101 AND 20103112
	AND
		FIS.SalesTerritoryKey = 3
GROUP BY
	ST.SalesTerritoryRegion, P.ProductKey, D.CalendarYear, D.CalendarQuarter
ORDER BY
	Region, Product, D.CalendarYear, D.CalendarQuarter;

-- only 274 pages, 100ms. That's worth the effort.

-- cleanup
DROP INDEX dbo.FactInternetSales.IX_FactInternetSales_SalesTerritoryKey;
DROP INDEX dbo.FactInternetSales.IX_FactInternetSales_SalesTerritoryKey_OrderDateKey;