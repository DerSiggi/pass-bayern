USE AdventureWorksDW;
GO

-- Partitioning

-- create a partition function to partition for days, only for a few samples values
CREATE PARTITION FUNCTION pfOrderDate (int) AS RANGE LEFT FOR VALUES
	(20080701, 20080702, 20080703, 20080704, 20080705);
GO

-- create a simple partitioning scheme
CREATE PARTITION SCHEME psFactInternetSales AS PARTITION pfOrderDate ALL 
TO ([PRIMARY]);
GO

-- create a partitioned copy of the FactInternetSales table
CREATE TABLE dbo.FactInternetSalesPTD
(
	ProductKey int NOT  NULL,
	OrderDateKey int NOT NULL,
	CustomerKey int NOT  NULL,
	SalesTerritoryKey int NOT NULL,
	OrderQuantity smallint NOT NULL,
	SalesAmount money NOT NULL
) ON psFactInternetSales(OrderDateKey);
GO

-- create the clustered index with PAGE data compression
CREATE CLUSTERED INDEX CIX_FactInternetSalesPTD_OrderDateKey
ON dbo.FactInternetSalesPTD (OrderDateKey ASC)
WITH (DATA_COMPRESSION = PAGE) ON psFactInternetSales(OrderDateKey);
GO

-- insert records for four days
INSERT INTO dbo.FactInternetSalesPTD WITH(TABLOCKX)
SELECT
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesTerritoryKey,
	OrderQuantity,
	SalesAmount
FROM dbo.FactInternetSales
WHERE 
	OrderDateKey IN (20080701, 20080702, 20080703, 20080704);
GO

-- check the data distribution
SELECT 
	$PARTITION.pfOrderDate(OrderDateKey) AS partition_number, 
	COUNT(*) AS row_count
FROM 
	dbo.FactInternetSalesPTD
GROUP BY
	$PARTITION.pfOrderDate(OrderDateKey);
GO

-- create a columnstore index
-- note: no parameters as FILLFACTOR, SORT_IN_TEMPDB
CREATE NONCLUSTERED COLUMNSTORE INDEX CSIX_FactInternetSalesPTD
ON dbo.FactInternetSalesPTD 
(
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesTerritoryKey,
	OrderQuantity,
	SalesAmount
) ON psFactInternetSales( OrderDateKey );
GO

-- Loading

-- create a staging table
CREATE TABLE dbo.FactInternetSalesSTG
(
	ProductKey int NOT NULL,
	OrderDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	OrderQuantity smallint NOT NULL,
	SalesAmount money NOT NULL
); 

-- create the clustered index with PAGE data compression on the staging table
CREATE CLUSTERED INDEX CIX_FactInternetSalesSTG_OrderDateKey
ON dbo.FactInternetSalesSTG (OrderDateKey ASC)
WITH (DATA_COMPRESSION = PAGE) ON [Primary];
GO

-- fill the staging table with data for date 20080705
INSERT INTO dbo.FactInternetSalesSTG WITH (TABLOCKX)
SELECT
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesTerritoryKey,
	OrderQuantity,
	SalesAmount
FROM dbo.FactInternetSales
WHERE 
	OrderDateKey = 20080705;

-- create the mandatory check constraint to tell SQL Server
-- that the data fits into the target table
ALTER TABLE dbo.FactInternetSalesSTG
ADD CONSTRAINT CHK_OrderDateKey 
CHECK (OrderDateKey = 20080705);

-- create the columnstore index on the staging table
CREATE NONCLUSTERED COLUMNSTORE INDEX CSIX_FactInternetSalesSTG  
ON dbo.FactInternetSalesSTG
(
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesTerritoryKey,
	OrderQuantity,
	SalesAmount
); 
GO

-- switch the data
-- first extend the range of the partition function
ALTER PARTITION FUNCTION pfOrderDate() SPLIT RANGE (20080706);
GO

-- and then switch...
ALTER TABLE dbo.FactInternetSalesSTG SWITCH 
TO [dbo].[FactInternetSalesPTD] PARTITION $PARTITION.pfOrderDate(20080705);
GO

-- check where the data has gone
SELECT 
	$PARTITION.pfOrderDate(OrderDateKey) AS partition_number, 
	COUNT(*) AS row_count
FROM 
	dbo.FactInternetSalesPTD
GROUP BY
	$PARTITION.pfOrderDate(OrderDateKey);

-- run a query to see the result
SELECT 
	OrderDateKey, 
	SUM(OrderQuantity) AS OrderQuantity, 
	ROUND(SUM(SalesAmount), 2) AS SalesAmount
FROM
	dbo.FactInternetSalesPTD
GROUP BY
	OrderDateKey
ORDER BY
	OrderDateKey;

-- cleanup
USE AdventureWorksDW;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'dbo.FactInternetSalesSTG'), 'IsUserTable') IS NOT NULL
	DROP TABLE dbo.FactInternetSalesSTG;
GO

IF OBJECTPROPERTY(OBJECT_ID(N'dbo.FactInternetSalesPTD'), 'IsUserTable') IS NOT NULL
	DROP TABLE dbo.FactInternetSalesPTD;
GO

IF EXISTS (SELECT * FROM sys.partition_schemes WHERE name = 'psFactInternetSales') 
	DROP PARTITION SCHEME psFactInternetSales;
GO

IF EXISTS (SELECT * FROM sys.partition_functions WHERE name = 'pfOrderDate') 
	DROP PARTITION FUNCTION pfOrderDate;
GO