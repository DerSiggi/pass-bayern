USE AdventureWorksDW;
GO

-- add the actual execution plan (Ctrl+M)

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

--
-- 1.) Run a sample DWH query
--

SELECT 
	P.ProductKey,
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount 
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
GROUP BY
	P.ProductKey;

-- 93339 reads, 12ms



--
-- 2.) Create an indexed view for the query
--

CREATE VIEW dbo.vwStarView WITH SCHEMABINDING
AS
SELECT 
	P.ProductKey,
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount) AS SalesAmount,
	COUNT_BIG(*) AS OrderCount 
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
GROUP BY
	P.ProductKey;



--
-- 3.) ... and the clustered index
--

CREATE UNIQUE CLUSTERED INDEX IX_vwStarView
ON vwStarView (ProductKey);

-- and test the indexed view
SELECT TOP (10) * FROM vwStarView;



--
-- 4.) The optimizer uses it. OK it's simple...
-- 

SELECT 
	P.ProductKey,
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount 
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
GROUP BY
	P.ProductKey;

-- reads: 2; < 1 ms. wow, not bad.



--
-- 5.) However, a simple modification kills it...
-- 

SELECT 
	P.ProductKey,
	P.EnglishProductName,  -- we need the product name as well
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount 
FROM
	dbo.FactInternetSalesBig FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
GROUP BY
	P.ProductKey, P.EnglishProductName;

-- ok. we already know this: 93339 reads, 12ms

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
GO

-- cleanup
USE AdventureWorksDW;
GO

DROP VIEW vwStarView;