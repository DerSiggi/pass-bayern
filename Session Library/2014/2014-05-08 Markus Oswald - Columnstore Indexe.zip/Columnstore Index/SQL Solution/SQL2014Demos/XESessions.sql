/*
If the query executes in parallel but falls back to row mode processing, you can infer that memory was the problem.
There is also an xevent (batch_hash_table_build_bailout) that is fired when there is not enough memory
during hash join and the query falls back to row mode processing.
If this happens, incorrect cardinality estimation may have contributed to the problem.
Check the cardinality estimation and consider updating statistics on the table.
*/

-- batch hash table build bailouts
CREATE EVENT SESSION BatchHashTableBuildBailout ON SERVER 
ADD EVENT sqlserver.batch_hash_table_build_bailout(
    ACTION(
		sqlserver.database_name,
		sqlserver.plan_handle,
		sqlserver.query_hash,
		sqlserver.query_plan_hash,
		sqlserver.session_id,
		sqlserver.sql_text)
	)
-- ADD TARGET package0.ring_buffer,
ADD TARGET package0.event_file(
	SET FILENAME = N'C:\Temp\BatchHashTableBuildBailout.xel')
WITH (MAX_MEMORY = 4096 KB, MAX_DISPATCH_LATENCY = 30 SECONDS);
GO

-- inaccurate cardinality estimates
CREATE EVENT SESSION InaccurateCardinalityEstimates
ON SERVER 
ADD EVENT sqlserver.inaccurate_cardinality_estimate(
	ACTION(
		sqlserver.plan_handle,
		sqlserver.sql_text)
	)
-- ADD TARGET package0.ring_buffer,
ADD TARGET package0.event_file(
	SET FILENAME = N'C:\Temp\InaccurateCardinalityEstimates.xel')
WITH (MAX_MEMORY = 4096 KB, MAX_DISPATCH_LATENCY = 30 SECONDS);
GO

