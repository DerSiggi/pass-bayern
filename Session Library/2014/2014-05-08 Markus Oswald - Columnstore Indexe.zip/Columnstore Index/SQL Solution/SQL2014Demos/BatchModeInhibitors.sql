-- run against a SQL 2012 and a SQL 2014 instance to see the differences in execution modes

USE AdventureWorksDW;
GO

-- add actual execution plan (Ctrl+M)

--
-- Scalar Aggregate Batch Execution Inhibitor
--

-- row mode in SQL 2012, batch mode in SQL 2014
SELECT
	SUM(f.SalesAmount) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f;
GO

-- batch mode with grouping
SELECT
	SUM(f.SalesAmount) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
GROUP BY YEAR(OrderDate);

-- batch mode with CTE
WITH IntermediateResult
AS (
	SELECT
		YEAR(OrderDate) AS OrderDateYear, 
		SUM(f.SalesAmount) AS TotalSalesAmount
	FROM dbo.FactInternetSalesBig12 AS f
	GROUP BY YEAR(OrderDate) 
 ) 
SELECT
	SUM(TotalSalesAmount) AS TotalSalesAmount
FROM IntermediateResult;
GO

-- 
-- Not In Batch Execution Inhibitor
--

-- row mode in SQL 2012, batch mode in SQL 2014
SELECT
	f.ProductKey,
    ISNULL(SUM(f.SalesAmount),0.00) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
WHERE f.ProductKey NOT IN
	(SELECT ProductKey
	 FROM dbo.DimProduct 
	 WHERE WeightUnitMeasureCode IS NULL)
GROUP BY f.ProductKey
ORDER BY f.ProductKey;
GO

-- re-write to batch execution mode
SELECT
	f.ProductKey,
    ISNULL(SUM(f.SalesAmount), 0.00) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
INNER JOIN dbo.DimProduct AS p ON
	f.ProductKey = p.ProductKey
WHERE p.WeightUnitMeasureCode IS NOT NULL
GROUP BY f.ProductKey
ORDER BY f.ProductKey;
GO

-- CTE alternative
WITH Sales
AS
	(SELECT
		ProductKey,
		ISNULL(SUM(SalesAmount),0.00) AS TotalSalesAmount
	FROM dbo.FactInternetSalesBig12 AS f
	GROUP BY ProductKey)
SELECT
	s.ProductKey,
	s.TotalSalesAmount
FROM Sales AS s
WHERE s.ProductKey NOT IN
	(SELECT ProductKey
	 FROM dbo.DimProduct 
	 WHERE WeightUnitMeasureCode IS NULL)
ORDER BY s.ProductKey;
GO

--
-- Serial Plan Batch Execution Inhibitor
--

-- parallelism used to execute the query?
SELECT
	p.ProductLine,
	f.SalesTerritoryKey,
	f.CustomerKey,
    AVG(f.SalesAmount) AS AvgSalesAmount,
    SUM(f.SalesAmount) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
INNER JOIN dbo.DimProduct AS p
	ON f.ProductKey = p.ProductKey
WHERE p.Size IS NOT NULL AND
	  f.UnitPriceDiscountPct = 0
GROUP BY p.ProductLine, f.SalesTerritoryKey, f.CustomerKey
ORDER BY p.ProductLine, f.SalesTerritoryKey, f.CustomerKey;
GO

-- configuring server level MAXDOP
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
GO

EXEC sp_configure 'max degree of parallelism', 1;
RECONFIGURE;
GO

-- what is the plan shape now?
SELECT
	p.ProductLine,
	f.SalesTerritoryKey,
	f.CustomerKey,
    AVG(f.SalesAmount) AS AvgSalesAmount,
    SUM(f.SalesAmount) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
INNER JOIN dbo.DimProduct AS p
    ON f.ProductKey = p.ProductKey
WHERE p.Size IS NOT NULL AND
		f.UnitPriceDiscountPct = 0
GROUP BY p.ProductLine, f.SalesTerritoryKey, f.CustomerKey
ORDER BY p.ProductLine, f.SalesTerritoryKey, f.CustomerKey;
GO

-- reset server level MAXDOP
EXEC sp_configure 'max degree of parallelism', 4;
RECONFIGURE;
GO

EXEC sp_configure 'show advanced options', 0;
RECONFIGURE;
GO