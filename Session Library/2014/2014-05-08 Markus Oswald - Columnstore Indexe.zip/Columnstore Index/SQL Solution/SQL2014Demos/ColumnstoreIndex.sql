USE AdventureWorksDW;
GO

EXEC sp_helpindex 'FactInternetSalesBig14';
GO

-- SQL Server 2014
-- convert an existing clustered index to a clustered columnstore index
/*
Msg 35304, Level 16, State 1
CREATE INDEX statement failed
because a clustered columnstore index cannot be created
on a table that has a nonclustered index.
Consider dropping all nonclustered indexes and trying again.
*/
CREATE CLUSTERED COLUMNSTORE INDEX CSIX_FactInternetSalesBig12
ON dbo.FactInternetSalesBig14
WITH (DROP_EXISTING = ON);
GO

-- check the number of records in the FactInternetSalesBig table
SELECT
	FORMAT(COUNT(*), '#,##') AS row_num
FROM dbo.FactInternetSalesBig14;

-- used page allocation for the columnstore index
SELECT
	[partition_id],
	SUM(in_row_used_page_count) AS in_row_used_page_count,
    SUM(lob_used_page_count) AS lob_used_page_count,
    SUM(row_count) AS row_count
FROM sys.dm_db_partition_stats
WHERE [object_id] = OBJECT_ID('FactInternetSalesBig12') AND
	  index_id = INDEXPROPERTY
		(OBJECT_ID('FactInternetSalesBig12'),
		'CSIX_FactInternetSalesBig12', 
		'IndexId')
GROUP BY [partition_id];
GO

-- Nonclustered CS Index
-- lob_used_page_count: 46567 | row_count: 15461888

SELECT
	[partition_id],
	SUM(in_row_used_page_count) AS in_row_used_page_count,
    SUM(lob_used_page_count) AS lob_used_page_count,
    SUM(row_count) AS row_count
FROM sys.dm_db_partition_stats
WHERE [object_id] = OBJECT_ID('FactInternetSalesBig14') AND
	  index_id = INDEXPROPERTY
		(OBJECT_ID('FactInternetSalesBig14'),
		'CSIX_FactInternetSalesBig14', 
		'IndexId')
GROUP BY [partition_id];
GO

-- Clustered CS Index
-- lob_used_page_count: 42635 | row_count: 15461888

-- segments of a columnstore index
SELECT
	i.name,
	p.partition_id,
	p.object_id,
	p.index_id,
	i.type_desc, 
    COUNT(*) AS segment_count
FROM sys.column_store_segments AS s 
INNER JOIN sys.partitions AS p 
    ON s.hobt_id = p.hobt_id 
INNER JOIN sys.indexes AS i 
    ON p.object_id = i.object_id
WHERE i.type IN (5, 6) AND i.name = 'CSIX_FactInternetSalesBig14'
GROUP BY i.name, p.partition_id, p.object_id, p.index_id, i.type_desc;
GO

-- segment information
SELECT
	[partition_id],
    hobt_id,
    column_id,
    segment_id,
    encoding_type,
    row_count,
    primary_dictionary_id,
    secondary_dictionary_id,
    min_data_id,
    max_data_id,
    on_disk_size
FROM sys.column_store_segments;
GO

-- all columns for the same segment have the same number of rows
SELECT
	[partition_id],
    hobt_id,
    column_id,
    segment_id,
    row_count,
    on_disk_size
FROM sys.column_store_segments
WHERE segment_id = 1;
GO

-- rowgroups, the calculated percent_full column is an estimate of the efficiency of the row group
SELECT
	i.object_id,
	object_name(i.object_id) AS table_name,
	i.name AS index_name,
	i.index_id,
	i.type_desc,
	rg.*, 
	100 * (total_rows - ISNULL(deleted_rows,0))/total_rows AS percent_full
FROM sys.indexes AS i
INNER JOIN sys.column_store_row_groups AS rg
    ON i.object_id = rg.object_id
AND i.index_id = rg.index_id 
-- WHERE object_name(i.object_id) = '<table_name>' 
ORDER BY object_name(i.object_id), i.name, row_group_id;

-- columnstore dictionary meta-data
SELECT
	[partition_id],
    hobt_id,
    column_id,
    dictionary_id, 
    [type],
    entry_count,
    on_disk_size
FROM sys.column_store_dictionaries
-- WHERE column_id = 9;
GO

-- verify the columnid
SELECT
	name,
	column_id
FROM sys.columns
WHERE [object_id] = OBJECT_ID('FactInternetSalesBig14')

-- how compression-friendly is the SalesOrderNumber	column ?
SELECT
	FORMAT(COUNT(DISTINCT [SalesOrderNumber]), '#,##') AS SalesOrderNumbers
FROM dbo.FactInternetSalesBig14;
GO

DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;

-- add the actual execution plan (Ctrl+M)

SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

-- look at the subtree cost and memory grant of the root operator 

-- nonclustered CS index
SELECT
	p.ModelName,
	t.SalesTerritoryCountry,
	COUNT(*) SalesCount,
    ROUND(AVG(f.SalesAmount), 2) AS AvgSalesAmount,
    ROUND(SUM(f.SalesAmount), 2) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig12 AS f
INNER JOIN dbo.DimProduct AS p
	ON f.ProductKey = p.ProductKey
INNER JOIN dbo.DimSalesTerritory t
	ON f.SalesTerritoryKey = t.SalesTerritoryKey
WHERE p.Size IS NOT NULL
	AND f.UnitPriceDiscountPct = 0
GROUP BY p.ModelName, t.SalesTerritoryCountry
ORDER BY p.ModelName, t.SalesTerritoryCountry
OPTION
	(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
GO

-- clustered CS index
SELECT
	p.ModelName,
	t.SalesTerritoryCountry,
	COUNT(*) SalesCount,
    ROUND(AVG(f.SalesAmount), 2) AS AvgSalesAmount,
    ROUND(SUM(f.SalesAmount), 2) AS TotalSalesAmount
FROM dbo.FactInternetSalesBig14 AS f
INNER JOIN dbo.DimProduct AS p
	ON f.ProductKey = p.ProductKey
INNER JOIN dbo.DimSalesTerritory t
	ON f.SalesTerritoryKey = t.SalesTerritoryKey
WHERE p.Size IS NOT NULL
	AND f.UnitPriceDiscountPct = 0
GROUP BY p.ModelName, t.SalesTerritoryCountry
ORDER BY p.ModelName, t.SalesTerritoryCountry;
GO

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

-- update the clustered columnstore index
EXEC sp_helpindex 'FactInternetSalesBig14';
GO

SELECT
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesOrderNumber,
	OrderQuantity,
	UnitPrice
FROM dbo.FactInternetSalesBig14
WHERE ProductKey = 528 AND OrderDateKey = 20080731
AND SalesOrderNumber = N'D095A370-A85C-4811-A';

UPDATE dbo.FactInternetSalesBig14 SET OrderQuantity = 2
WHERE ProductKey = 528 AND OrderDateKey = 20080731
AND SalesOrderNumber = N'D095A370-A85C-4811-A';

-- try to create a nonclustered index
CREATE NONCLUSTERED INDEX IX_FactInternetSalesBig14_SalesTerritoryKey 
ON dbo.FactInternetSalesBig14
(
	SalesTerritoryKey ASC
);
GO

/*
CREATE INDEX statement failed because a nonclustered index cannot be created on a table that has a clustered columnstore index.
Consider replacing the clustered columnstore index with a nonclustered columnstore index.
*/

-- try to update the nonclustered columnstore index
EXEC sp_helpindex 'FactInternetSalesBig12';
GO

SELECT
	ProductKey,
	OrderDateKey,
	CustomerKey,
	SalesOrderNumber,
	OrderQuantity,
	UnitPrice
FROM dbo.FactInternetSalesBig12
WHERE ProductKey = 528 AND OrderDateKey = 20080628
AND SalesOrderNumber = N'D8B50E4E-697F-4BEF-B';

UPDATE dbo.FactInternetSalesBig12 SET OrderQuantity = 2
WHERE ProductKey = 528 AND OrderDateKey = 20080628
AND SalesOrderNumber = N'D8B50E4E-697F-4BEF-B';

-- SQL Server 2012
/*
UPDATE statement failed because data cannot be updated in a table with a columnstore index.
Consider disabling the columnstore index before issuing the UPDATE statement,
the rebuilding the columnstore index after UPDATE is complete.
*/