USE master;
GO

-- pre-size your database to reduce auto-growth operations
ALTER DATABASE AdventureWorksDW
	MODIFY FILE (NAME = N'AdventureWorksDW', 
	SIZE = 2048MB, FILEGROWTH = 1024MB);
GO

ALTER DATABASE AdventureWorksDW
	MODIFY FILE (NAME = N'AdventureWorksDW_Log', 
	SIZE = 1024MB, FILEGROWTH = 512MB);
GO

ALTER DATABASE AdventureWorksDW SET RECOVERY SIMPLE;
GO

USE AdventureWorksDW;
GO

SET NOCOUNT ON;
GO

/*
-- create partition function
CREATE PARTITION FUNCTION pfOrderDateMonth(int) AS RANGE RIGHT
FOR VALUES (
    20050701, 20050801, 20050901, 20051001, 20051101, 20051201,
    20060101, 20060201, 20060301, 20060401, 20060501, 20060601,
    20060701, 20060801, 20060901, 20061001, 20061101, 20061201,
    20070101, 20070201, 20070301, 20070401, 20070501, 20070601,
    20070701, 20070801, 20070901, 20071001, 20071101, 20071201,
    20080101, 20080201, 20080301, 20080401, 20080501, 20080601,
    20080701, 20080801, 20080901, 20081001, 20081101, 20081201
);
GO

-- create partition scheme
CREATE PARTITION SCHEME psOrderDateMonth
AS PARTITION pfOrderDateMonth
ALL TO ([PRIMARY]);
GO
*/

-- create a big (partitioned) version of the FactInternetSales table
CREATE TABLE dbo.FactInternetSalesBig12 (
    ProductKey int NOT NULL,
	OrderDateKey int NOT NULL,
	DueDateKey int NOT NULL,
	ShipDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	SalesOrderNumber nvarchar(20) NOT NULL,
	SalesOrderLineNumber tinyint NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderQuantity smallint NOT NULL,
	UnitPrice money NOT NULL,
	ExtendedAmount money NOT NULL,
	UnitPriceDiscountPct float NOT NULL,
	DiscountAmount float NOT NULL,
	ProductStandardCost money NOT NULL,
	TotalProductCost money NOT NULL,
	SalesAmount money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	CustomerPONumber nvarchar(25) NULL,
	OrderDate datetime NULL,
	DueDate datetime NULL,
	ShipDate datetime NULL
) ON [PRIMARY]; -- psOrderDateMonth(OrderDateKey);
GO

-- create the clustered index with PAGE data compression
CREATE CLUSTERED INDEX CIX_FactInternetSalesBig12_OrderDateKey
ON dbo.FactInternetSalesBig12 (OrderDateKey ASC)
WITH (DATA_COMPRESSION = PAGE);
GO

-- copy the data from the FactInternetSales into the new table
INSERT INTO dbo.FactInternetSalesBig12 WITH(TABLOCKX)
SELECT * FROM dbo.FactInternetSales;
GO

-- increasing the number of rows
INSERT INTO dbo.FactInternetSalesBig12 WITH(TABLOCKX)
	(ProductKey, OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, ExtendedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStandardCost, TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate)
SELECT
	ProductKey, OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, PromotionKey, CurrencyKey, SalesTerritoryKey, LEFT(CAST(NEWID() AS NVARCHAR(36)), 20) AS SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, ExtendedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStandardCost, TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate
FROM dbo.FactInternetSalesBig12;
CHECKPOINT;
GO 8 -- change this based on your test environment storage and time you want to wait

-- check the number of records in the FactInternetSalesBig12 table
SELECT
	FORMAT(COUNT(*), '#,##') AS row_num
FROM dbo.FactInternetSalesBig12;

-- create a non clustered columnstore index
CREATE NONCLUSTERED COLUMNSTORE INDEX CSIX_FactInternetSalesBig12
ON dbo.FactInternetSalesBig12
(
	ProductKey,
	OrderDateKey,
	DueDateKey,
	ShipDateKey,
	CustomerKey,
	PromotionKey,
	CurrencyKey,
	SalesTerritoryKey,
	SalesOrderNumber,
	SalesOrderLineNumber,
	RevisionNumber,
	OrderQuantity,
	UnitPrice,
	ExtendedAmount,
	UnitPriceDiscountPct,
	DiscountAmount,
	ProductStandardCost,
	TotalProductCost,
	SalesAmount,
	TaxAmt,
	Freight,
	CarrierTrackingNumber,
	CustomerPONumber,
	OrderDate,
	DueDate,
	ShipDate
	);
GO

-- create a big (partitioned) version of the FactInternetSales table
CREATE TABLE dbo.FactInternetSalesBig14 (
    ProductKey int NOT NULL,
	OrderDateKey int NOT NULL,
	DueDateKey int NOT NULL,
	ShipDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	SalesOrderNumber nvarchar(20) NOT NULL,
	SalesOrderLineNumber tinyint NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderQuantity smallint NOT NULL,
	UnitPrice money NOT NULL,
	ExtendedAmount money NOT NULL,
	UnitPriceDiscountPct float NOT NULL,
	DiscountAmount float NOT NULL,
	ProductStandardCost money NOT NULL,
	TotalProductCost money NOT NULL,
	SalesAmount money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	CustomerPONumber nvarchar(25) NULL,
	OrderDate datetime NULL,
	DueDate datetime NULL,
	ShipDate datetime NULL
) ON [PRIMARY]; -- psOrderDateMonth(OrderDateKey);
GO

-- create the clustered index with PAGE data compression
CREATE CLUSTERED INDEX CSIX_FactInternetSalesBig14
ON dbo.FactInternetSalesBig14 (OrderDateKey ASC)
WITH (DATA_COMPRESSION = PAGE);
GO

-- copy the data from the FactInternetSales into the new table
INSERT INTO dbo.FactInternetSalesBig14 WITH(TABLOCKX)
SELECT * FROM dbo.FactInternetSales;
GO

-- increasing the number of rows
INSERT INTO dbo.FactInternetSalesBig14 WITH(TABLOCKX)
	(ProductKey, OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, ExtendedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStandardCost, TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate)
SELECT
	ProductKey, OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, PromotionKey, CurrencyKey, SalesTerritoryKey, LEFT(CAST(NEWID() AS NVARCHAR(36)), 20) AS SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, ExtendedAmount, UnitPriceDiscountPct, DiscountAmount, ProductStandardCost, TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, CustomerPONumber, OrderDate, DueDate, ShipDate
FROM dbo.FactInternetSalesBig14;
CHECKPOINT;
GO 8 -- change this based on your test environment storage and time you want to wait

-- check the number of records in the FactInternetSalesBig14 table
SELECT
	FORMAT(COUNT(*), '#,##') AS row_num
FROM dbo.FactInternetSalesBig14;

-- look the the result
EXEC sp_helpindex 'FactInternetSales';
EXEC sp_helpindex 'FactInternetSalesBig';
EXEC sp_helpindex 'FactInternetSalesBig12';
EXEC sp_helpindex 'FactInternetSalesBig14';
GO
