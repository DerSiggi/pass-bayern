USE AdventureWorksDW;
GO

-- add the actual execution plan (Ctrl+M)

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

--
-- 1) Verkaufszahlen nach Region
--

SELECT 
	SalesTerritoryKey, 
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount) AS SalesAmount
FROM
	dbo.FactInternetSalesBig12
GROUP BY
	SalesTerritoryKey;


--
-- 2)  Verkaufszahlen nach Region, Produkt, Jahr, Quartal - gefiltert, gruppiert, sortiert
--

SELECT 
	ST.SalesTerritoryRegion AS Region, 
	MIN(P.EnglishProductName) AS Product, 
	D.CalendarYear, 
	D.CalendarQuarter,  
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount) AS SalesAmount
FROM
	dbo.FactInternetSalesBig12 FIS
INNER JOIN 
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
INNER JOIN
	dbo.DimProductSubcategory PS ON PS.ProductCategoryKey = P.ProductSubcategoryKey
INNER JOIN
	dbo.DimSalesTerritory ST ON ST.SalesTerritoryKey = FIS.SalesTerritoryKey
WHERE
		PS.EnglishProductSubcategoryName = 'Mountain Bikes' 
	AND 
		D.DateKey BETWEEN 20050101 AND 20103112
	AND
		FIS.SalesTerritoryKey = 3
GROUP BY
	ST.SalesTerritoryRegion, P.ProductKey, D.CalendarYear, D.CalendarQuarter
ORDER BY
	Region, Product, D.CalendarYear, D.CalendarQuarter
OPTION
	(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
GO

--
-- 3)  Verkaufszahlen nach Geschlecht, Einkommen, Produktkategorie - gefiltert, gruppiert, sortiert
--

SELECT
	Gender,
	YearlyIncome,
	PC.EnglishProductCategoryName, 
	SUM(OrderQuantity) AS OrderQuantity, 
	SUM(SalesAmount)  AS SalesAmount
FROM
	dbo.FactInternetSalesBig12 FIS 
INNER JOIN 
	dbo.DimCustomer C ON C.CustomerKey = FIS.CustomerKey 
INNER JOIN 
	dbo.DimDate D ON D.DateKey = FIS.OrderDateKey
INNER JOIN
	dbo.DimProduct P ON P.ProductKey = FIS.ProductKey
INNER JOIN 
	dbo.DimProductSubcategory PS ON PS.ProductSubcategoryKey = P.ProductSubcategoryKey
INNER JOIN
	dbo.DimProductCategory PC ON PC.ProductCategoryKey = PS.ProductCategoryKey
WHERE
	D.CalendarYear = 2007
GROUP BY 
	Gender, YearlyIncome, PC.EnglishProductCategoryName
ORDER BY
	Gender, YearlyIncome, PC.EnglishProductCategoryName, SUM(SalesAmount) DESC
OPTION
	(IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX);
GO

SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;