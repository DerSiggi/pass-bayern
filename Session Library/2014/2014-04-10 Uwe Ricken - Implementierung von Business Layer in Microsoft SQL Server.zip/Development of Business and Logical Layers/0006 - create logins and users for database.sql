/*============================================================================
	File:		0006 - create logins and users for database.sql

	Summary:	This script creates logins and users which will have different
				access privileges to the data

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Login StaffUser
RAISERROR ('Creation of login [CustomerUser]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'CustomerUser')
	DROP LOGIN CustomerUser;
	GO

CREATE LOGIN CustomerUser WITH Password = 'abc$123', CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
GO

RAISERROR ('Creation of login [StaffUser]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'StaffUser')
	DROP LOGIN StaffUser;
	GO

CREATE LOGIN StaffUser WITH Password = 'abc$123', CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
GO

-- Login FinanceUser
RAISERROR ('Creation of login [FinanceUser]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'FinanceUser')
	DROP LOGIN FinanceUser;
	GO

CREATE LOGIN FinanceUser WITH Password = 'abc$123', CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
GO

-- Login Management
RAISERROR ('Creation of login [Management]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'Management')
	DROP LOGIN Management;
	GO

CREATE LOGIN Management WITH Password = 'abc$123', CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
GO

-- Creation of users in demo_db
USE demo_db;
GO


RAISERROR ('Creation of user [CustomerUser] in [demo_db]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'CustomerUser')
	DROP USER [CustomerUser];
	GO

CREATE USER [CustomerUser] FROM LOGIN [CustomerUser] WITH DEFAULT_SCHEMA = dbo;
GO

RAISERROR ('Creation of user [StaffUser] in [demo_db]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'StaffUser')
	DROP USER [StaffUser];
	GO

CREATE USER [StaffUser] FROM LOGIN [StaffUser] WITH DEFAULT_SCHEMA = dbo;
GO

RAISERROR ('Creation of user [FinanceUser] in [demo_db]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'FinanceUser')
	DROP USER FinanceUser;
	GO

CREATE USER [FinanceUser] FROM LOGIN [FinanceUser] WITH DEFAULT_SCHEMA = dbo;
GO

RAISERROR ('Creation of user [Management] in [demo_db]...', 0, 1) WITH NOWAIT;
IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'Management')
	DROP USER Management;
	GO

CREATE USER [Management] FROM LOGIN [Management] WITH DEFAULT_SCHEMA = dbo;
GO

-- Grant privileges on schemata to database users
RAISERROR ('Grant EXECUTE privielges on application-schema...', 0, 1) WITH NOWAIT;
GRANT EXECUTE ON SCHEMA::application TO CustomerUser;
GRANT EXECUTE ON SCHEMA::application TO StaffUser;
GRANT EXECUTE ON SCHEMA::application TO FinanceUser;
GRANT EXECUTE ON SCHEMA::application TO Management;
GO

RAISERROR ('Grant SELECT, EXECUTE privielges on controls-schema...', 0, 1) WITH NOWAIT;
GRANT SELECT, EXECUTE ON SCHEMA::controls TO CustomerUser;
GRANT SELECT, EXECUTE ON SCHEMA::controls TO StaffUser;
GRANT SELECT, EXECUTE ON SCHEMA::controls TO FinanceUser;
GRANT SELECT, EXECUTE ON SCHEMA::controls TO Management;
GO


-- Create database roles for access to schemas and objects
IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'A-CUSTOMER')
	DROP ROLE [A-CUSTOMER];
	GO

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'B-CUSTOMER')
	DROP ROLE [B-CUSTOMER];
	GO

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'C-CUSTOMER')
	DROP ROLE [C-CUSTOMER];
	GO

RAISERROR ('Create roles for access level for data...', 0, 1) WITH NOWAIT;
CREATE ROLE [A-CUSTOMER] AUTHORIZATION dbo;
CREATE ROLE [B-CUSTOMER] AUTHORIZATION dbo;
CREATE ROLE [C-CUSTOMER] AUTHORIZATION dbo;
GO

-- Add Management to all customer roles
ALTER ROLE [A-CUSTOMER] ADD Member Management;
ALTER ROLE [B-CUSTOMER] ADD Member Management;
ALTER ROLE [C-CUSTOMER] ADD Member Management;
GO

-- Add CustomerStaff to all customer roles
ALTER ROLE [A-CUSTOMER] ADD Member CustomerUser;
ALTER ROLE [B-CUSTOMER] ADD Member CustomerUser;
ALTER ROLE [C-CUSTOMER] ADD Member CustomerUser;
GO

-- Add FinanceUser to A-CUSTOMER only
ALTER ROLE [A-CUSTOMER] ADD Member FinanceUser;
GO

-- Validiation
SELECT * FROM sys.server_principals WHERE type = 'S' AND CAST(create_date AS date) = CAST(getdate() AS date);
SELECT * FROM sys.database_principals WHERE type = 'S' AND CAST(create_date AS date) = CAST(getdate() AS date);
SELECT * FROM sys.database_principals WHERE type = 'R' AND CAST(create_date AS date) = CAST(getdate() AS date);
GO
