/*============================================================================
	File:		0004 - Usage of triggers.sql

	Summary:	This script demonstrates triggers on tables / views

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

/* Creation of trigger for check of zip based on country code */
IF OBJECT_ID('data.trg_Customer_Insert', 'TR') IS NOT NULL
	DROP TRIGGER data.trg_Customer_Insert;
	GO

CREATE TRIGGER data.trg_Customer_Insert
ON data.Customer
FOR INSERT, UPDATE
AS
	SET NOCOUNT ON;
	
	IF EXISTS
	(
		SELECT * FROM inserted
		WHERE	CustomerCCode = 'DE' AND
				LEN(CustomerZIP) != 5
	)
	BEGIN
		RAISERROR ('german zip codes must have 5 characters!', 11, 1) WITH NOWAIT;
		ROLLBACK
	END

	SET NOCOUNT OFF;
GO

/* successfull insertion */
INSERT INTO data.Customer
(CustomerName, CustomerStreet, CustomerCCode, CustomerZIP, CustomerCity)
VALUES
('db Berater GmbH', 'Bahnstrasse 33', 'DE', '64390', 'Erzhausen');
GO

/* will fail because of violation of data integrity */
INSERT INTO data.Customer
(CustomerName, CustomerStreet, CustomerCCode, CustomerZIP, CustomerCity)
VALUES
('American Chamber of Commerce', 'Ro�markt 13', 'DE', '6000', 'Frankfurt am Main');
GO

/* what have been inserted */
SELECT * FROM data.Customer;
GO

-- Trigger for the update of attributes when records have been updates
IF OBJECT_ID('data.trg_Customer_Update', 'TR') IS NOT NULL
	DROP TRIGGER data.trg_Customer_Update;
	GO

CREATE TRIGGER data.trg_Customer_Update
ON data.Customer
FOR UPDATE
AS
	SET NOCOUNT ON;

	UPDATE	c
	SET		c.UpdateUser	=	ORIGINAL_LOGIN(),
			c.UpdateDate	=	getdate()
	FROM	data.Customer c INNER JOIN deleted d
			ON (c.Id = d.Id)

	SET NOCOUNT OFF;
GO

/* Update of customer information */
SELECT * FROM data.Customer;
GO

UPDATE	data.Customer
SET		CustomerZIP = '60313'
WHERE	Id = 1;
GO

SELECT * FROM data.Customer;
GO
