/*============================================================================
	File:		0002 - create schemas.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

DECLARE	@stmt	nvarchar(1000);
DECLARE	@schema	nvarchar(20);

SET	@schema = N'data';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END

SET	@schema = N'controls';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END

SET	@schema = 'reporting';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END

SET	@schema = 'application';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END

SET	@schema = 'business';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END

SET	@schema = 'system';
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = @schema)
BEGIN
	RAISERROR ('Creating schema [%s]...', 0, 1, @schema) WITH NOWAIT;
	SET	@stmt = N'CREATE SCHEMA [' + @schema + '] AUTHORIZATION dbo;';
	EXEC sp_executeSQL @stmt;
END
