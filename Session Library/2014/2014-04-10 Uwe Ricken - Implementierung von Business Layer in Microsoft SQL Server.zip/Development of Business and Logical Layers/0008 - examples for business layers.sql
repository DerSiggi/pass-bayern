/*============================================================================
	File:		0008 - examples for business layers.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

/* 1. Klassifizierung von Kunden auf Basis der durchschnittlichen Rechnungssummen */
IF OBJECT_ID('business.view_CustomerByCategory', 'V') IS NOT NULL
	DROP VIEW business.view_CustomerByCategory;
	GO

CREATE VIEW business.view_CustomerByCategory
AS
	WITH AvgInvoiceSum
	AS
	(
		SELECT	Customer_Id,
				COUNT_BIG(*)		AS Num_Invoices,
				MAX(InvoiceAmount)	AS Max_InvoiceAmount,
				MIN(InvoiceAmount)	AS Min_InvoiceAmount,
				AVG(InvoiceAmount)	AS Avg_InvoiceAmount
		FROM	data.Invoices
		GROUP BY
				Customer_Id
	)
	SELECT	c.Id,
			c.CustomerName,
			c.CustomerCCode,
			c.CustomerZIP,
			c.CustomerCity,
			a.Num_Invoices,
			a.Min_InvoiceAmount,
			a.Max_InvoiceAmount,
			a.Avg_InvoiceAmount,
			CASE
				WHEN a.Avg_InvoiceAmount < 2500 THEN 'C-CUSTOMER'
				WHEN a.Avg_InvoiceAmount BETWEEN 2500 AND 7500 THEN 'B-CUSTOMER'
				WHEN a.Avg_InvoiceAmount > 7500 THEN 'A-CUSTOMER'
				ELSE 'unkown'
			END							AS	CustomerClass 
	FROM	data.Customer c INNER JOIN AvgInvoiceSum a
			ON (c.Id = a.Customer_Id)
GO

-- business view for Customer_Id where user may have access to
IF OBJECT_ID('business.view_available_customer_id', 'V') IS NOT NULL
	DROP VIEW business.view_available_customer_id;
	GO

CREATE VIEW business.view_available_customer_id
AS
	SELECT	Id
	FROM	business.view_CustomerByCategory
	WHERE	IS_MEMBER(CustomerClass) = 1;
GO

-- fails because user does not have SELECT permission
-- either on the schema nor on the object
EXECUTE AS User = 'Management';
SELECT * FROM business.view_CustomerByCategory;
REVERT;
GO

-- Create a stored procedure for the access because access
-- is only allowed by EXECUTE privileges
CREATE PROC application.proc_CustomerList
AS
	SET NOCOUNT ON;

	SELECT	Id,
			CustomerName,
			CustomerCCode,
			CustomerZIP,
			CustomerCity,
			Num_Invoices,
			Min_InvoiceAmount,
			Max_InvoiceAmount,
			Avg_InvoiceAmount,
			CustomerClass
	FROM	business.view_CustomerByCategory
	WHERE	IS_MEMBER(CustomerClass) = 1 OR
			CustomerClass = 'unkown'
	ORDER BY
			CustomerName;

	SET NOCOUNT OFF;
GO

EXECUTE AS User = 'Management';
SELECT * FROM business.view_CustomerByCategory;
EXEC application.proc_CustomerList;
REVERT;

-- Why cover calls for views in stored procedures?
SELECT * FROM business.view_CustomerByCategory
WHERE	CAST(CustomerClass AS int) = 1;
GO

-- Creation of procedure for controls
IF OBJECT_ID('controls.proc_lst_Customerlist', 'P') IS NOT NULL
	DROP PROC controls.proc_lst_Customerlist
	GO

CREATE PROC controls.proc_lst_Customerlist
AS
	SET NOCOUNT ON;

	SELECT	Id,
			CustomerName,
			CustomerZIP,
			CustomerCity
	FROM	business.view_CustomerByCategory
	WHERE	IS_MEMBER(CustomerClass) = 1
	ORDER BY
			CustomerName;

	SET NOCOUNT OFF;
GO

-- Check the security in the access application
-- BREAK!!!

-- Now add FinanceUser to the [C-Customer]-Role
ALTER ROLE [C-Customer] ADD MEMBER FinanceUser;
GO

ALTER ROLE [A-Customer] DROP MEMBER FinanceUser;
GO


-- Creation of procedure for invoice list in Access
IF OBJECT_ID('controls.proc_lst_CustomerInvoiceList', 'P') IS NOT NULL
	DROP PROC controls.proc_lst_CustomerInvoiceList
	GO

CREATE PROC controls.proc_lst_CustomerInvoiceList
	@Customer_Id	int
AS
	SET NOCOUNT ON;

	SELECT	i.Customer_Id,
			i.InvoiceNumber,
			i.InvoiceDate,
			i.InvoiceAmount,
			i.InvoicePaymentDate
	FROM	data.invoices i INNER JOIN business.view_available_customer_id v
			ON (i.Customer_Id = v.Id)
	WHERE	i.Customer_Id = @Customer_Id

	SET NOCOUNT OFF;
GO

EXECUTE AS Login = 'FinanceUser'
EXEC controls.proc_lst_CustomerInvoiceList 19;
REVERT;

