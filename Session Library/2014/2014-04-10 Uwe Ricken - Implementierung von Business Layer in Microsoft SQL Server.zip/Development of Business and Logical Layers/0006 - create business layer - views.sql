/*============================================================================
	File:		0005 - create business layser - views.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
SET NOCOUNT ON;
SET LANGUAGE us_english;
GO

-- View with all customers and their annual amount
IF OBJECT_ID('business.view_CustomerAmountByYear', 'V') IS NOT NULL
	DROP VIEW business.view_CustomerAmountByYear;
	GO

CREATE VIEW business.view_CustomerAmountByYear
AS
	SELECT	c.Id,
			c.CustomerName,
			c.CustomerStreet,
			c.CustomerCCode,
			c.CustomerZIP,
			c.CustomerCity,
			YEAR(i.InvoiceDate)		AS	InvoiceYear,
			SUM(i.InvoiceAmount)	AS	Sum_InvoiceAmount,
			AVG(i.InvoiceAmount)	AS	AVG_InvoiceAmount
	FROM	data.Customer c INNER JOIN data.Invoices i
			ON (c.Id = i.Customer_Id)
	GROUP BY
			c.Id,
			c.CustomerName,
			c.CustomerStreet,
			c.CustomerCCode,
			c.CustomerZIP,
			c.CustomerCity,
			YEAR(i.InvoiceDate);
GO

SELECT * FROM business.view_CustomerAmountByYear
ORDER BY
	CustomerName,
	InvoiceYear;