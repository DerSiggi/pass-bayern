/*============================================================================
	File:		0007 - demonstration of schemata.sql

	Summary:	This script creates logins and users which will have different
				access privileges to the data

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- Create a schema demo with dbo as owner
CREATE SCHEMA demo AUTHORIZATION dbo;
GO

-- Now add User Management with SELECT privileges
GRANT SELECT ON schema::demo TO Management;
GO

-- Now we create a relation in the demo-schema
CREATE TABLE demo.foo
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(200)	NOT NULL	DEFAULT ('just stuff')
);
GO

-- Insert 
INSERT INTO demo.foo DEFAULT VALUES;
GO 10

-- Execute as StaffUser
EXECUTE AS User = 'StaffUser'
SELECT * FROM demo.foo;
REVERT

EXECUTE AS User = 'Management'
SELECT * FROM demo.foo;
REVERT;

-- Investigate the schema and the object owner!
SELECT * FROM sys.schemas WHERE name = 'demo';
SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('demo.foo', 'U');
GO

ALTER AUTHORIZATION ON OBJECT::demo.foo TO StaffUser;
GO

-- Execute as StaffUser
EXECUTE AS User = 'StaffUser'
SELECT * FROM demo.foo;
REVERT

EXECUTE AS User = 'Management'
SELECT * FROM demo.foo;
REVERT;

-- Investigate the schema and the object owner!
SELECT * FROM sys.schemas WHERE name = 'demo';
SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('demo.foo', 'U');
GO

-- Clean the kitchen
DROP TABLE demo.foo;
DROP SCHEMA demo;
GO
