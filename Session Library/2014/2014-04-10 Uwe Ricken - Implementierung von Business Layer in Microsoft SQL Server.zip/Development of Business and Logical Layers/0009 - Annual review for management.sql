/*============================================================================
	File:		0009 - Annual review for management.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- Creation of schema for reporting objects
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'reporting')
	EXEC sp_executeSQL N'CREATE SCHEMA [reporting] AUTHORIZATION dbo;';
	GO

-- Authorization in the reporting schema for everybody
-- no problem because of security IN the procedures
GRANT EXECUTE ON schema::reporting TO public;
GO

-- Create a procedure for the annual revue for management members
IF OBJECT_ID('reporting.proc_Customer_TurnOver', 'P') IS NOT NULL
	DROP PROC reporting.proc_Customer_TurnOver
	GO

CREATE PROC reporting.proc_Customer_TurnOver
AS
	SET NOCOUNT ON;

	SELECT	c.Id,
			c.CustomerName,
			i.InvoiceDate,
			i.InvoiceAmount
	FROM	data.Customer AS c INNER JOIN data.Invoices AS i
			ON (c.Id = i.Customer_Id) INNER JOIN business.view_available_customer_id v
			ON (i.Customer_Id = v.Id)
	-- last three years
	WHERE	YEAR(InvoiceDate) >= YEAR(getdate()) - 3;

	SET NOCOUNT OFF;
GO

EXECUTE AS Login = 'FinanceUser'
EXEC reporting.proc_Customer_TurnOver;
REVERT;
