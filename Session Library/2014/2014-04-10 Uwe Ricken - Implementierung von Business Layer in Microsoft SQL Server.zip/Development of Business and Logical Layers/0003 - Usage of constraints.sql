/*============================================================================
	File:		0003 - Usage of constraints.sql

	Summary:	This script creates a new table for demonstration of business
				rules based on metas data level

				THIS SCRIPT IS PART OF THE TRACK: "Development of business layers"

	Date:		March 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

/* detail relation for storage of invoices for each customer */
IF OBJECT_ID('data.Invoices', 'U') IS NOT NULL
	DROP TABLE data.Invoices;
	GO


/* Masterrelation for storage of customer data */
IF OBJECT_ID('data.Customer', 'U') IS NOT NULL
	DROP TABLE data.Customer;
	GO

CREATE TABLE data.Customer
(
	Id				int				NOT NULL	IDENTITY (1, 1),
	CustomerName	varchar(255)	NOT NULL,
	CustomerStreet	varchar(100)	NOT NULL,
	CustomerCCode	varchar(3)		NOT NULL	DEFAULT ('DE'),
	CustomerZIP		varchar(10)		NOT NULL,
	CustomerCity	varchar(100)	NOT NULL,
	InsertUser		sysname			NOT NULL	DEFAULT (ORIGINAL_LOGIN()), CHECK (InsertUser = ORIGINAL_LOGIN()),
	InsertDate		datetime		NOT NULL	DEFAULT (GETDATE()),
	UpdateUser		sysname			NULL,
	UpdateDate		datetime		NULL,

	CONSTRAINT	pk_Customer PRIMARY KEY CLUSTERED (Id),
	CONSTRAINT	ix_Customer UNIQUE (CustomerName)
)
GO

/* detail relation for storage of invoices for each customer */
IF OBJECT_ID('data.Invoices', 'U') IS NOT NULL
	DROP TABLE data.Invoices;
	GO

CREATE TABLE data.Invoices
(
	Id					int				NOT NULL	IDENTITY (1, 1),
	InvoiceNumber		char(8)			NOT NULL,
	InvoiceDate			date			NOT NULL,
	CustomerName		varchar(255)	NOT NULL,
	InvoiceStreet		varchar(100)	NOT NULL,
	InvoiceCCode		char(3)			NOT NULL,
	InvoiceZIP			varchar(10)		NOT NULL,
	InvoiceCity			varchar(100)	NOT NULL,
	InvoiceAmount		smallmoney		NOT NULL,
	InvoiceCurrency		char(3)			NOT NULL,
	InvoicePaymentDate	date			NULL,
	Customer_Id			int				NOT NULL
);
GO

/*
	no constraints on level of attributes
	no referencial integrity
*/

/* creation of default constraints */
ALTER TABLE data.invoices ADD CONSTRAINT df_invoices_invoicedate
DEFAULT (GETDATE()) FOR InvoiceDate;
ALTER TABLE data.invoices ADD CONSTRAINT df_invoices_invoicececcode
DEFAULT ('DE') FOR InvoiceCCode;
ALTER TABLE data.invoices ADD CONSTRAINT df_invoices_invoiceamount
DEFAULT (0) FOR InvoiceAmount;
ALTER TABLE data.invoices ADD CONSTRAINT df_invoices_invoicecurrency
DEFAULT ('�') FOR InvoiceCurrency;
GO

/*	create foreign key for referencial integrity */
ALTER TABLE data.invoices ADD CONSTRAINT fk_Customer_Id FOREIGN KEY (Customer_Id)
REFERENCES data.Customer (Id)
--ON DELETE CASCADE
ON UPDATE CASCADE;