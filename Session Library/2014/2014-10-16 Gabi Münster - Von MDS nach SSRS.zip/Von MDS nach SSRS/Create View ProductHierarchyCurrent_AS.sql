USE [AdventureWorksDW2014]
GO

/****** Object:  View [dbo].[ProductHierarchyCurrent_AS]    Script Date: 17.11.2014 13:03:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[ProductHierarchyCurrent_AS] AS
SELECT [VersionName]
      ,[VersionNumber]
      ,[VersionFlag]
      ,[Hierarchy]
      ,[ROOT]
      ,[Category_ID] AS [ProductCategory_ID]
      ,CAST([Category_Code] AS INT) AS [ProductCategory_Code]
      ,[Category_Name] AS [ProductCategory_Name]
      ,[SubCategory_ID] AS [ProductSubCategory_ID]
      ,CAST([SubCategory_Code] AS INT) AS [ProductSubCategory_Code]
      ,[SubCategory_Name] AS [ProductSubCategory_Name]
      ,[Product_ID] AS [Product_ID]
      ,CAST([Product_Code] AS INT) AS [Product_Code]
      ,[Product_Name] AS [Product_Name]
  FROM [MDS].[mdm].[V_PassKoeln_Current]





GO


